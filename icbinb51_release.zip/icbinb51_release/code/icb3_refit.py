#!/usr/bin/env python3
"""icb3_refit.py -- ICB-3, the part that FITS models (Slurm only): \\NRtwoOneFeature and the reproduction guards.

\\NRtwoOneFeature is the leave-one-clade-out R^2 for mean coverage (y_cov) of a ONE-feature linear fit on
f_minscore_mean (the mean of min(p, 1-p) over the unlabelled test batch), with pred.y_cov.gbr's protocol: paper_numbers.py's
own loco() (l.49-54: LeaveOneGroupOut by clade, out-of-fold predictions pooled, then one r2_score over all pairs, as in
l.65), run from the input copy's TEXT (pinned by INPUTS.sha256) with ONE line changed, the model (l.52), which becomes
LinearRegression() (ordinary least squares; no seed is involved, and the folds are the same deterministic clade folds).
Before that, the harness must REPRODUCE (abort, exit 2, otherwise):
  (A) pred.y_cov.gbr.r2: loco(F, "y_cov", "gbr") with the UNCHANGED text must give email-7 r08's unrounded LOCO R^2
      (nums_67 27baf2c, within 1e-12) and round to PAPER_NUMBERS.json's 4-dp value;
  (B) screen.labelfree_auroc / _ap: paper_numbers.py's loco_clf(F) (l.98-104, unchanged) with l.107-108's metric calls must
      round to PAPER_NUMBERS.json's 4-dp values; and the identity rule run through the same harness (as icb3_screen.py)
      must give icb3_screen.py's AUROC and AP exactly.
Context values (not macros): the one-feature fit with paper_numbers' own Ridge(alpha=1.0) and with its GBR, same folds.

Usage: icb3_refit.py --root INPUT_ROOT --screen icb3_screen.json --out OUT.json       (Slurm)
       icb3_refit.py --root INPUT_ROOT --check-only                                  (login node: text checks, no fit)
"""
import argparse, hashlib, json, os, re, sys

FEAT = "f_minscore_mean"
WANT = {46: 'F=sorted([c for c in p.columns if c.startswith("f_")])', 48: 'g=p["clade"].to_numpy()',
        49: 'def loco(cols,target,model="gbr"):',
        52: '        m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))',
        54: '    return y,pr', 65: '        N[f"pred.{target}.{name}.r2"]=round(float(r2_score(y,pr)),4)',
        98: "ysev=(p.y_cov<0.70).astype(int).to_numpy()", 99: "def loco_clf(cols):",
        103: '        pr[te]=GradientBoostingClassifier(random_state=0).fit(X[tr],ysev[tr]).predict_proba(X[te])[:,1]',
        104: "    return pr", 107: 'N["screen.labelfree_auroc"]=round(float(roc_auc_score(ysev,pr_lf)),4)',
        108: 'N["screen.labelfree_ap"]=round(float(average_precision_score(ysev,pr_lf)),4)'}


def guard(r2, r2_e7, pn_r2, auc_lf, ap_lf, pn_auc, pn_ap, auc_id, ap_id, scr_auc, scr_ap):
    """the reproduction guard as a pure function: the list of failures (empty = pass)"""
    f = []
    if abs(r2 - r2_e7) > 1e-12 or round(r2, 4) != pn_r2:
        f.append(f"(A) loco(F, y_cov, gbr) R2 {r2!r}: email-7 r08 {r2_e7!r}, PAPER_NUMBERS {pn_r2}")
    if round(auc_lf, 4) != pn_auc or round(ap_lf, 4) != pn_ap:
        f.append(f"(B) loco_clf(F): AUROC {auc_lf!r}, AP {ap_lf!r} do not round to PAPER_NUMBERS {pn_auc}, {pn_ap}")
    if auc_id != scr_auc or ap_id != scr_ap:
        f.append(f"(B) identity rule AUROC {auc_id!r}, AP {ap_id!r} differ from icb3_screen.py's {scr_auc!r}, {scr_ap!r}")
    return f


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def texts(root):
    man = dict(reversed(ln.split(None, 1)) for ln in open(os.path.join(root, "INPUTS.sha256")).read().splitlines() if ln.strip())
    used = {}
    for rel in ("amrconf/src/paper_numbers.py", "amrconf/results/c2v2_pairs_s0.parquet", "amrconf/results/PAPER_NUMBERS.json",
                "nums_67/27baf2c/e7/logs/r08_sd_ratio.out"):
        h = sha256(os.path.join(root, rel))
        if man.get(rel) != h:
            sys.exit(f"icb3_refit: ABORT {rel} does not match INPUTS.sha256")
        used[rel] = h
    src = open(os.path.join(root, "amrconf/src/paper_numbers.py")).read().splitlines()
    bad = [k for k, v in WANT.items() if src[k - 1] != v]
    if bad:
        sys.exit(f"icb3_refit: ABORT paper_numbers.py differs from the expected text at lines {bad}")
    head = src[45] + "\n" + src[47]                                   # F (l.46), g (l.48)
    loco = "\n".join(src[48:54])                                       # l.49-54, unchanged
    loco_ols = loco.replace("def loco(cols,target,model=\"gbr\"):", "def loco_ols(cols,target,model=None):") \
                   .replace(src[51], "        m=LinearRegression()   # ICB-3: the one-feature linear fit (l.52's model line, changed)")
    clf = "\n".join(src[97:104])                                       # l.98-104, unchanged
    ident = clf.replace("def loco_clf(cols):", "def loco_ident(cols):").replace(
        src[102], "        pr[te]=X[te][:,0]   # identity rule (icb3_screen.py)")
    if loco_ols.count("LinearRegression()") != 1 or "loco_ident" not in ident or "identity rule" not in ident:
        sys.exit("icb3_refit: ABORT could not build the changed harnesses")
    return src, used, head, loco, loco_ols, clf, ident


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--screen"); ap.add_argument("--out")
    ap.add_argument("--check-only", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    src, used, head, loco, loco_ols, clf, ident = texts(root)
    print("text: paper_numbers.py l.46, l.48, l.49-54 (loco; and loco_ols = l.52's model -> LinearRegression()), "
          "l.98-104 (loco_clf; and loco_ident = l.103 -> identity rule), metrics as l.65 and l.107-108")
    if a.check_only:
        compile("\n".join([head, loco, loco_ols, clf, ident]), "<icb3>", "exec")
        print("check-only: texts match and compile; nothing fitted"); return
    if not (a.screen and a.out):
        ap.error("--screen and --out are required")
    import numpy as np, pandas as pd, sklearn
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier
    from sklearn.linear_model import Ridge, LinearRegression
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.metrics import r2_score, roc_auc_score, average_precision_score
    p = pd.read_parquet(os.path.join(root, "amrconf/results/c2v2_pairs_s0.parquet"))
    PN = json.load(open(os.path.join(root, "amrconf/results/PAPER_NUMBERS.json")))
    r08 = open(os.path.join(root, "nums_67/27baf2c/e7/logs/r08_sd_ratio.out")).read()
    r2_e7 = float(re.search(r"^\s*LOCO R2 ([0-9.]+);", r08, re.M).group(1))
    G = {"np": np, "p": p, "GradientBoostingRegressor": GradientBoostingRegressor, "GradientBoostingClassifier": GradientBoostingClassifier,
         "Ridge": Ridge, "LinearRegression": LinearRegression, "LeaveOneGroupOut": LeaveOneGroupOut}
    for block in (head, loco, loco_ols, clf, ident):
        exec(block, G)
    out = {}
    # (A) pred.y_cov.gbr, unchanged harness
    y, pr = G["loco"](G["F"], "y_cov", "gbr"); r2 = float(r2_score(y, pr))
    out["reproduce_pred_y_cov_gbr_r2"] = r2
    # (B) the trained screen and the identity rule through the same harness
    pr_lf = G["loco_clf"](G["F"]); auc_lf = float(roc_auc_score(G["ysev"], pr_lf)); ap_lf = float(average_precision_score(G["ysev"], pr_lf))
    out["reproduce_screen_labelfree"] = {"auroc": auc_lf, "ap": ap_lf}
    pr_id = G["loco_ident"]([FEAT]); auc_id = float(roc_auc_score(G["ysev"], pr_id)); ap_id = float(average_precision_score(G["ysev"], pr_id))
    scr = json.load(open(a.screen))
    out["identity_rule_same_harness"] = {"auroc": auc_id, "ap": ap_id}
    args = dict(r2=r2, r2_e7=r2_e7, pn_r2=PN["pred.y_cov.gbr.r2"], auc_lf=auc_lf, ap_lf=ap_lf, pn_auc=PN["screen.labelfree_auroc"],
                pn_ap=PN["screen.labelfree_ap"], auc_id=auc_id, ap_id=ap_id, scr_auc=scr["auroc"], scr_ap=scr["ap"])
    fails = guard(**args)
    # negative controls of the guard: each perturbed expected value must make it fire with its own message
    ctl = {"(A) r2_e7 + 1e-6": dict(args, r2_e7=r2_e7 + 1e-6), "(B) screen AUROC expected + 0.0001": dict(args, pn_auc=round(PN["screen.labelfree_auroc"] + 0.0001, 4)),
           "(B) identity AUROC expected + 1e-9": dict(args, scr_auc=scr["auroc"] + 1e-9)}
    out["guard_negative_controls"] = {k: guard(**v) for k, v in ctl.items()}
    ctl_ok = all(len(v) == 1 and v[0].startswith(k[:3]) for k, v in out["guard_negative_controls"].items())
    if not ctl_ok:
        fails.append(f"guard negative controls did not all fire: {out['guard_negative_controls']}")
    # the macro and its context
    y, pr = G["loco_ols"]([FEAT], "y_cov"); out["r2_one_feature_ols"] = float(r2_score(y, pr))
    y, pr = G["loco"]([FEAT], "y_cov", "ridge"); out["context_r2_one_feature_ridge_alpha1"] = float(r2_score(y, pr))
    y, pr = G["loco"]([FEAT], "y_cov", "gbr"); out["context_r2_one_feature_gbr"] = float(r2_score(y, pr))
    full = LinearRegression().fit(p[[FEAT]].to_numpy(), p["y_cov"].to_numpy())
    out["context_ols_all_pairs"] = {"slope": float(full.coef_[0]), "intercept": float(full.intercept_)}
    out.update(feature=FEAT, target="y_cov", n_pairs=int(len(p)), n_clades=int(p.clade.nunique()), sklearn=sklearn.__version__,
               numpy=np.__version__, inputs_sha256=dict(used, **{"icb3_screen.json": sha256(a.screen)}), checks_failed=fails)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    for f in fails:
        print(f"ABORT icb3_refit: {f}")
    print(f"(A) pred.y_cov.gbr R2 reproduced: {r2!r}; (B) screen AUROC/AP {auc_lf!r}/{ap_lf!r}; identity rule {auc_id!r}/{ap_id!r}")
    print(f"guard negative controls: {sum(1 for v in out['guard_negative_controls'].values() if len(v) == 1)} of {len(ctl)} fire")
    print(f"one-feature OLS LOCO R2 {out['r2_one_feature_ols']!r} (context: Ridge(1.0) {out['context_r2_one_feature_ridge_alpha1']!r}, "
          f"GBR {out['context_r2_one_feature_gbr']!r})")
    sys.exit(2 if fails else 0)


if __name__ == "__main__":
    main()
