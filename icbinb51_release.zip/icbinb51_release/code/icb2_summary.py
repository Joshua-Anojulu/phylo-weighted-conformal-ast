#!/usr/bin/env python3
"""icb2_summary.py -- ICB-2 (no fit; login node): the shares behind \\NCorrSummary, from icb2_coverage.csv.

A cell is one (lineage, draw); a variant's cell value is its mean coverage over the cell's drugs (Table 1's statistic).
  (a) over the cells where vanilla's mean coverage is below THR, the share in which at least one of the three corrections
      (class-conditional, oracle prior, covariate-shift weighted) reaches THR (mean coverage >= THR);
  (b) over all cells, the share in which at least one correction's mean coverage exceeds vanilla's by more than MARGIN.
THR is Table 1's under-coverage threshold, read from e3_shift_diagnosis.py l.161 (the code that counts Table 1's
under-covered drugs); MARGIN is read from the spec row of \\NCorrSummary ("by more than ..."). Both input files are pinned.
GUARDS (abort, exit 2): every lineage has the same draws 0..N-1 and every cell the same drugs and the four variants; the
Lineage 2 draw 0 rows equal e3_shift_diagnosis.json's lineage2_blocked coverages exactly (Table 1); (a) and (b) computed by
two independent implementations (pandas group-by; plain Python over the CSV rows) agree exactly.
--mutate thr|margin breaks the plain-Python implementation (for the negative control).

Usage: icb2_summary.py --root INPUT_ROOT --out OUT.json [--mutate thr|margin]
"""
import argparse, csv, hashlib, json, math, os, re, sys

VARS = ["vanilla", "class_conditional", "oracle_prior", "covshift_weighted"]


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out", required=True); ap.add_argument("--mutate", choices=("thr", "margin"))
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    man = {}
    for mf, base in (("INPUTS.sha256", ""), ("derived/DERIVED.sha256", "derived/")):
        for ln in open(os.path.join(root, mf)).read().splitlines():
            if ln.strip():
                h, r = ln.split(None, 1); man[base + r.strip()] = h
    rels = ["derived/icb2_coverage.csv", "derived/icb2_run.json", "amrconf/src/e3_shift_diagnosis.py",
            "amrconf/results/e3_shift_diagnosis.json", "notes/ICBINB_NUMBERS_SPEC_v2.md"]
    used = {}
    for rel in rels:
        h = sha256(os.path.join(root, rel))
        if man.get(rel) != h:
            sys.exit(f"icb2_summary: ABORT {rel} does not match its manifest")
        used[rel] = h
    e3src = open(os.path.join(root, rels[2])).read().splitlines()
    m = re.search(r"undercovered \{sum\(1 for x in c if x<([0-9.]+)\)\}", e3src[160])
    spec = [ln for ln in open(os.path.join(root, rels[4])).read().splitlines() if ln.startswith("| \\NCorrSummary |")]
    mm = re.findall(r"by more than ([0-9.]+)", spec[0]) if len(spec) == 1 else []
    if not m or len(mm) != 1:
        sys.exit("icb2_summary: ABORT the threshold (e3 l.161) or the margin (spec row) could not be read")
    THR, MARGIN = float(m.group(1)), float(mm[0])

    rows = list(csv.DictReader(open(os.path.join(root, rels[0]))))
    fails = []
    # completeness
    cells = {}
    for r in rows:
        cells.setdefault((r["lineage"], int(r["draw"])), {}).setdefault(r["drug"], {})[r["variant"]] = float(r["coverage"])
    lins = sorted({L for L, _ in cells})
    draws = {L: sorted(s for LL, s in cells if LL == L) for L in lins}
    N = len(draws[lins[0]])
    drugs0 = sorted(next(iter(cells.values())))
    if any(draws[L] != list(range(N)) for L in lins):
        fails.append("lineages do not all have draws 0..N-1")
    if any(sorted(c) != drugs0 or any(sorted(v) != sorted(VARS) for v in c.values()) for c in cells.values()):
        fails.append("cells differ in drugs or variants")
    if fails:                       # an incomplete table cannot be summarised: stop before computing any mean
        for f in fails:
            print(f"ABORT icb2_summary: {f}")
        sys.exit(2)
    # Table 1 reproduction from the CSV
    e3 = json.load(open(os.path.join(root, rels[3])))["lineage2_blocked"]
    c0 = cells.get(("Lineage 2", 0), {})
    diff = [abs(c0[d][v] - e3[d]["variants"][v]["coverage"]) for d in e3 for v in VARS if d in c0]
    if len(diff) != len(e3) * len(VARS) or max(diff) != 0.0:
        fails.append(f"Lineage 2 draw 0 does not reproduce Table 1 (compared {len(diff)}, max abs diff {max(diff) if diff else None})")

    # implementation 1: pandas
    import pandas as pd
    df = pd.DataFrame(rows); df["draw"] = df["draw"].astype(int); df["coverage"] = df["coverage"].astype(float)
    cm = df.groupby(["lineage", "draw", "variant"])["coverage"].mean().unstack("variant")
    corr = cm[VARS[1:]]
    sub = cm["vanilla"] < THR
    a_n1, a_k1 = int(sub.sum()), int((corr[sub] >= THR).any(axis=1).sum())
    b_n1, b_k1 = int(len(cm)), int(((corr.sub(cm["vanilla"], axis=0)) > MARGIN).any(axis=1).sum())
    # implementation 2: plain Python over the rows
    a_n2 = a_k2 = b_k2 = 0
    thr2 = THR - 0.01 if a.mutate == "thr" else THR          # the controls' deliberate defects
    mg = MARGIN / 2 if a.mutate == "margin" else MARGIN
    for key, c in cells.items():
        mean = {v: math.fsum(c[d][v] for d in c) / len(c) for v in VARS}
        if mean["vanilla"] < thr2:
            a_n2 += 1; a_k2 += any(mean[v] >= THR for v in VARS[1:])
        b_k2 += any(mean[v] - mean["vanilla"] > mg for v in VARS[1:])
    b_n2 = len(cells)
    if (a_n1, a_k1, b_n1, b_k1) != (a_n2, a_k2, b_n2, b_k2):
        fails.append(f"the two implementations differ: pandas (a) {a_k1}/{a_n1}, (b) {b_k1}/{b_n1}; plain (a) {a_k2}/{a_n2}, (b) {b_k2}/{b_n2}")
    if fails:
        for f in fails:
            print(f"ABORT icb2_summary: {f}")
        sys.exit(2)
    # context: per lineage, split halves, which correction, binomial standard errors
    per_lin = {}
    for L in lins:
        cL = cm.loc[L]
        per_lin[L] = {"mean_over_draws": {v: float(cL[v].mean()) for v in VARS}, "sd_over_draws": {v: float(cL[v].std(ddof=1)) for v in VARS},
                      "cells_vanilla_below": int((cL["vanilla"] < THR).sum()),
                      "a_reaches": int((cL[VARS[1:]][cL["vanilla"] < THR] >= THR).any(axis=1).sum()),
                      "b_beats": int(((cL[VARS[1:]].sub(cL["vanilla"], axis=0)) > MARGIN).any(axis=1).sum())}
    half = {}
    for name, rng in (("draws_first_half", range(0, N // 2)), ("draws_second_half", range(N // 2, N))):
        h = cm[cm.index.get_level_values("draw").isin(list(rng))]
        hs = h["vanilla"] < THR
        half[name] = {"a": [int((h[VARS[1:]][hs] >= THR).any(axis=1).sum()), int(hs.sum())],
                      "b": [int(((h[VARS[1:]].sub(h["vanilla"], axis=0)) > MARGIN).any(axis=1).sum()), int(len(h))]}
    by_var_b = {v: int((cm[v] - cm["vanilla"] > MARGIN).sum()) for v in VARS[1:]}
    by_var_a = {v: int((cm[v][sub] >= THR).sum()) for v in VARS[1:]}
    out = {"n_draws": N, "lineages": lins, "drugs": drugs0, "n_cells": b_n1, "threshold": THR, "margin": MARGIN,
           "a": {"cells_vanilla_below": a_n1, "any_correction_reaches": a_k1, "share": a_k1 / a_n1 if a_n1 else None,
                 "binomial_se": math.sqrt((a_k1 / a_n1) * (1 - a_k1 / a_n1) / a_n1) if a_n1 else None, "by_correction": by_var_a},
           "b": {"cells": b_n1, "any_correction_beats": b_k1, "share": b_k1 / b_n1, "binomial_se": math.sqrt((b_k1 / b_n1) * (1 - b_k1 / b_n1) / b_n1),
                 "by_correction": by_var_b},
           "per_lineage": per_lin, "split_halves": half, "table1_reproduction_from_csv": {"compared": len(diff), "max_abs_diff": max(diff)},
           "implementations_agree": True, "inputs_sha256": used, "mutate": a.mutate}
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"icb2_summary: {N} draws x {len(lins)} lineages = {b_n1} cells; (a) vanilla below {THR} in {a_n1} cells, a correction reaches it in "
          f"{a_k1}; (b) a correction beats vanilla by more than {MARGIN} in {b_k1} of {b_n1}; Table 1 reproduced from the CSV "
          f"({len(diff)} values, max abs diff {max(diff)}); two implementations agree")


if __name__ == "__main__":
    main()
