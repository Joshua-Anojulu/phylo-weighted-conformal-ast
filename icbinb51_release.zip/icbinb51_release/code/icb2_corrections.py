#!/usr/bin/env python3
"""icb2_corrections.py -- ICB-2: Table 1's four conformal variants over many calibration draws, four lineage holdouts.
FITS MODELS (the base classifier and the covariate-shift domain classifier): Slurm only, never on a login node.

Table 1 (e3_shift_diagnosis.py) compares vanilla, class-conditional (Mondrian), oracle-prior and covariate-shift-weighted
split conformal on the lineage-2 holdout at ONE calibration draw. This script repeats it for each of the four lineage
holdouts over N draws, the same nine drugs and alpha, running e3's OWN code: qlevel(), variants() and cov_stats()
(e3 l.39-81) and the per-drug body of run_split() (e3 l.86-96 and l.112-119) are VERBATIM copies, compared line by line
with the input copy of e3_shift_diagnosis.py before anything runs. Left out: e3's within-class discriminator (T2,
l.98-110), which enters no coverage.

A "draw" re-splits the isolates OUTSIDE the held-out lineage 75/25 into training and calibration (e3 l.137's cut) and
refits both classifiers; the held-out lineage is always the test set. Draw 0 of every lineage uses e3's own procedure and
seed (default_rng(0) after e3's random and sublineage splits, l.37 and l.128-137), so Lineage 2 draw 0 IS Table 1's
draw: the script aborts unless it reproduces every per-drug coverage of e3_shift_diagnosis.json["lineage2_blocked"]
(abs diff <= 1e-12) and numbers_e3.json's four lineage-2 means. Draws s >= 1 use default_rng(crc32("ICB2|<lineage>|<s>")).

Output: <out>/icb2_coverage.csv (lineage, draw, drug, variant, coverage) and <out>/icb2_run.json (sizes, priors,
skipped drugs with reasons, per-unit seconds, versions, input sha256, the reproduction check).

Usage: icb2_corrections.py --root INPUT_ROOT --out DIR --draws 0-29 [--lineages all|"Lineage 1,Lineage 3"] [--jobs K]
       icb2_corrections.py --root INPUT_ROOT --check-only        (login node: verbatim checks only, no fit)
"""
import argparse, hashlib, json, os, re, sys, time, zlib

E3 = "e3_shift_diagnosis.py"
VERB_RANGES = [(39, 39), (41, 71), (73, 81)]            # qlevel, variants, cov_stats
DRUG_BODY = [(86, 96), (112, 119)]                      # run_split's per-drug body without T2
SETUP = [(28, 29), (32, 37)]                            # DRUGS, ALPHA/MIN_AC; data, n, rng
SPLIT = [(128, 128), (130, 135)]                        # e3's random and sublineage draws (consume the stream)
L2LINE = 137                                            # the lineage-2 split; generalised to any lineage below
LINEAGES = ["Lineage 1", "Lineage 2", "Lineage 3", "Lineage 4"]


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def source(root):
    """e3's text, pinned: its sha256 must be the input manifest's (the file email 7 hashed); the executed lines ARE its lines"""
    path = os.path.join(root, "amrconf", "src", E3)
    man = dict(reversed(ln.split(None, 1)) for ln in open(os.path.join(root, "INPUTS.sha256")).read().splitlines() if ln.strip())
    if man.get(f"amrconf/src/{E3}") != sha256(path):
        sys.exit(f"icb2_corrections: ABORT {E3} does not match INPUTS.sha256")
    src = open(path).read().splitlines()
    lines = lambda a, b: src[a - 1:b]
    want = {39: "def qlevel(m,alpha=ALPHA): return min(np.ceil((m+1)*(1-alpha))/m,1.0)",
            41: "def variants(pca,yca,pte,yte,w_cov=None,prior_te=None,prior_ca=None):",
            73: "def cov_stats(inS,inR,yte):", 86: "        j=ALL.index(d); y=Y[:,j]",
            112: "        # covariate-shift weights from a domain classifier (cal=0 vs test=1)",
            119: "        V=variants(pca,y[CA],pte,y[TE],w_cov=w_cov,prior_te=pi_te,prior_ca=pi_ca)",
            128: "p=rng.permutation(n); a,b=int(.6*n),int(.8*n)",
            137: 'tem2=(lin=="Lineage 2"); rest2=np.where(~tem2)[0]; rp2=rng.permutation(rest2); cut2=int(.75*rest2.size)',
            37: "n=X.shape[0]; rng=np.random.default_rng(0)", 28: 'DRUGS=["RIF","RFB","INH","EMB","LEV","MXF","ETH","KAN","AMI"]   # well-characterised only',
            98: "        # T2: P(X|Y) invariance -- discriminate cal vs test WITHIN each class", 111: ""}
    bad = [k for k, v in want.items() if src[k - 1] != v]
    if bad:
        sys.exit(f"icb2_corrections: ABORT {E3} differs from the copied version at lines {bad}")
    return src, lines


def build_code(src, lines, out_dir):
    funcs = "\n".join(l for a, b in VERB_RANGES for l in lines(a, b))
    body = "\n".join(l for a, b in DRUG_BODY for l in lines(a, b))
    setup = "\n".join(l for a, b in SETUP for l in lines(a, b))
    split = "\n".join(l for a, b in SPLIT for l in lines(a, b))
    drugs = ("def run_drugs(tr,ca,te):\n    res={}\n    for d in DRUGS:\n" + body + "\n"
             "        res[d]={'coverage':{k:cov_stats(*v,y[TE])['coverage'] for k,v in V.items()},\n"
             "                'n_tr':int(TR.size),'n_cal':int(CA.size),'n_te':int(TE.size),'n_feat':int(cols.size),\n"
             "                'prior_cal':pi_ca,'prior_test':pi_te}\n    return res\n")
    return setup, funcs, drugs, split


STATE = {}


def load(root):
    """per process: e3's setup (data, DRUGS, ALPHA, rng), functions, and the RNG state at e3 l.137"""
    if STATE:
        return STATE
    import numpy as np, pandas as pd
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from scipy import sparse
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    from sklearn.model_selection import StratifiedKFold
    src, lines = source(root)
    setup, funcs, drugs, split = build_code(src, lines, None)
    g = {"np": np, "pd": pd, "sparse": sparse, "LogisticRegression": LogisticRegression,
         "roc_auc_score": roc_auc_score, "StratifiedKFold": StratifiedKFold, "OUT": os.path.join(root, "amrconf", "results")}
    exec(setup, g); exec(funcs, g); exec(drugs, g); exec(split, g)
    STATE.update(g=g, rng_state=g["rng"].bit_generator.state, l2line=lines(L2LINE, L2LINE)[0])
    return STATE


def one_unit(root, lineage, draw):
    import numpy as np
    S = load(root); g = S["g"]
    t0 = time.time()
    if draw == 0:     # e3's own procedure: the stream after e3's random and sublineage draws (state saved after l.135)
        g["rng"].bit_generator.state = S["rng_state"]
        exec(S["l2line"].replace('"Lineage 2"', repr(lineage).replace("'", '"')), g)
        rp2, cut2, rest2 = g["rp2"], g["cut2"], g["rest2"]
        tem2 = g["tem2"]
    else:
        tem2 = (g["lin"] == lineage); rest2 = np.where(~tem2)[0]
        r = np.random.default_rng(zlib.crc32(f"ICB2|{lineage}|{draw}".encode()))
        rp2 = r.permutation(rest2); cut2 = int(.75 * rest2.size)
    res = g["run_drugs"](rp2[:cut2], rp2[cut2:], np.where(tem2)[0])
    skipped = [d for d in g["DRUGS"] if d not in res]
    return dict(lineage=lineage, draw=draw, seconds=time.time() - t0, res=res, skipped=skipped)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out")
    ap.add_argument("--draws", default="0-0"); ap.add_argument("--lineages", default="all")
    ap.add_argument("--jobs", type=int, default=1); ap.add_argument("--check-only", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    src, lines = source(root)
    setup, funcs, drugs, split = build_code(src, lines, None)
    print(f"verbatim: {E3} l.{', l.'.join(f'{x}-{y}' for x, y in SETUP + VERB_RANGES + DRUG_BODY + SPLIT)} and l.{L2LINE} "
          f"(lineage generalised); T2 (l.98-110) left out")
    if a.check_only:
        compile(setup + "\n" + funcs + "\n" + drugs + "\n" + split, "<icb2>", "exec")
        print("check-only: verbatim copies match and compile; nothing fitted"); return
    lo, hi = map(int, a.draws.split("-"))
    lins = LINEAGES if a.lineages == "all" else [x.strip() for x in a.lineages.split(",")]
    units = [(L, s) for L in lins for s in range(lo, hi + 1)]
    os.makedirs(a.out, exist_ok=True)
    used = {r: sha256(os.path.join(root, r)) for r in ("amrconf/src/" + E3, "amrconf/results/cohort.parquet",
            "amrconf/results/labels_int8.npy", "amrconf/results/X_nonsyn.npz", "amrconf/results/e3_shift_diagnosis.json",
            "amrconf/paper/icbinb/numbers_e3.json")}
    t0 = time.time()
    if a.jobs > 1:
        from joblib import Parallel, delayed
        out = Parallel(n_jobs=a.jobs, backend="loky", verbose=0)(delayed(one_unit)(root, L, s) for L, s in units)
    else:
        out = [one_unit(root, L, s) for L, s in units]
    wall = time.time() - t0
    # ---- reproduction of Table 1 (Lineage 2, draw 0)
    rep = {"checked": False}
    l2 = [u for u in out if u["lineage"] == "Lineage 2" and u["draw"] == 0]
    if l2:
        e3 = json.load(open(os.path.join(root, "amrconf/results/e3_shift_diagnosis.json")))["lineage2_blocked"]
        ne3 = json.load(open(os.path.join(root, "amrconf/paper/icbinb/numbers_e3.json")))
        diffs = [abs(l2[0]["res"][d]["coverage"][v] - e3[d]["variants"][v]["coverage"]) for d in e3 for v in e3[d]["variants"]
                 if d in l2[0]["res"]]
        import numpy as np
        means = {v: float(np.mean([l2[0]["res"][d]["coverage"][v] for d in l2[0]["res"]])) for v in ne3_keys(ne3)}
        mdiff = max(abs(means[v] - ne3[f"lineage2_blocked|{v}"][0]) for v in means)
        rep = {"checked": True, "drugs": sorted(l2[0]["res"]), "max_abs_diff_per_drug": max(diffs) if diffs else None,
               "n_compared": len(diffs), "max_abs_diff_means": mdiff,
               "ok": len(diffs) == sum(len(e3[d]["variants"]) for d in e3) and max(diffs) <= 1e-12 and mdiff <= 1e-12}
        print(f"Table 1 reproduction (Lineage 2, draw 0): {rep['n_compared']} per-drug coverages, max abs diff "
              f"{rep['max_abs_diff_per_drug']!r}; four means max abs diff {mdiff!r}: {'OK' if rep['ok'] else 'FAILED'}")
    # ---- outputs
    import ast
    DRUGS = ast.literal_eval(src[27].split("=", 1)[1].split("#")[0].strip())        # e3 l.28
    rows = [(u["lineage"], u["draw"], d, v, c) for u in sorted(out, key=lambda u: (u["lineage"], u["draw"]))
            for d in sorted(u["res"], key=DRUGS.index) for v, c in u["res"][d]["coverage"].items()]
    with open(os.path.join(a.out, "icb2_coverage.csv"), "w") as fh:
        fh.write("lineage,draw,drug,variant,coverage\n")
        fh.writelines(f"{L},{s},{d},{v},{c!r}\n" for L, s, d, v, c in rows)
    import numpy, sklearn, scipy
    meta = {"generator": "icb2_corrections.py", "numpy": numpy.__version__, "sklearn": sklearn.__version__, "scipy": scipy.__version__,
            "draws": [lo, hi], "lineages": lins, "jobs": a.jobs, "wall_seconds": wall,
            "unit_seconds": {f"{u['lineage']}|{u['draw']}": u["seconds"] for u in out},
            "skipped": {f"{u['lineage']}|{u['draw']}": u["skipped"] for u in out if u["skipped"]},
            "sizes": {f"{u['lineage']}|{u['draw']}|{d}": {k: x for k, x in r.items() if k != "coverage"} for u in out for d, r in u["res"].items()},
            "table1_reproduction": rep, "inputs_sha256": used}
    json.dump(meta, open(os.path.join(a.out, "icb2_run.json"), "w"), indent=1)
    secs = [u["seconds"] for u in out]
    print(f"{len(out)} (lineage, draw) units, {len(rows)} rows; unit seconds mean {sum(secs) / len(secs):.1f} "
          f"max {max(secs):.1f}; wall {wall:.1f} s with {a.jobs} job(s); skipped drugs: {meta['skipped'] or 'none'}")
    if rep.get("checked") and not rep["ok"]:
        print("icb2_corrections: ABORT Lineage 2 draw 0 does not reproduce Table 1"); sys.exit(3)


def ne3_keys(ne3):
    return [k.split("|")[1] for k in ne3 if k.startswith("lineage2_blocked|")]


if __name__ == "__main__":
    main()
