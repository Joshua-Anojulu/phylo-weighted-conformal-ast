#!/usr/bin/env python3
"""icb4b_lingroup.py -- ICB-4b (FITS models: Slurm only): the screen and the coverage R^2 under LINEAGE-grouped validation.

Runs paper_numbers.py's own harnesses from the input copy's TEXT, UNCHANGED (pinned by INPUTS.sha256): F (l.46), the
groups g (l.48), loco (l.49-54: GradientBoostingRegressor(random_state=0) per fold, pooled out-of-fold predictions, one
r2_score as l.65) and loco_clf (l.98-104: GradientBoostingClassifier(random_state=0), pooled, one AUROC and one AP as
l.107-108). First it must REPRODUCE the paper's clade-grouped values (abort, exit 2, otherwise):
  (A) pred.y_cov.gbr.r2: email-7 r08's unrounded LOCO R^2 (within 1e-12) and PAPER_NUMBERS.json's 4-dp value;
  (B) screen.labelfree_auroc / _ap: PAPER_NUMBERS.json's 4-dp values.
Then ONLY THE GROUPS CHANGE: g becomes each pair's lineage group, i.e. a lineage clade with all of its sublineage clades
(a sublineage clade's lineage = the single lineage of its isolates, cohort.parquet), so each of the four folds holds out a
lineage together with all of its sublineages. The same functions then give \\NScreenLinGroupAuroc, \\NScreenLinGroupAP
(pooled over all pairs) and \\NRtwoLinGroup (pooled R^2 for mean coverage). The guard's negative controls run inside the
job: each perturbed expected value must make the (pure) guard function fire with its own message.

Usage: icb4b_lingroup.py --root INPUT_ROOT --out OUT.json       (Slurm)
       icb4b_lingroup.py --root INPUT_ROOT --check-only        (login node: text checks, no fit)
"""
import argparse, hashlib, json, os, re, sys

WANT = {46: 'F=sorted([c for c in p.columns if c.startswith("f_")])', 48: 'g=p["clade"].to_numpy()',
        49: 'def loco(cols,target,model="gbr"):', 51: "    for tr,te in LeaveOneGroupOut().split(X,y,g):",
        52: '        m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))', 54: '    return y,pr',
        65: '        N[f"pred.{target}.{name}.r2"]=round(float(r2_score(y,pr)),4)', 98: "ysev=(p.y_cov<0.70).astype(int).to_numpy()",
        99: "def loco_clf(cols):", 101: "    for tr,te in LeaveOneGroupOut().split(X,ysev,g):",
        103: '        pr[te]=GradientBoostingClassifier(random_state=0).fit(X[tr],ysev[tr]).predict_proba(X[te])[:,1]',
        104: "    return pr", 107: 'N["screen.labelfree_auroc"]=round(float(roc_auc_score(ysev,pr_lf)),4)',
        108: 'N["screen.labelfree_ap"]=round(float(average_precision_score(ysev,pr_lf)),4)'}
RELS = ["amrconf/src/paper_numbers.py", "amrconf/results/c2v2_pairs_s0.parquet", "amrconf/results/cohort.parquet",
        "amrconf/results/PAPER_NUMBERS.json", "nums_67/27baf2c/e7/logs/r08_sd_ratio.out"]


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def guard(r2, r2_e7, pn_r2, auc, ap, pn_auc, pn_ap):
    """the reproduction guard as a pure function: the list of failures (empty = pass)"""
    f = []
    if abs(r2 - r2_e7) > 1e-12 or round(r2, 4) != pn_r2:
        f.append(f"(A) clade-grouped loco(F, y_cov, gbr) R2 {r2!r}: email-7 r08 {r2_e7!r}, PAPER_NUMBERS {pn_r2}")
    if round(auc, 4) != pn_auc or round(ap, 4) != pn_ap:
        f.append(f"(B) clade-grouped loco_clf(F): AUROC {auc!r}, AP {ap!r} do not round to PAPER_NUMBERS {pn_auc}, {pn_ap}")
    return f


def texts(root):
    man = dict(reversed(ln.split(None, 1)) for ln in open(os.path.join(root, "INPUTS.sha256")).read().splitlines() if ln.strip())
    used = {}
    for rel in RELS:
        h = sha256(os.path.join(root, rel))
        if man.get(rel) != h:
            sys.exit(f"icb4b_lingroup: ABORT {rel} does not match INPUTS.sha256")
        used[rel] = h
    src = open(os.path.join(root, RELS[0])).read().splitlines()
    bad = [k for k, v in WANT.items() if src[k - 1] != v]
    if bad:
        sys.exit(f"icb4b_lingroup: ABORT paper_numbers.py differs from the expected text at lines {bad}")
    return used, src[45] + "\n" + src[47], "\n".join(src[48:54]), "\n".join(src[97:104])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out"); ap.add_argument("--check-only", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    used, head, loco, clf = texts(root)
    print("text: paper_numbers.py l.46, l.48, l.49-54 (loco), l.98-104 (loco_clf), all unchanged; metrics as l.65 and l.107-108")
    if a.check_only:
        compile("\n".join([head, loco, clf]), "<icb4b>", "exec")
        print("check-only: texts match and compile; nothing fitted"); return
    if not a.out:
        ap.error("--out is required")
    import numpy as np, pandas as pd, sklearn
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier
    from sklearn.linear_model import Ridge
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.metrics import r2_score, roc_auc_score, average_precision_score
    p = pd.read_parquet(os.path.join(root, RELS[1]))
    coh = pd.read_parquet(os.path.join(root, RELS[2])); keep = coh["in_cohort"].to_numpy()
    lin = coh.loc[keep, "Lineage"].to_numpy(); sub = coh.loc[keep, "Sublineage"].to_numpy()
    PN = json.load(open(os.path.join(root, RELS[3])))
    r2_e7 = float(re.search(r"^\s*LOCO R2 ([0-9.]+);", open(os.path.join(root, RELS[4])).read(), re.M).group(1))
    G = {"np": np, "p": p, "GradientBoostingRegressor": GradientBoostingRegressor, "GradientBoostingClassifier": GradientBoostingClassifier,
         "Ridge": Ridge, "LeaveOneGroupOut": LeaveOneGroupOut}
    for block in (head, loco, clf):
        exec(block, G)
    F, ysev = G["F"], G["ysev"]
    out = {}
    # (A) and (B): the paper's clade grouping, unchanged
    y, pr = G["loco"](F, "y_cov", "gbr"); r2_c = float(r2_score(y, pr))
    pr = G["loco_clf"](F); auc_c = float(roc_auc_score(ysev, pr)); ap_c = float(average_precision_score(ysev, pr))
    args = dict(r2=r2_c, r2_e7=r2_e7, pn_r2=PN["pred.y_cov.gbr.r2"], auc=auc_c, ap=ap_c, pn_auc=PN["screen.labelfree_auroc"],
                pn_ap=PN["screen.labelfree_ap"])
    fails = guard(**args)
    out["reproduce_clade_grouped"] = {"r2_y_cov_gbr": r2_c, "screen_auroc": auc_c, "screen_ap": ap_c}
    ctl = {"(A) r2_e7 + 1e-6": dict(args, r2_e7=r2_e7 + 1e-6), "(B) AUROC expected + 0.0001": dict(args, pn_auc=round(args["pn_auc"] + 0.0001, 4)),
           "(B) AP expected - 0.0001": dict(args, pn_ap=round(args["pn_ap"] - 0.0001, 4))}
    out["guard_negative_controls"] = {k: guard(**v) for k, v in ctl.items()}
    if not all(len(v) == 1 and v[0].startswith(k[:3]) for k, v in out["guard_negative_controls"].items()):
        fails.append(f"guard negative controls did not all fire: {out['guard_negative_controls']}")
    # only the groups change: each pair's lineage group
    kinds = dict(p.groupby("clade")["kind"].first())
    par = {}
    for c, k in kinds.items():
        ls = sorted(set(lin[(sub == c) if k == "sublineage" else (lin == c)]))
        if len(ls) != 1 or (k == "lineage" and ls[0] != c):
            fails.append(f"clade {c} ({k}) does not map to one lineage: {ls}")
        par[c] = ls[0]
    G["g"] = np.array([par[c] for c in p["clade"]])
    folds = [{"held_out": sorted(set(G["g"][te])), "pairs": int(len(te)), "severe": int(ysev[te].sum()),
              "train_classes": int(len(np.unique(ysev[tr])))}
             for tr, te in LeaveOneGroupOut().split(np.zeros((len(p), 1)), ysev, G["g"])]
    y, pr = G["loco"](F, "y_cov", "gbr"); r2_l = float(r2_score(y, pr))
    pr = G["loco_clf"](F); auc_l = float(roc_auc_score(ysev, pr)); ap_l = float(average_precision_score(ysev, pr))
    out.update(lineage_grouped={"screen_auroc": auc_l, "screen_ap": ap_l, "r2_y_cov_gbr": r2_l}, folds=folds,
               single_class_training_folds=sum(f["train_classes"] < 2 for f in folds), n_pairs=int(len(p)),
               n_severe=int(ysev.sum()), sklearn=sklearn.__version__, numpy=np.__version__, inputs_sha256=used, checks_failed=fails)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    for f in fails:
        print(f"ABORT icb4b_lingroup: {f}")
    print(f"clade-grouped (reproduced): R2 {r2_c!r}, AUROC {auc_c!r}, AP {ap_c!r}; guard negative controls "
          f"{sum(1 for v in out['guard_negative_controls'].values() if len(v) == 1)} of {len(ctl)} fire")
    print(f"lineage-grouped ({len(folds)} folds): AUROC {auc_l!r}, AP {ap_l!r}, R2 {r2_l!r}; single-class training folds "
          f"{out['single_class_training_folds']}")
    sys.exit(2 if fails else 0)


if __name__ == "__main__":
    main()
