#!/usr/bin/env python3
"""icb5_treekernel.py -- ICB-5: coverage of tree-kernel-weighted split conformal prediction. FITS the base classifier: Slurm only.

Setting = Table 1's lineage-2 column: e3_shift_diagnosis.py's own split (default_rng(0) stream, l.128-138), its nine drugs and
alpha, its per-drug logistic regression (l.86-96), all run from the input copy's TEXT, pinned by INPUTS.sha256. Distances
are Figure 2's: the cophenetic (patristic) matrix with weight_degeneracy.py's lookup (l.21-22), as float64.
Weights for test isolate t and calibration isolate i: w_i(t) = exp(-d(t, x_i) / h). The weighted quantile is Tibshirani et
al. (2019) Eq. 7: q(t) = the smallest calibration score s such that the normalised weight of the calibration scores <= s
reaches 1 - alpha; mass that cannot reach it puts q(t) at +inf (the full set {S, R}).
  version A: the test point's own weight exp(-d(t,t)/h) = exp(0) = 1 is in the normalisation, at +inf (Tibshirani Eq. 7;
             Barber et al. 2023);
  version B: normalised over the calibration points only.
Bandwidths: Figure 2's narrow and wide multiples (weight_degeneracy.json, lineage2_holdout|tree) of the median patristic
distance between this split's test and calibration isolates; sensitivity: Figure 2's own absolute bandwidths (multiple x the
median of Figure 2's sampled block, wd_replay_l2.json). Sets: S in the set iff p_hat(R) <= q(t), R iff 1 - p_hat(R) <= q(t)
(e3 l.45, l.48). Reported per drug and as the mean over the nine drugs: coverage and the shares of singleton, empty and
full {S, R} sets.
GUARDS (abort, exit 2): (1) e3's three label-only variants (vanilla, class-conditional, oracle prior; variants(), l.41-71)
recomputed on the refit reproduce e3_shift_diagnosis.json["lineage2_blocked"] within 1e-12 for every drug; (2) with all
weights equal to 1, version A's q(t) equals the textbook conformal quantile (the ceil((n+1)(1-alpha))-th smallest score,
from an independent sort) and version B's the ceil(n(1-alpha))-th, for every test point; (3) the three shares sum to 1. The
guard's negative controls run inside the job (perturbed expected values must make it fire).
Also recorded: e3's np.quantile(level=k/n, method="higher") picks the (k+1)-th smallest score, one rank above the textbook k-th,
so the textbook vanilla (version A with uniform weights) is reported beside e3's vanilla for a like-for-like comparison.

Usage: icb5_treekernel.py --root INPUT_ROOT --out OUT.json        (Slurm)
       icb5_treekernel.py --root INPUT_ROOT --check-only         (login node: text checks, no fit)
"""
import argparse, hashlib, json, os, sys

E3 = "amrconf/src/e3_shift_diagnosis.py"; WDP = "amrconf/src/weight_degeneracy.py"
RELS = [E3, WDP, "amrconf/results/cohort.parquet", "amrconf/results/labels_int8.npy", "amrconf/results/X_nonsyn.npz",
        "amrconf/results/cophenetic_f32.npy", "amrconf/results/e3_shift_diagnosis.json", "amrconf/results/weight_degeneracy.json"]
DERIVED = ["derived/wd_replay_l2.json"]
E3_WANT = {28: 'DRUGS=["RIF","RFB","INH","EMB","LEV","MXF","ETH","KAN","AMI"]   # well-characterised only',
           29: "ALPHA=0.10; MIN_AC=5", 37: "n=X.shape[0]; rng=np.random.default_rng(0)",
           39: "def qlevel(m,alpha=ALPHA): return min(np.ceil((m+1)*(1-alpha))/m,1.0)",
           41: "def variants(pca,yca,pte,yte,w_cov=None,prior_te=None,prior_ca=None):", 45: "    sS_te=pte; sR_te=1-pte                   # score for hypothesising S / R",
           48: '    out["vanilla"]=(sS_te<=q, sR_te<=q)', 71: "    return out", 73: "def cov_stats(inS,inR,yte):",
           86: "        j=ALL.index(d); y=Y[:,j]", 96: "        pi_ca=float((y[CA]==1).mean()); pi_te=float((y[TE]==1).mean())",
           128: "p=rng.permutation(n); a,b=int(.6*n),int(.8*n)",
           137: 'tem2=(lin=="Lineage 2"); rest2=np.where(~tem2)[0]; rp2=rng.permutation(rest2); cut2=int(.75*rest2.size)',
           138: 'splits["lineage2_blocked"]=(rp2[:cut2],rp2[cut2:],np.where(tem2)[0])'}
WD_WANT = {21: 'tidx=coh.loc[keep,"tree_idx"].to_numpy()', 22: 'M=np.load(f"{OUT}/cophenetic_f32.npy",mmap_mode="r")',
           23: "Dtree=np.ascontiguousarray(M[np.ix_(tidx,tidx)]).astype(np.float64)"}


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def weighted_q(ss, W, alpha, test_mass, np, off_by_one=False):
    """Tibshirani Eq. 7, vectorised over test points: ss = calibration scores sorted ascending (n,), W = weights (m, n) in the
    same order, test_mass = (m,) weight at +inf (1 for version A, 0 for version B). q = ss[j] for the first j whose cumulative
    weight reaches (1 - alpha) x total, +inf if none. off_by_one exists only for the negative control."""
    C = np.cumsum(W, 1)
    total = C[:, -1] + test_mass          # the same sequential sums as the cumulative weights (no pairwise-sum ulp gap)
    j = (C < ((1 - alpha) * total)[:, None]).sum(1) + (1 if off_by_one else 0)
    return np.where(j >= ss.size, np.inf, ss[np.minimum(j, ss.size - 1)])


def sets(q, pte, yte, np):
    inS = pte <= q; inR = (1 - pte) <= q
    size = inS.astype(int) + inR.astype(int)
    cov = float(np.where(yte == 1, inR, inS).mean())
    return dict(coverage=cov, singleton=float((size == 1).mean()), empty=float((size == 0).mean()), full=float((size == 2).mean()),
                q_inf=float(np.isinf(q).mean()))


def guard(repro_max_diff, uniform_ok, shares_ok):
    f = []
    if not (repro_max_diff <= 1e-12):
        f.append(f"(1) the refit does not reproduce Table 1's label-only variants (max abs diff {repro_max_diff!r})")
    if not uniform_ok:
        f.append("(2) uniform weights do not give the textbook conformal quantile")
    if not shares_ok:
        f.append("(3) singleton + empty + full shares do not sum to 1")
    return f


def texts(root):
    man = {}
    for mf, base in (("INPUTS.sha256", ""), ("derived/DERIVED.sha256", "derived/")):
        for ln in open(os.path.join(root, mf)).read().splitlines():
            if ln.strip():
                h, r = ln.split(None, 1); man[base + r.strip()] = h
    used = {}
    for rel in RELS + DERIVED:
        h = sha256(os.path.join(root, rel))
        if man.get(rel) != h:
            sys.exit(f"icb5_treekernel: ABORT {rel} does not match its manifest")
        used[rel] = h
    e3 = open(os.path.join(root, E3)).read().splitlines(); wd = open(os.path.join(root, WDP)).read().splitlines()
    bad = [f"e3 l.{k}" for k, v in E3_WANT.items() if e3[k - 1] != v] + [f"weight_degeneracy l.{k}" for k, v in WD_WANT.items() if wd[k - 1] != v]
    if bad:
        sys.exit(f"icb5_treekernel: ABORT the code differs from the expected text at {bad}")
    L = lambda a, b: "\n".join(e3[a - 1:b])
    setup = L(28, 29) + "\n" + L(32, 37) + "\n" + wd[20] + "\n" + wd[21]
    funcs = L(39, 39) + "\n" + L(41, 71) + "\n" + L(73, 81)
    split = L(127, 127) + "\n" + L(128, 128) + "\n" + L(130, 135) + "\n" + L(137, 138)
    fit = ("def fit_drug(d,tr,ca,te):\n    for _ in (0,):\n" + "\n".join(e3[85:96]) + "\n"
           "        return dict(TR=TR,CA=CA,TE=TE,y=y,pca=pca,pte=pte,pi_ca=pi_ca,pi_te=pi_te,cols=cols)\n    return None\n")
    return used, setup, funcs, split, fit


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out"); ap.add_argument("--check-only", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    used, setup, funcs, split, fit = texts(root)
    print("text: e3_shift_diagnosis.py l.28-29, l.32-37, l.39-81, l.86-96 (inside fit_drug), l.127-128, l.130-135, l.137-138; "
          "weight_degeneracy.py l.21-22; all unchanged")
    if a.check_only:
        compile("\n".join([setup, funcs, split, fit]), "<icb5>", "exec")
        print("check-only: texts match and compile; nothing fitted"); return
    if not a.out:
        ap.error("--out is required")
    import numpy as np, pandas as pd, sklearn
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from scipy import sparse
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    G = {"np": np, "pd": pd, "sparse": sparse, "LogisticRegression": LogisticRegression, "roc_auc_score": roc_auc_score,
         "OUT": os.path.join(root, "amrconf", "results")}
    for block in (setup, funcs, split, fit):
        exec(block, G)
    tr, ca, te = G["splits"]["lineage2_blocked"]
    E3J = json.load(open(os.path.join(root, RELS[6])))["lineage2_blocked"]
    WD = json.load(open(os.path.join(root, RELS[7])))["lineage2_holdout|tree"]
    RP = json.load(open(os.path.join(root, DERIVED[0])))
    mults = {"narrow": min(r["bandwidth_x_median"] for r in WD), "wide": max(r["bandwidth_x_median"] for r in WD)}
    tidx, M, ALPHA = G["tidx"], G["M"], G["ALPHA"]
    med_split = float(np.median(np.asarray(M[np.ix_(tidx[te], tidx[ca])], dtype=np.float64)))
    h = {k: v * med_split for k, v in mults.items()}
    h_fig2 = {k: v * RP["median_patristic"] for k, v in mults.items()}
    per, repro, uni_ok, sh_ok = {}, [], True, True
    for d in G["DRUGS"]:
        r = G["fit_drug"](d, tr, ca, te)
        if r is None:
            per[d] = {"skipped": True}; continue
        y, TR, CA, TE, pca, pte = r["y"], r["TR"], r["CA"], r["TE"], r["pca"], r["pte"]
        V = G["variants"](pca, y[CA], pte, y[TE], prior_te=r["pi_te"], prior_ca=r["pi_ca"])
        cs = {k: G["cov_stats"](*v, y[TE])["coverage"] for k, v in V.items()}
        repro += [abs(cs[k] - E3J[d]["variants"][k]["coverage"]) for k in cs]
        s_ca = np.where(y[CA] == 1, 1 - pca, pca)
        o = np.argsort(s_ca, kind="stable"); ss = s_ca[o]
        D = np.asarray(M[np.ix_(tidx[TE], tidx[CA])], dtype=np.float64)[:, o]
        yte = y[TE]
        # (2) uniform-weight limit against an independent textbook quantile
        n = ss.size; ones = np.ones_like(D)
        kA = int(np.ceil((n + 1) * (1 - ALPHA))); kB = int(np.ceil(n * (1 - ALPHA)))
        qA_text = np.inf if kA > n else ss[kA - 1]; qB_text = ss[kB - 1]
        qA_u = weighted_q(ss, ones, ALPHA, np.ones(D.shape[0]), np); qB_u = weighted_q(ss, ones, ALPHA, np.zeros(D.shape[0]), np)
        uni_ok &= bool(np.all(qA_u == qA_text) and np.all(qB_u == qB_text))
        rec = {"n_cal": int(n), "n_te": int(TE.size), "e3_variants_recomputed": cs,
               "textbook_vanilla": sets(np.full(D.shape[0], qA_text), pte, yte, np),
               "e3_quantile_rank_minus_textbook_rank": int(np.searchsorted(ss, np.quantile(s_ca, G["qlevel"](n), method="higher"), side="left") + 1 - kA)}
        for tag, hh in (("split_median", h), ("figure2_h", h_fig2)):
            for bw, hv in hh.items():
                W = np.exp(-D / hv)
                for ver, tm in (("A", np.ones(D.shape[0])), ("B", np.zeros(D.shape[0]))):
                    st = sets(weighted_q(ss, W, ALPHA, tm, np), pte, yte, np)
                    sh_ok &= abs(st["singleton"] + st["empty"] + st["full"] - 1) < 1e-12
                    rec[f"{ver}|{bw}|{tag}"] = st
        per[d] = rec
        print(f"{d}: n_cal {n}, n_te {TE.size}; e3 variants reproduced (max diff {max(repro[-3:]):.1e}); "
              f"A narrow cov {rec['A|narrow|split_median']['coverage']:.4f}", flush=True)
    keys = [k for k in per[G["DRUGS"][0]] if k.count("|") == 2]
    done = [d for d in G["DRUGS"] if not per[d].get("skipped")]
    means = {k: {m: float(np.mean([per[d][k][m] for d in done])) for m in ("coverage", "singleton", "empty", "full", "q_inf")} for k in keys}
    means["textbook_vanilla"] = {m: float(np.mean([per[d]["textbook_vanilla"][m] for d in done])) for m in ("coverage", "singleton", "empty", "full")}
    means["e3_vanilla"] = {"coverage": float(np.mean([E3J[d]["variants"]["vanilla"]["coverage"] for d in done]))}
    fails = guard(max(repro) if repro else float("nan"), uni_ok, sh_ok)
    ctl = {"(1) reproduction": guard(1e-6, uni_ok, sh_ok), "(2) uniform": guard(max(repro), False, sh_ok), "(3) shares": guard(max(repro), uni_ok, False)}
    if not all(len(v) == 1 and v[0].startswith(k[:3]) for k, v in ctl.items()):
        fails.append(f"guard negative controls did not all fire: {ctl}")
    out = {"drugs": done, "skipped": [d for d in G["DRUGS"] if per[d].get("skipped")], "alpha": ALPHA,
           "bandwidth_multiples": mults, "median_patristic_split": med_split, "median_patristic_figure2": RP["median_patristic"],
           "h_split_median": h, "h_figure2": h_fig2, "means_over_drugs": means, "per_drug": per,
           "reproduction_max_abs_diff": max(repro) if repro else None, "uniform_limit_ok": uni_ok, "shares_ok": sh_ok,
           "guard_negative_controls": ctl, "checks_failed": fails, "sklearn": sklearn.__version__, "numpy": np.__version__,
           "inputs_sha256": used}
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    for f in fails:
        print(f"ABORT icb5_treekernel: {f}")
    A = means["A|narrow|split_median"]
    print(f"mean over {len(done)} drugs: version A narrow coverage {A['coverage']!r}, not singleton {A['empty'] + A['full']!r}; "
          f"e3 vanilla {means['e3_vanilla']['coverage']!r}, textbook vanilla {means['textbook_vanilla']['coverage']!r}; "
          f"guard negative controls {sum(1 for v in ctl.values() if len(v) == 1)} of {len(ctl)} fire")
    sys.exit(2 if fails else 0)


if __name__ == "__main__":
    main()
