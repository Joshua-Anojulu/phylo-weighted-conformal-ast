#!/usr/bin/env python3
"""icb3_screen.py -- ICB-3, the part with NO fitted model (login node allowed): the one-feature screen.

Ranks the (drug, clade) pairs by f_minscore_mean, the mean of min(p, 1-p) over the pair's unlabelled test batch (the
canonical pairs file), and scores it against the severity label exactly as paper_numbers.py scores the trained screen
(screen.labelfree_auroc / screen.labelfree_ap):
  * the label and the folds are paper_numbers.py's own: ysev = (y_cov < 0.70) (l.98), LeaveOneGroupOut by clade (l.48);
  * the harness is paper_numbers.py's loco_clf (l.99-104) run from the input copy's TEXT (pinned by INPUTS.sha256), with
    ONE line changed: the fitted classifier (l.103) becomes the identity rule pr[te]=X[te][:,0], i.e. each held-out
    clade's score is its own feature value (nothing is learned from the other clades). So the LOCO out-of-fold scores
    are pooled over all pairs and ONE AUROC and ONE AP are computed with l.107-108's calls, as for the trained screen;
  * the single-class branch of l.102 is counted (it would replace a clade's score by a base rate).
Guards (abort, exit 2): the harness scores equal the raw feature; sklearn's AUROC and AP equal independent pure-Python
implementations (Mann-Whitney with ties at 1/2; step-wise AP over distinct thresholds, as sklearn defines it) within 1e-12.
--mutate flip|ap-step breaks the independent implementation, for the negative control.

Usage: icb3_screen.py --root INPUT_ROOT --out OUT.json [--mutate flip|ap-step]
"""
import argparse, hashlib, json, os, re, sys


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def auc_mw(y, s, flip=False):
    """Mann-Whitney AUROC: P(score of a positive > score of a negative), ties count 1/2"""
    pos = [v for v, t in zip(s, y) if t == 1]; neg = [v for v, t in zip(s, y) if t == 0]
    if flip:
        pos, neg = neg, pos
    win = 0.0
    for a in pos:
        for b in neg:
            win += 1.0 if a > b else 0.5 if a == b else 0.0
    return win / (len(pos) * len(neg))


def ap_step(y, s, broken=False):
    """average precision as sklearn defines it: sum over distinct thresholds (descending) of (R_k - R_{k-1}) * P_k"""
    order = sorted(range(len(s)), key=lambda i: -s[i])
    P = sum(y); tp = fp = 0; ap = 0.0; r_prev = 0.0; i = 0
    while i < len(order):
        j = i
        while j < len(order) and s[order[j]] == s[order[i]]:
            tp += y[order[j]]; fp += 1 - y[order[j]]; j += 1
        r = tp / P; prec = tp / (tp + fp)
        ap += (r - (0.0 if broken else r_prev)) * prec; r_prev = r; i = j
    return ap


def main():
    ap_ = argparse.ArgumentParser()
    ap_.add_argument("--root", required=True); ap_.add_argument("--out", required=True)
    ap_.add_argument("--mutate", choices=("flip", "ap-step"))
    a = ap_.parse_args()
    root = os.path.abspath(a.root)
    man = dict(reversed(ln.split(None, 1)) for ln in open(os.path.join(root, "INPUTS.sha256")).read().splitlines() if ln.strip())
    pnp = os.path.join(root, "amrconf", "src", "paper_numbers.py")
    pqp = os.path.join(root, "amrconf", "results", "c2v2_pairs_s0.parquet")
    for rel, p in (("amrconf/src/paper_numbers.py", pnp), ("amrconf/results/c2v2_pairs_s0.parquet", pqp)):
        if man.get(rel) != sha256(p):
            sys.exit(f"icb3_screen: ABORT {rel} does not match INPUTS.sha256")
    src = open(pnp).read().splitlines()
    want = {46: 'F=sorted([c for c in p.columns if c.startswith("f_")])', 48: 'g=p["clade"].to_numpy()',
            98: "ysev=(p.y_cov<0.70).astype(int).to_numpy()", 99: "def loco_clf(cols):",
            103: '        pr[te]=GradientBoostingClassifier(random_state=0).fit(X[tr],ysev[tr]).predict_proba(X[te])[:,1]',
            104: "    return pr", 107: 'N["screen.labelfree_auroc"]=round(float(roc_auc_score(ysev,pr_lf)),4)',
            108: 'N["screen.labelfree_ap"]=round(float(average_precision_score(ysev,pr_lf)),4)'}
    bad = [k for k, v in want.items() if src[k - 1] != v]
    if bad:
        sys.exit(f"icb3_screen: ABORT paper_numbers.py differs from the expected text at lines {bad}")
    harness = "\n".join(src[97:104]).replace(src[102], "        pr[te]=X[te][:,0]   # identity rule: the held-out clade's own feature value")
    harness = harness.replace("    for tr,te in LeaveOneGroupOut().split(X,ysev,g):\n        if len(np.unique(ysev[tr]))<2: pr[te]=ysev[tr].mean(); continue",
                              "    for tr,te in LeaveOneGroupOut().split(X,ysev,g):\n        if len(np.unique(ysev[tr]))<2: SINGLE.append(1); pr[te]=ysev[tr].mean(); continue")
    if "SINGLE.append" not in harness or "identity rule" not in harness:
        sys.exit("icb3_screen: ABORT could not build the harness from paper_numbers.py l.98-104")

    import numpy as np, pandas as pd
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.metrics import roc_auc_score, average_precision_score
    p = pd.read_parquet(pqp)
    g = {"np": np, "p": p, "LeaveOneGroupOut": LeaveOneGroupOut, "SINGLE": []}
    exec(src[45] + "\n" + src[47], g)                       # F (l.46) and g (l.48), paper_numbers' own lines
    exec(harness, g)                                         # ysev (l.98) and loco_clf with the identity rule
    feat = "f_minscore_mean"
    pr_mu = g["loco_clf"]([feat])
    ysev = g["ysev"]
    if not np.array_equal(pr_mu, p[feat].to_numpy()):
        sys.exit("icb3_screen: ABORT the harness scores differ from the raw feature")
    auc = float(roc_auc_score(ysev, pr_mu)); ap = float(average_precision_score(ysev, pr_mu))   # l.107-108's calls
    y = [int(v) for v in ysev]; s = [float(v) for v in pr_mu]
    auc2 = auc_mw(y, s, flip=a.mutate == "flip"); ap2 = ap_step(y, s, broken=a.mutate == "ap-step")
    fails = []
    if abs(auc - auc2) > 1e-12:
        fails.append(f"AUROC: sklearn {auc!r} != Mann-Whitney {auc2!r}")
    if abs(ap - ap2) > 1e-12:
        fails.append(f"AP: sklearn {ap!r} != step-wise {ap2!r}")
    out = {"feature": feat, "n_pairs": int(len(p)), "n_severe": int(ysev.sum()), "n_clades": int(p.clade.nunique()),
           "auroc": auc, "ap": ap, "auroc_independent": auc2, "ap_independent": ap2,
           "single_class_folds": len(g["SINGLE"]), "ties_in_score": int(len(s) - len(set(s))),
           "harness": "paper_numbers.py l.98-104 with l.103 replaced by the identity rule; metrics as l.107-108",
           "inputs_sha256": {"amrconf/src/paper_numbers.py": sha256(pnp), "amrconf/results/c2v2_pairs_s0.parquet": sha256(pqp)},
           "mutate": a.mutate}
    if fails:
        for f in fails:
            print(f"ABORT icb3_screen: {f}")
        sys.exit(2)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"icb3_screen: one-feature rule ({feat}) over {out['n_pairs']} pairs ({out['n_severe']} severe, {out['n_clades']} clades): "
          f"AUROC {auc!r}, AP {ap!r}; independent implementations agree; single-class folds {out['single_class_folds']}; "
          f"tied scores {out['ties_in_score']}")


if __name__ == "__main__":
    main()
