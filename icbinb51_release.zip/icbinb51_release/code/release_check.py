#!/usr/bin/env python3
"""release_check.py -- rebuild numbers_icbinb.tex from this release bundle and run the release build's negative controls.

Run from anywhere; the bundle is the folder above code/ unless --bundle says otherwise. Fits nothing; about a minute.

  1. MANIFEST.sha256: every file of the bundle is listed and matches (the manifest itself excepted).
  2. Positive control: gen_numbers_icbinb.py --release over inputs/ (with the record's --hold list) exits 0 and writes
     numbers_icbinb.tex and provenance_icbinb.tsv byte-identical to expected/ and to the sha256 the internal build
     recorded in inputs/release/RELEASE_RECORD.json.
  3. Negative controls, each on a fresh copy of inputs/ and code/: one perturbation, then the generator must exit 2,
     print its own line "ABORT gen_numbers_icbinb: <GUARD>: <MACRO>:" for the expected guard and macro, and write nothing.

Usage: release_check.py [--bundle DIR] [--scratch DIR]
"""
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def rehash(root, rel):
    """Update rel's manifest entry, so that a value guard (not the manifest guard) has to catch the change."""
    der = rel.startswith("derived/")
    man = os.path.join(root, "derived/DERIVED.sha256" if der else "INPUTS.sha256")
    key = rel[len("derived/"):] if der else rel
    lines = open(man).read().splitlines()
    hit = [i for i, ln in enumerate(lines) if ln.split(None, 1)[1].strip() == key]
    assert len(hit) == 1, f"control setup: {key} is listed {len(hit)} times in {man}"
    lines[hit[0]] = f"{sha256(os.path.join(root, rel))}  {key}"
    open(man, "w").write("\n".join(lines) + "\n")


def edit_json(root, rel, fn):
    p = os.path.join(root, rel)
    d = json.load(open(p))
    fn(d)
    json.dump(d, open(p, "w"), indent=1)


def run(code, root, outdir, hold):
    os.makedirs(outdir, exist_ok=True)
    tex, prov = os.path.join(outdir, "numbers_icbinb.tex"), os.path.join(outdir, "provenance_icbinb.tsv")
    cmd = [sys.executable, os.path.join(code, "gen_numbers_icbinb.py"), "--release", "--root", root,
           "--out-tex", tex, "--out-prov", prov]
    if hold:
        cmd += ["--hold", hold]
    r = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    return r.returncode, r.stdout + r.stderr, tex, prov


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", default=os.path.dirname(HERE))
    ap.add_argument("--scratch")
    a = ap.parse_args()
    B = os.path.abspath(a.bundle)
    scratch = a.scratch or tempfile.mkdtemp(prefix="icbinb51_release_check_")
    os.makedirs(scratch, exist_ok=True)
    results = []

    # 1. manifest
    listed = {}
    for ln in open(os.path.join(B, "MANIFEST.sha256")).read().splitlines():
        if ln.strip():
            h, rel = ln.split(None, 1)
            listed[rel.strip()] = h
    present = set()
    for dp, dn, fn in os.walk(B):
        for f in fn:
            present.add(os.path.relpath(os.path.join(dp, f), B))
    present.discard("MANIFEST.sha256")
    bad = sorted(r for r, h in listed.items() if r not in present or sha256(os.path.join(B, r)) != h)
    unlisted = sorted(present - set(listed))
    ok = not bad and not unlisted
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'} manifest: {len(listed)} files listed; mismatched or missing {len(bad)} {bad[:5]}; "
          f"unlisted {len(unlisted)} {unlisted[:5]}")

    rec = json.load(open(os.path.join(B, "inputs", "release", "RELEASE_RECORD.json")))
    hold = ",".join(rec.get("hold", []))

    # 2. positive control
    rc, out, tex, prov = run(os.path.join(B, "code"), os.path.join(B, "inputs"), os.path.join(scratch, "pos"), hold)
    same = (rc == 0 and os.path.exists(tex) and os.path.exists(prov)
            and open(tex, "rb").read() == open(os.path.join(B, "expected", "numbers_icbinb.tex"), "rb").read()
            and open(prov, "rb").read() == open(os.path.join(B, "expected", "provenance_icbinb.tsv"), "rb").read()
            and sha256(tex) == rec["outputs_sha256"]["numbers_icbinb.tex"]
            and sha256(prov) == rec["outputs_sha256"]["provenance_icbinb.tsv"])
    results.append(same)
    print(f"{'PASS' if same else 'FAIL'} positive control: release build (--hold {hold or '-'}) -> rc={rc}; numbers_icbinb.tex and "
          f"provenance_icbinb.tsv byte-identical to expected/ and to the internal build's recorded sha256: {same}")
    for ln in out.splitlines():
        if ln.startswith(("gen_numbers_icbinb:", "  note: release build", "  note: INPUT-DRIFT", "  HELD", "wrote", "ABORT")):
            print("      " + ln)

    # 3. negative controls
    PNJ = "amrconf/results/PAPER_NUMBERS.json"
    R12E = "nums_67/27baf2c/e7/logs/r12e_identity_1e6.out"

    def r12e_one(d):
        key = [k for k in d["replay"]["e7_line"] if k.startswith(R12E + " :: ")]
        assert len(key) == 1, "control setup: the record has no single r12e line"
        d["replay"]["e7_line"][key[0]]["first"][3] = "1"

    TKJ = "derived/icb5_treekernel.json"

    def gain_low(d):
        m = d["means_over_drugs"]
        a, tv = m["A|narrow|split_median"], m["textbook_vanilla"]
        a["full"] = tv["full"] + 0.5 * (a["coverage"] - tv["coverage"])

    def empty_up(d):
        a = d["means_over_drugs"]["A|narrow|split_median"]
        a["empty"] = a["empty"] + 0.001

    def append_comment(code):
        with open(os.path.join(code, "gen_numbers_icbinb.py"), "a") as fh:
            fh.write("# a changed generator\n")

    controls = [
        # (name, perturb(inputs_root), file whose manifest entry is updated or None, perturb(code_dir), extra hold, guard, macro)
        ("spec value: PAPER_NUMBERS.json screen.labelfree_auroc 0.9052 -> 0.9152 (manifest updated)",
         lambda r: edit_json(r, PNJ, lambda d: d.__setitem__("screen.labelfree_auroc", 0.9152)), PNJ, None, "", "SPEC", "NScreenAuroc"),
        ("manifest: cal_variance.json edited, INPUTS.sha256 not updated",
         lambda r: edit_json(r, "amrconf/results/cal_variance.json", lambda d: d["drugs"]["RIF"]["qhat"].__setitem__("min", 0.2132)),
         None, None, "", "INPUT-MANIFEST", "-"),
        ("release: cohort_report.json gains an unused key (manifest updated; no macro changes)",
         lambda r: edit_json(r, "amrconf/results/cohort_report.json", lambda d: d.__setitem__("_control", 1)),
         "amrconf/results/cohort_report.json", None, "", "RELEASE", "-"),
        ("replayed value: the record's identity-check mismatch count 0 -> 1 (manifest updated)",
         lambda r: edit_json(r, "release/RELEASE_RECORD.json", r12e_one), "release/RELEASE_RECORD.json", None, "", "EMAIL-7", "NMismatch"),
        ("derived value: icb3_screen.json AUROC +0.001 (manifest updated)",
         lambda r: edit_json(r, "derived/icb3_screen.json", lambda d: d.__setitem__("auroc", d["auroc"] + 0.001)),
         "derived/icb3_screen.json", None, "", "CROSS", "NScreenMeanUncAuroc"),
        ("generator: one comment line appended to gen_numbers_icbinb.py", lambda r: None, None, append_comment, "", "COMMIT", "-"),
        ("stale hold: --hold NCovMedian, which passes every guard", lambda r: None, None, None, "NCovMedian", "STALE-HOLD", "NCovMedian"),
        ("gain: the tree-kernel run's full share set so that its rise is half the coverage gain (manifest updated)",
         lambda r: edit_json(r, TKJ, gain_low), TKJ, None, "", "GAIN", "NTreeKernelFullPct"),
        ("shares: the tree-kernel run's empty share +0.001, so empty + full no longer equals 1 - singleton (manifest updated)",
         lambda r: edit_json(r, TKJ, empty_up), TKJ, None, "", "SHARES", "NTreeKernelEmptyPct"),
    ]
    for i, (name, perturb, remanifest, code_perturb, xhold, guard, macro) in enumerate(controls):
        base = os.path.join(scratch, f"c{i + 1}")
        if os.path.exists(base):
            shutil.rmtree(base)
        shutil.copytree(os.path.join(B, "inputs"), os.path.join(base, "inputs"))
        shutil.copytree(os.path.join(B, "code"), os.path.join(base, "code"))
        root, code = os.path.join(base, "inputs"), os.path.join(base, "code")
        perturb(root)
        if remanifest:
            rehash(root, remanifest)
        if code_perturb:
            code_perturb(code)
        rc, out, tex, prov = run(code, root, os.path.join(base, "out"), ",".join(h for h in (hold, xhold) if h))
        want = f"ABORT gen_numbers_icbinb: {guard}: {macro}:"
        hit = [ln for ln in out.splitlines() if ln.startswith(want)]
        ok = rc == 2 and bool(hit) and not os.path.exists(tex) and not os.path.exists(prov)
        results.append(ok)
        print(f"{'PASS' if ok else 'FAIL'} control {i + 1}: {name}\n      rc={rc}; fired: {hit[0] if hit else '(not fired)'}")
        shutil.rmtree(base)
    if not a.scratch:
        shutil.rmtree(scratch)
    print(f"RESULT | release_check | {sum(results)} of {len(results)} PASS")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
