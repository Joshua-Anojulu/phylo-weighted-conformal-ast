#!/usr/bin/env python3
"""icb4a_nested.py -- ICB-4a (no fitted model; login node allowed): nested clades in the screen's leave-one-clade-out folds.

paper_numbers.py builds the screen's folds (loco_clf, l.99-104) and the R^2 folds (loco, l.49-54) with
LeaveOneGroupOut().split(X, y, g) and g = p["clade"] (l.48): a fold holds out the rows of ONE clade label and trains on
every other row. A clade's isolates are those of the c2v2 builder (c2v2_coverage_prediction.py l.43): a sublineage clade
= the isolates whose sublineage label is exactly that sublineage; a lineage clade = every isolate of the lineage, so it
CONTAINS the isolates of its sublineage clades. Two clades "share isolates" if these sets intersect.

\\NNestedPairs counts the held-out clades for which a clade sharing isolates (its parent lineage, or a child sublineage)
stayed in training. Counted two independent ways, which must agree (abort, exit 2, otherwise):
  (1) fold-based: iterate sklearn's LeaveOneGroupOut over the pairs file's own groups and intersect the held-out clade's
      isolate set (cohort.parquet) with every training clade's isolate set;
  (2) hierarchy-based: a sublineage clade's parent is the single lineage of its isolates; a lineage clade's children are
      the sublineage clades whose parent it is.
Context (not the macro): sublineage clades nested by NAME (e.g. lineage2.2 and lineage2.2.7) hold disjoint isolates
under exact-label membership; how many held-out clades keep such a name relative in training.
--mutate lineage-groups replaces the folds' groups by each clade's lineage in (1) only (the negative control).

Usage: icb4a_nested.py --root INPUT_ROOT --out OUT.json [--mutate lineage-groups]
"""
import argparse, hashlib, json, os, sys


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--mutate", choices=("lineage-groups",))
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    man = dict(reversed(ln.split(None, 1)) for ln in open(os.path.join(root, "INPUTS.sha256")).read().splitlines() if ln.strip())
    rels = ["amrconf/src/paper_numbers.py", "amrconf/src/c2v2_coverage_prediction.py", "amrconf/results/c2v2_pairs_s0.parquet",
            "amrconf/results/cohort.parquet"]
    used = {}
    for rel in rels:
        h = sha256(os.path.join(root, rel))
        if man.get(rel) != h:
            sys.exit(f"icb4a_nested: ABORT {rel} does not match INPUTS.sha256")
        used[rel] = h
    pn = open(os.path.join(root, rels[0])).read().splitlines()
    c2 = open(os.path.join(root, rels[1])).read().splitlines()
    want = [(pn, 48, 'g=p["clade"].to_numpy()'), (pn, 51, "    for tr,te in LeaveOneGroupOut().split(X,y,g):"),
            (pn, 101, "    for tr,te in LeaveOneGroupOut().split(X,ysev,g):"),
            (c2, 43, '    memb=(sub==clade) if kind=="sublineage" else (lin==clade)'),
            (c2, 37, 'clades=[(c,"sublineage") for c in vc[vc>=MIN_CLADE].index.tolist()]'),
            (c2, 38, 'clades+=[(c,"lineage") for c in pd.Series(lin).value_counts().index.tolist()]')]
    bad = [f"{'paper_numbers' if s is pn else 'c2v2'} l.{k}" for s, k, v in want if s[k - 1] != v]
    if bad:
        sys.exit(f"icb4a_nested: ABORT the code differs from the expected text at {bad}")

    import numpy as np, pandas as pd
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from sklearn.model_selection import LeaveOneGroupOut
    p = pd.read_parquet(os.path.join(root, rels[2]))
    coh = pd.read_parquet(os.path.join(root, rels[3])); keep = coh["in_cohort"].to_numpy()
    lin = coh.loc[keep, "Lineage"].to_numpy(); sub = coh.loc[keep, "Sublineage"].to_numpy()
    kind = p.groupby("clade")["kind"].agg(lambda s: sorted(set(s)))
    if any(len(v) != 1 for v in kind):
        sys.exit("icb4a_nested: ABORT a clade label has more than one kind")
    kind = {c: v[0] for c, v in kind.items()}
    members = {c: set(np.where((sub == c) if k == "sublineage" else (lin == c))[0].tolist()) for c, k in kind.items()}
    if any(len(m) == 0 for m in members.values()):
        sys.exit("icb4a_nested: ABORT a clade has no isolates")

    # (2) hierarchy-based
    parent = {}
    for c, k in kind.items():
        if k == "sublineage":
            ls = sorted(set(lin[list(members[c])]))
            if len(ls) != 1:
                sys.exit(f"icb4a_nested: ABORT sublineage clade {c} spans lineages {ls}")
            parent[c] = ls[0]
    children = {c: sorted(s for s, l in parent.items() if l == c) for c, k in kind.items() if k == "lineage"}
    hier = {}
    for c, k in kind.items():
        rel_ = ([parent[c]] if parent[c] in kind else []) if k == "sublineage" else children[c]
        if rel_:
            hier[c] = sorted(rel_)

    # (1) fold-based, from the folds sklearn builds on the pairs file's own groups
    g = p["clade"].to_numpy()
    if a.mutate == "lineage-groups":
        g = np.array([c if kind[c] == "lineage" else parent[c] for c in g])
    X = np.zeros((len(p), 1)); y = np.zeros(len(p))
    fold, n_folds = {}, 0
    for tr, te in LeaveOneGroupOut().split(X, y, g):
        n_folds += 1
        held = sorted(set(p["clade"].to_numpy()[te])); train = sorted(set(p["clade"].to_numpy()[tr]))
        for c in held:
            ov = [t for t in train if t not in held and members[t] & members[c]]
            if ov:
                fold[c] = sorted(ov)
    # context: relatives by NAME among sublineage clades (disjoint isolates under exact labels)
    subs = [c for c, k in kind.items() if k == "sublineage"]
    name_rel = {c: sorted(t for t in subs if t != c and (t.startswith(c + ".") or c.startswith(t + "."))) for c in subs}
    name_rel = {c: v for c, v in name_rel.items() if v}
    disjoint = all(not (members[c] & members[t]) for c, v in name_rel.items() for t in v)

    out = {"n_clades": len(kind), "n_lineage_clades": sum(k == "lineage" for k in kind.values()),
           "n_sublineage_clades": sum(k == "sublineage" for k in kind.values()), "n_folds": n_folds,
           "n_nested_heldout_clades": len(fold), "nested_by_fold": fold, "nested_by_hierarchy": hier,
           "pairs_in_nested_clades": int(p["clade"].isin(list(fold)).sum()), "n_pairs": int(len(p)),
           "removed_from_training": "no: a fold removes only the rows of the held-out clade label; its parent lineage's rows "
                                    "(for a sublineage clade) and its child sublineages' rows (for a lineage clade) stay in training",
           "context_name_relatives": name_rel, "context_name_relatives_disjoint": disjoint,
           "context_heldout_with_name_relative": len(name_rel), "mutate": a.mutate, "inputs_sha256": used}
    if fold != hier:
        print(f"ABORT icb4a_nested: fold-based nesting ({len(fold)} held-out clades) != hierarchy-based ({len(hier)})"); sys.exit(2)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"icb4a_nested: {out['n_folds']} folds over {out['n_clades']} clades ({out['n_lineage_clades']} lineage, "
          f"{out['n_sublineage_clades']} sublineage); held-out clades with a parent or child clade sharing isolates in training: "
          f"{len(fold)} (fold-based) = {len(hier)} (hierarchy-based); their pairs: {out['pairs_in_nested_clades']} of {out['n_pairs']}; "
          f"context: {len(name_rel)} sublineage clades keep a name relative (disjoint isolates: {disjoint})")


if __name__ == "__main__":
    main()
