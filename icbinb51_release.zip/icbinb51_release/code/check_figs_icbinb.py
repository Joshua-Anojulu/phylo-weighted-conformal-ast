#!/usr/bin/env python3
r"""check_figs_icbinb.py -- guard for the three ICBINB-BIO #51 figures (order_16Oct_ICBINB, ICB-1).

ABORTS (exit 2, every failure printed as "ABORT check_figs_icbinb: <KIND>: <file>: <detail>") if any of these fails:
  TYPE3     a font in `pdffonts` is Type 3, or not embedded;
  GLYPH     the smallest glyph at PRINT size is under MIN_PT. Glyph size = the font size of every text-showing
            operator in the page's content stream (Tf) x the scale of the text matrix (Tm) and of the current
            transformation matrix (cm, with the q/Q stack); print size = that x print width / page width, where the
            print width is the \includegraphics width in the submitted main.tex x the sty's \textwidth (input root);
  METADATA  a pdfinfo field holds an absolute path;
  ORDER     Figure 3's y-axis labels, read back from the PDF (pdftotext -bbox: words left of the axes, inside its
            height, top to bottom), are not the features sorted by |Spearman rho| with P(broken), which this script
            recomputes from the recorded pairs file (and the drawing's own record of its rows must agree);
  CATEGORY  Figure 3 does not label log n_cal, log n_te and q-hat "other label-free" (and the phylogeny / novelty
            features "phylogeny / novelty", the rest "predicted-probability"), or the legend text is missing.
Writes a report (per file: page size, print width and scale, smallest glyph, pdffonts output).

Usage: check_figs_icbinb.py --root INPUT_ROOT --figs DIR --report FILE [--min-pt 7] [--no-layout]
"""
import argparse, json, math, os, re, subprocess, sys, zlib

NAMES = ["fig1_auroc_vs_coverage", "fig2_weight_degeneracy", "fig3_signal_ranking"]
OTHER = {"f_log_n_cal", "f_log_n_te", "f_qhat"}
FAILS, REPORT = [], []


def fail(kind, f, detail):
    FAILS.append(f"ABORT check_figs_icbinb: {kind}: {f}: {detail}")


def say(s=""):
    REPORT.append(s)


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, errors="replace").stdout


def pdffonts_rows(path):
    out = run(["pdffonts", path]); lines = out.splitlines()
    dash = [i for i, ln in enumerate(lines) if ln.startswith("-----")]
    if not dash:
        return out, []
    cols, pos = [], 0
    for seg in lines[dash[0]].split(" "):
        cols.append((pos, pos + len(seg))); pos += len(seg) + 1
    rows = [[ln[a:b].strip() for a, b in cols] for ln in lines[dash[0] + 1:] if ln.strip()]
    return out, rows


def page_content(path):
    b = open(path, "rb").read()
    objs = {int(m.group(1)): m.group(2) for m in re.finditer(rb"(\d+) 0 obj(.*?)endobj", b, re.S)}
    pages = [v for v in objs.values() if re.search(rb"/Type\s*/Page\b", v)]
    if len(pages) != 1:
        raise ValueError(f"{len(pages)} pages")
    mb = [float(x) for x in re.search(rb"/MediaBox \[\s*([0-9.]+) ([0-9.]+) ([0-9.]+) ([0-9.]+)\s*\]", pages[0]).groups()]
    data = b""
    for c in re.findall(rb"(\d+) 0 R", re.search(rb"/Contents\s+(\[[^\]]*\]|\d+ 0 R)", pages[0]).group(1)):
        s = objs[int(c)]
        i = s.index(b"stream") + len(b"stream"); j = s.rindex(b"endstream")
        raw = s[i:j].lstrip(b"\r\n").rstrip(b"\r\n")
        data += zlib.decompress(raw) if b"/FlateDecode" in s[:i] else raw
    return mb, data.decode("latin-1")


TOK = re.compile(r"\((?:\\.|[^\\)])*\)|<[0-9A-Fa-f\s]*>|\[|\]|<<|>>|/[^\s/\[\]()<>{}%]+|[+-]?(?:\d+\.?\d*|\.\d+)|[A-Za-z'\"*]+", re.S)


def glyph_sizes(content):
    """effective font size (page units) of every text-showing operator"""
    ident = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]
    mul = lambda m, n: [m[0] * n[0] + m[1] * n[2], m[0] * n[1] + m[1] * n[3], m[2] * n[0] + m[3] * n[2],
                        m[2] * n[1] + m[3] * n[3], m[4] * n[0] + m[5] * n[2] + n[4], m[4] * n[1] + m[5] * n[3] + n[5]]
    ctm, stack, tm, size, ops, out = ident[:], [], ident[:], None, [], []
    for t in TOK.findall(content):
        if re.fullmatch(r"[+-]?(?:\d+\.?\d*|\.\d+)", t):
            ops.append(float(t)); continue
        if t[0] in "(</[]" or t in ("<<", ">>"):
            ops.append(t); continue
        if t == "q":
            stack.append(ctm[:])
        elif t == "Q":
            ctm = stack.pop() if stack else ident[:]
        elif t == "cm" and len(ops) >= 6:
            ctm = mul([float(x) for x in ops[-6:]], ctm)
        elif t == "BT":
            tm = ident[:]
        elif t == "Tf" and ops:
            size = float(ops[-1])
        elif t == "Tm" and len(ops) >= 6:
            tm = [float(x) for x in ops[-6:]]
        elif t in ("Tj", "TJ", "'", '"'):
            m = mul(tm, ctm)
            out.append(size * math.sqrt(abs(m[0] * m[3] - m[1] * m[2])))
        ops = []
    return out


def norm(s):
    s = re.sub(r"\\[A-Za-z]+", "", s.replace("$", ""))
    return re.sub(r"[^a-z0-9]", "", s.lower())


def main():
    ap = argparse.ArgumentParser()
    for x in ("--root", "--figs", "--report"):
        ap.add_argument(x, required=True)
    ap.add_argument("--min-pt", type=float, default=7.0)
    ap.add_argument("--no-layout", action="store_true", help="fonts, glyphs and metadata only (e.g. the submitted originals)")
    a = ap.parse_args()
    SUB = os.path.join(a.root, "submitted", "source")
    tex = open(os.path.join(SUB, "main.tex")).read(); sty = open(os.path.join(SUB, "neurips_2025.sty")).read()
    frac = {n: float(f) for f, n in re.findall(r"\\includegraphics\[width=([0-9.]+)\\linewidth\]\{figs/(fig\d_[a-z_]+)\.pdf\}", tex)}
    tw = re.findall(r"^\s*textwidth=([0-9.]+)in,\s*$", sty, re.M)
    if len(tw) != 1 or set(frac) != set(NAMES):
        print("ABORT check_figs_icbinb: SETUP: -: print widths not found in the submitted main.tex / sty"); sys.exit(2)
    lw = "\\linewidth"
    widths = ", ".join(f"{n} {frac[n]} x {lw}" for n in NAMES)
    say(f"print widths from the submitted source: {widths}; {lw} = textwidth = {tw[0]} in (neurips_2025.sty)")
    smallest = {}
    for n in NAMES:
        f = os.path.join(a.figs, f"{n}.pdf")
        if not os.path.exists(f):
            fail("SETUP", n, "missing"); continue
        out, rows = pdffonts_rows(f)
        bad = [r for r in rows if r[1].startswith("Type 3") or r[3] != "yes"]
        for r in bad:
            fail("TYPE3", n, f"font {r[0]} is {r[1]} (embedded: {r[3]})")
        if not rows:
            fail("TYPE3", n, "pdffonts lists no font")
        mb, content = page_content(f)
        width_pt = mb[2] - mb[0]
        print_pt = frac[n] * float(tw[0]) * 72
        scale = print_pt / width_pt
        sizes = glyph_sizes(content)
        mn = min(sizes) if sizes else float("nan")
        smallest[n] = mn * scale
        if not sizes or mn * scale < a.min_pt - 1e-9:
            fail("GLYPH", n, f"smallest glyph {mn * scale:.2f} pt at print width < {a.min_pt} pt")
        info = run(["pdfinfo", f])
        for ln in info.splitlines():
            if re.search(r"(?<![:/A-Za-z])/[A-Za-z0-9_.-]+/", ln):
                fail("METADATA", n, f"pdfinfo line holds a path: {ln.strip()}")
        say(""); say(f"== {n}.pdf")
        say(f"page {width_pt:.2f} x {mb[3] - mb[1]:.2f} pt; print width {print_pt:.2f} pt; print scale {scale:.4f}")
        say(f"text-showing operators {len(sizes)}; font sizes in the file {sorted(set(round(s, 3) for s in sizes))}; "
            f"smallest glyph at print width {mn * scale:.2f} pt")
        say("pdffonts:"); say(out.rstrip())
        say("pdfinfo:"); say("\n".join(ln for ln in info.splitlines() if re.match(r"(Creator|Producer|Page size|Title|Author)", ln)))
    # ---- Figure 3: order and categories
    n = NAMES[2]
    if a.no_layout:
        verdict = (f"check_figs_icbinb: {'PASS' if not FAILS else 'FAIL'} (fonts, glyphs, metadata only): smallest glyph at print width "
                   + ", ".join(f"{k} {v:.2f} pt" for k, v in smallest.items()) + f" (minimum {a.min_pt}); failures {len(FAILS)}")
        say(""); say(verdict)
        open(a.report, "w").write("\n".join(REPORT + FAILS) + "\n")
        print("\n".join(FAILS + [verdict])); sys.exit(2 if FAILS else 0)
    lay = json.load(open(os.path.join(a.figs, "figs_icbinb_layout.json")))["figs"][n]
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    import pyarrow.parquet as pq
    from scipy.stats import spearmanr
    d = pq.read_table(os.path.join(a.root, "amrconf", "results", "c2v2_pairs_s0.parquet"), use_threads=False).to_pandas()
    feats = sorted(c for c in d.columns if c.startswith("f_"))
    rho = {c: abs(float(spearmanr(d[c], d.y_broken).statistic)) for c in feats}
    expect_top_down = sorted(feats, key=lambda c: (-rho[c], c))
    drawn = [r["feature"] for r in lay["rows_bottom_to_top"]][::-1]
    if drawn != expect_top_down:
        fail("ORDER", n, "the drawing's own record of its rows is not sorted by |Spearman rho| (recomputed)")
    label = {r["feature"]: r["label"] for r in lay["rows_bottom_to_top"]}
    if set(label) != set(feats):
        fail("ORDER", n, "the drawn features are not the pairs file's features")
    f = os.path.join(a.figs, f"{n}.pdf")
    bbox = run(["pdftotext", "-bbox", f, "-"])
    ph = float(re.search(r'<page width="[0-9.]+" height="([0-9.]+)"', bbox).group(1))
    x0, y0, x1, y1 = lay["axes_pt"]
    words = [(float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4)), m.group(5))
             for m in re.finditer(r'<word xMin="([0-9.]+)" yMin="([0-9.]+)" xMax="([0-9.]+)" yMax="([0-9.]+)">(.*?)</word>', bbox)]
    # y-axis labels: words that START left of the axes (pdftotext boxes include glyph advance, so a right-aligned
    # label's box can end a little past the axes edge) and whose centre lies within the axes' height
    left = [w for w in words if w[0] < x0 and (ph - y1) <= (w[1] + w[3]) / 2 <= (ph - y0)]
    lines, last = [], None                       # cluster words into rows: a new row where the centre jumps > 3 pt
    for w in sorted(left, key=lambda w: (w[1] + w[3]) / 2):
        c_ = (w[1] + w[3]) / 2
        if last is None or c_ - last > 3.0:
            lines.append([])
        lines[-1].append(w); last = c_
    got = [norm(" ".join(w[4] for w in sorted(ws))) for ws in lines]
    want = [norm(label.get(c, c)) for c in expect_top_down]
    if got != want:
        fail("ORDER", n, f"PDF y-axis labels top to bottom {got} are not the |rho| order {want}")
    cats = {r["feature"]: r["category"] for r in lay["rows_bottom_to_top"]}
    for c in feats:
        exp = ("other label-free" if c in OTHER else "phylogeny / novelty" if (c.startswith("f_dist") or c == "f_domain_auc"
               or c.startswith("f_novel")) else "predicted-probability")
        if cats.get(c) != exp:
            fail("CATEGORY", n, f"{c} drawn as '{cats.get(c)}', expected '{exp}'")
    text = run(["pdftotext", f, "-"])
    for lab in ("predicted-probability", "phylogeny / novelty", "other label-free"):
        if norm(lab) not in norm(text):
            fail("CATEGORY", n, f"legend entry '{lab}' not found in the PDF text")
    say(""); say(f"== {n}: y-axis labels read back from the PDF, top to bottom ({len(got)}), against |Spearman rho| recomputed "
                 f"from the pairs file: {'same order' if got == want else 'DIFFERENT'}")
    for c in expect_top_down:
        say(f"   {rho[c]:.4f}  {cats.get(c, '?'):22} {label.get(c, c)}")
    verdict = (f"check_figs_icbinb: {'PASS' if not FAILS else 'FAIL'}: smallest glyph at print width "
               + ", ".join(f"{k} {v:.2f} pt" for k, v in smallest.items())
               + f" (minimum {a.min_pt}); Type 3 fonts {sum(1 for x in FAILS if ': TYPE3: ' in x)}; failures {len(FAILS)}")
    say(""); say(verdict)
    open(a.report, "w").write("\n".join(REPORT + FAILS) + "\n")
    print("\n".join(FAILS + [verdict]))
    sys.exit(2 if FAILS else 0)


if __name__ == "__main__":
    main()
