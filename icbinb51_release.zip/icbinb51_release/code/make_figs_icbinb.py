#!/usr/bin/env python3
r"""make_figs_icbinb.py -- Figures 1-3 of the ICBINB-BIO #51 camera-ready (order_16Oct_ICBINB, ICB-1).

Redraws the three figures of the submitted paper from RECORDED results only (the canonical pairs file and
weight_degeneracy.json; nothing is fitted), starting from the submitted script (amrconf/src/make_figs_icbinb.py, drawn
with matplotlib 3.11.1, the version this script asserts). Changes:
  * TrueType fonts: pdf.fonttype 42 (the submitted PDFs carry Type 3 fonts);
  * every figure is drawn at its PRINT width and saved at exactly that page width, so one point in the file is one
    point on paper. Print width = the \includegraphics width in the submitted main.tex x the sty's \textwidth (both
    read from the input root); height = the original figure's height at the same print scale (same printed
    footprint). Every text is at least MIN_PT points at print size; mathtext subscripts are avoided (they print
    smaller than their base size);
  * Figure 3 stays sorted by |Spearman rho| (as its caption says) and gains a third category: log n (calibration),
    log n (test batch) and q-hat are "other label-free", not predicted-probability features. Colours follow the
    validated categorical order (slots 1-3), each with its own texture (none, 45 deg, 135 deg) and direct labels;
  * the PDF metadata carries no CreationDate (reproducible bytes) and the files are saved from relative paths.
Writes figs_icbinb_layout.json (print widths, page sizes, Figure 3's plotted rows) for check_figs_icbinb.py.

Usage: make_figs_icbinb.py --root INPUT_ROOT --out DIR [--png] [--fonttype 42|3] [--mutate small-label|swap-order|mislabel]
       (--fonttype 3 and --mutate exist only for the negative controls of check_figs_icbinb.py)
"""
import argparse, json, os, re, sys
from decimal import Decimal

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import NullFormatter, NullLocator
from scipy.stats import spearmanr

MPL_VERSION = "3.11.1"          # the version that drew the submitted figures (their PDF Producer)
MIN_PT = 7.0                    # order ICB-1: every glyph at least 7 pt at print width
NAMES = ["fig1_auroc_vs_coverage", "fig2_weight_degeneracy", "fig3_signal_ranking"]
# validated categorical slots 1-3 (fixed order) and the chart ink of the submitted script
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, MUTED, GRID, BASE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
PHYLO = {"f_dist_min_mean", "f_dist_min_med", "f_dist_mean", "f_domain_auc",
         "f_novel_cnt", "f_novel_frac", "f_novel_any", "f_novel_ca_cnt", "f_novel_ca_frac"}
OTHER = {"f_log_n_cal", "f_log_n_te", "f_qhat"}       # order ICB-1 (NEW): "other label-free"
CATS = [("predicted-probability", BLUE, None), ("phylogeny / novelty", ORANGE, "///"), ("other label-free", AQUA, "\\\\\\")]
NICE = {"f_minscore_mean": "mean min$(p,1-p)$", "f_empty_rate": "empty-set rate",
        "f_p_te_mean": "mean $p$ (test)", "f_p_te_sd": "sd $p$ (test)",
        "f_p_shift": "mean $p$ shift", "f_ambig_rate": "ambiguous-set rate",
        "f_qhat": "$\\hat q$", "f_log_n_cal": "log n (calibration)", "f_log_n_te": "log n (test batch)",
        "f_dist_min_mean": "min patristic dist.", "f_dist_min_med": "median min patristic",
        "f_dist_mean": "mean patristic dist.", "f_domain_auc": "domain-classifier AUC",
        "f_novel_cnt": "novel mutations (count)", "f_novel_frac": "novel mutations (frac)",
        "f_novel_any": "any novel mutation", "f_novel_ca_cnt": "novel vs calib. (count)",
        "f_novel_ca_frac": "novel vs calib. (frac)"}


def code_const(src, pat):
    hits = re.findall(pat, src, re.M)
    if len(hits) != 1:
        sys.exit(f"make_figs_icbinb: ABORT pattern {pat!r} matched {len(hits)} times")
    return hits[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--png", action="store_true"); ap.add_argument("--fonttype", type=int, default=42, choices=(3, 42))
    ap.add_argument("--mutate", choices=("small-label", "swap-order", "mislabel"))
    a = ap.parse_args()
    if matplotlib.__version__ != MPL_VERSION:
        sys.exit(f"make_figs_icbinb: ABORT matplotlib {matplotlib.__version__}, the submitted figures were drawn with {MPL_VERSION}")
    R = os.path.join(os.path.abspath(a.root), "amrconf", "results")
    SRC = os.path.join(os.path.abspath(a.root), "amrconf", "src")
    SUB = os.path.join(os.path.abspath(a.root), "submitted", "source")
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    import pyarrow.parquet as pq

    # ---- print sizes, read from the submitted tree
    tex = open(os.path.join(SUB, "main.tex")).read(); sty = open(os.path.join(SUB, "neurips_2025.sty")).read()
    frac = {n: float(f) for f, n in re.findall(r"\\includegraphics\[width=([0-9.]+)\\linewidth\]\{figs/(fig\d_[a-z_]+)\.pdf\}", tex)}
    textwidth_in = float(code_const(sty, r"^\s*textwidth=([0-9.]+)in,\s*$"))
    size = {}
    for n in NAMES:
        b = open(os.path.join(SUB, "figs", f"{n}.pdf"), "rb").read()
        w0, h0 = map(float, re.search(rb"/MediaBox \[\s*0 0 ([0-9.]+) ([0-9.]+)\s*\]", b).groups())
        wi = frac[n] * textwidth_in
        size[n] = dict(include_frac=frac[n], textwidth_in=textwidth_in, print_width_in=wi,
                       height_in=h0 * (wi * 72 / w0) / 72, original_page_pt=[w0, h0])
    # ---- thresholds from the committed code (nothing typed)
    alpha = Decimal(code_const(open(os.path.join(SRC, "c2v2_coverage_prediction.py")).read(), r"^ALPHA=([0-9.]+);"))
    sev = Decimal(code_const(open(os.path.join(SRC, "paper_numbers.py")).read(), r"^sev=\(p\.y_cov<([0-9.]+)\)$"))
    nominal = 1 - alpha

    plt.rcParams.update({
        "pdf.fonttype": a.fonttype, "ps.fonttype": a.fonttype,
        "font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": MIN_PT,
        "axes.labelsize": MIN_PT + 0.5, "axes.titlesize": MIN_PT + 0.5,
        "xtick.labelsize": MIN_PT, "ytick.labelsize": MIN_PT, "legend.fontsize": MIN_PT,
        "axes.edgecolor": BASE, "axes.linewidth": 0.8, "axes.labelcolor": INK2,
        "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelcolor": INK2, "ytick.labelcolor": INK2,
        "text.color": INK, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
        "legend.frameon": False, "figure.dpi": 200, "hatch.linewidth": 0.8})

    d = pq.read_table(os.path.join(R, "c2v2_pairs_s0.parquet"), use_threads=False).to_pandas()
    well, res = d[d.well_characterised], d[~d.well_characterised]
    os.makedirs(a.out, exist_ok=True)
    os.chdir(a.out)                       # save from relative paths
    layout = {"matplotlib": matplotlib.__version__, "fonttype": a.fonttype, "min_pt": MIN_PT, "mutate": a.mutate, "figs": {}}

    def new_fig(n):
        fig = plt.figure(figsize=(size[n]["print_width_in"], size[n]["height_in"]), layout="constrained")
        fig.get_layout_engine().set(w_pad=2 / 72, h_pad=2 / 72, wspace=0, hspace=0)
        return fig, fig.add_subplot()

    def save(fig, n):
        fig.savefig(f"{n}.pdf", metadata={"CreationDate": None})
        if a.png:
            fig.savefig(f"preview_{n}.png", dpi=300)
        w, h = fig.get_size_inches()
        layout["figs"][n] = dict(size[n], page_pt=[w * 72, h * 72])
        return fig

    # ---- Figure 1: accuracy tells you nothing about whether the guarantee holds
    n = NAMES[0]; fig, ax = new_fig(n)
    ax.axhline(float(nominal), color=MUTED, lw=0.9, ls=(0, (3, 2)))
    ax.text(1.01, float(nominal) - 0.015, f"nominal {nominal:.2f}", fontsize=MIN_PT, color=INK2, va="top", ha="right",
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.8, pad=0.6))
    ax.axhspan(0.0, float(sev), color=ORANGE, alpha=0.07, zorder=0)
    ax.text(0.335, float(sev) - 0.035, "severe failure", fontsize=(MIN_PT - 1 if a.mutate == "small-label" else MIN_PT),
            color=INK2, va="top")
    ax.scatter(well.auroc, well.y_cov, s=11, color=BLUE, alpha=0.65, linewidth=0, label=f"well-characterised (n={len(well)})")
    ax.scatter(res.auroc, res.y_cov, s=11, color=ORANGE, alpha=0.65, marker="^", linewidth=0, label=f"reserve (n={len(res)})")
    rw = spearmanr(well.auroc, well.y_cov).statistic
    ax.set_xlabel("AUROC on the held-out clade"); ax.set_ylabel("realised conformal coverage")
    ax.set_xlim(0.32, 1.02); ax.set_ylim(0.0, 1.04)
    ax.set_title(f"within-class Spearman $\\rho$ = {rw:+.3f}", color=INK, pad=3)
    ax.legend(loc="lower left", handletextpad=0.2, borderpad=0.2, borderaxespad=0.3)
    save(fig, n)

    # ---- Figure 2: normalised phylogenetic weights collapse, depth-dependently
    n = NAMES[1]; W = json.load(open(os.path.join(R, "weight_degeneracy.json"))); fig, ax = new_fig(n)
    sty2 = {"random": (AQUA, "o", "random split"), "sublineage": (BLUE, "s", "sublineage holdout"),
            "lineage2": (ORANGE, "^", "lineage holdout")}
    for key, rows in W.items():
        hold, dist = key.split("|")
        if dist != "tree":
            continue
        col, mk, lab = sty2[hold.replace("_holdout", "")]
        bw = [r["bandwidth_x_median"] for r in rows]; cm = [r["cos_mean"] for r in rows]
        ax.plot(bw, cm, color=col, marker=mk, ms=4, lw=1.6, label=lab, markeredgecolor="white", markeredgewidth=0.7)
    ax.axhline(1.0, color=MUTED, lw=0.9, ls=(0, (3, 2)))
    ax.text(0.255, 1.012, "identical weights", fontsize=MIN_PT, color=INK2, va="bottom", ha="left")
    ax.set_xscale("log"); ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_minor_formatter(NullFormatter())
    bws = sorted({r["bandwidth_x_median"] for rows in W.values() for r in rows})
    ax.set_xticks(bws); ax.set_xticklabels([f"{b:g}" if b != int(b) else f"{b:.1f}" for b in bws])
    ax.set_xlabel("kernel bandwidth\n($\\times$ median patristic distance)")      # two lines: one line is wider than the figure
    ax.set_ylabel("mean pairwise cosine sim.\nof normalised weight vectors")
    ax.set_ylim(0.30, 1.10)
    ax.legend(loc="lower right", handletextpad=0.3, borderpad=0.2, borderaxespad=0.3)
    save(fig, n)

    # ---- Figure 3: what predicts a broken guarantee, and what does not
    n = NAMES[2]; fig, ax = new_fig(n)
    feats = sorted(c for c in d.columns if c.startswith("f_"))
    rows = sorted(((c, abs(float(spearmanr(d[c], d.y_broken).statistic))) for c in feats), key=lambda r: (r[1], r[0]))
    if a.mutate == "swap-order":
        rows[-1], rows[-2] = rows[-2], rows[-1]
    cat = {c: (1 if c in PHYLO else 2 if c in OTHER else 0) for c in feats}
    if a.mutate == "mislabel":
        cat["f_qhat"] = 0
    ys = np.arange(len(rows))
    for y, (c, v) in zip(ys, rows):
        _, col, hatch = CATS[cat[c]]
        ax.barh(y, v, height=0.72, color=col, hatch=hatch, edgecolor="white", linewidth=0.7)
    ax.set_yticks(ys); ax.set_yticklabels([NICE.get(c, c) for c, _ in rows])
    ax.tick_params(axis="y", length=0, pad=2)
    ax.set_ylim(-0.6, len(rows) - 0.4)
    ax.set_xlabel("|Spearman $\\rho$| vs\nP(guarantee broken)")      # two lines: one line is wider than the axes
    ax.set_xlim(0, 0.78); ax.grid(axis="y", visible=False)
    ax.legend(handles=[Patch(facecolor=col, hatch=h, edgecolor="white", label=lab) for lab, col, h in CATS],
              loc="lower right", handletextpad=0.4, borderpad=0.2, borderaxespad=0.3, handlelength=1.6)
    save(fig, n)
    fig.canvas.draw()
    pos = ax.get_position(); w, h = fig.get_size_inches() * 72
    layout["figs"][n].update(axes_pt=[pos.x0 * w, pos.y0 * h, pos.x1 * w, pos.y1 * h], xlim=list(ax.get_xlim()),
                             rows_bottom_to_top=[dict(feature=c, label=NICE.get(c, c), abs_rho=v,
                                                      category=CATS[cat[c]][0]) for c, v in rows])
    json.dump(layout, open("figs_icbinb_layout.json", "w"), indent=1)
    print(f"make_figs_icbinb: matplotlib {matplotlib.__version__}, fonttype {a.fonttype}, mutate {a.mutate}; "
          + "; ".join(f"{k}: {v['print_width_in']:.3f} x {v['height_in']:.3f} in" for k, v in layout["figs"].items()))


if __name__ == "__main__":
    main()
