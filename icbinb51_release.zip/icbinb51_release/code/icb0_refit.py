#!/usr/bin/env python3
"""icb0_refit.py -- the two ICB-0 quantities whose recorded values are rounded too coarsely to decide a macro.
FITS MODELS: run it as a Slurm job, never on a login node.

(A) \\NPhyloImpMax is the CEILING at 3 dp of the unrounded largest gradient-boosting importance of a phylogeny
    feature. PAPER_NUMBERS.json stores imp.phylo.max = 0.0100 (4 dp), which leaves 0.010 or 0.011 open. This part
    refits paper_numbers.py l.123 (GradientBoostingRegressor(random_state=0) on the canonical pairs file) and keeps
    the importances unrounded.
(B) \\NAurocStab is the half-range of AUROC over the 30 rifampicin lineage-2 calibration draws. cal_variance.json
    stores only mean and sd (3 dp); the 6 Sep rerun logs print min and max at 3 dp (0.968, 0.971), which leaves
    0.001 or 0.002 open. This part re-runs check_cal_variance.py's per-draw loop for RIF and keeps AUROC unrounded.

Every executed source line is a VERBATIM copy, compared line by line with the input copy of the source file before
anything runs (abort on any difference). The run is accepted only if it REPRODUCES what was stored:
  (A) round(v, 4) == PAPER_NUMBERS.json imp.<f>.y_broken for all 18 features (paper_numbers.py l.125's rounding);
  (B) all 30 coverages == cal_variance.json["drugs"]["RIF"]["coverage"]["all"] (4 dp, in draw order), and the stored
      coverage mean/sd/min/max, qhat mean/sd/min/max and AUROC mean/sd, and the rerun log's AUROC min/max (3 dp).
Inputs come only from --root (the folder fetch_inputs.py writes); output is one JSON with input hashes.

Sizing: the email-7 check r05 (nums_67 27baf2c) re-ran exactly these 30 RIF fits in about 30 s, and the whole e7
suite, which includes paper_numbers.py's 82 LOCO GBR fits, took about 1 minute. This script does 30 + 1 fits:
expected under 2 minutes including imports; the job asks for 15 minutes on one node (normal: 0.25 SU ceiling).

Usage: icb0_refit.py --root INPUT_ROOT --out OUT.json      (Slurm)
       icb0_refit.py --root INPUT_ROOT --check-only        (login node: verbatim checks only, no fit)
"""
import argparse, hashlib, json, os, re, sys, textwrap

PN_VERBATIM = [  # paper_numbers.py
    'F=sorted([c for c in p.columns if c.startswith("f_")])',
    '_gbr=GradientBoostingRegressor(random_state=0).fit(p[F].to_numpy(),p.y_broken.to_numpy())',
    '_nov=[c for c in F if c.startswith("f_novel")]',
    '_phy=[c for c in F if c.startswith("f_dist") or c=="f_domain_auc"]',
]
PN_LOOP = 'for c,v in zip(F,_gbr.feature_importances_):'
CCV_SETUP = [  # check_cal_variance.py
    'ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]',
    'ALPHA=0.10; MIN_AC=5',
    'coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()',
    'Y=np.load(f"{OUT}/labels_int8.npy")[keep]; lin=coh.loc[keep,"Lineage"].to_numpy()',
    'X=sparse.load_npz(f"{OUT}/X_nonsyn.npz").tocsr()',
]
CCV_LOOP_HEAD = 'for DRUG in ["RIF","INH","RFB"]:'
CCV_BODY = '''    j=ALL.index(DRUG); y=Y[:,j]
    te_mask=(lin=="Lineage 2"); rest=np.where(~te_mask)[0]
    TE=np.where(te_mask)[0]; TE=TE[y[TE]>=0]
    covs=[];aucs=[];qs=[];emps=[]
    for s in range(30):
        r=np.random.default_rng(10_000+s); rp=r.permutation(rest); cut=int(.75*rest.size)
        TR=rp[:cut]; CA=rp[cut:]
        TR=TR[y[TR]>=0]; CA=CA[y[CA]>=0]
        ac=np.asarray((X[TR]>0).sum(axis=0)).ravel(); cols=np.where(ac>=MIN_AC)[0]
        clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                               class_weight="balanced").fit(X[TR][:,cols],y[TR])
        pca=clf.predict_proba(X[CA][:,cols])[:,1]; pte=clf.predict_proba(X[TE][:,cols])[:,1]
        s_ca=np.where(y[CA]==1,1-pca,pca)
        q=np.quantile(s_ca,min(np.ceil((s_ca.size+1)*(1-ALPHA))/s_ca.size,1.0),method="higher")
        inS,inR=(pte<=q),((1-pte)<=q)
        covs.append(float(np.where(y[TE]==1,inR,inS).mean()))
        emps.append(float(((~inS)&(~inR)).mean()))
        aucs.append(float(roc_auc_score(y[TE],pte))); qs.append(float(q))
'''


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def locate(src_lines, text, what):
    hits = [i for i, ln in enumerate(src_lines) if ln == text]
    if len(hits) != 1:
        sys.exit(f"icb0_refit: ABORT {what}: verbatim line found {len(hits)} times, expected once: {text}")
    return hits[0] + 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); ap.add_argument("--out")
    ap.add_argument("--check-only", action="store_true", help="verify the verbatim copies, fit nothing")
    a = ap.parse_args()
    if not a.check_only and not a.out:
        ap.error("--out is required unless --check-only")
    R = os.path.join(a.root, "amrconf", "results"); S = os.path.join(a.root, "amrconf", "src")
    used = {}

    def inp(p):
        used[os.path.relpath(p, a.root)] = sha256(p)
        return p

    import numpy as np, pandas as pd
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    from scipy import sparse
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    import sklearn

    # ---------------- verbatim checks (both parts) BEFORE anything is fitted ----------------
    pn_src = open(inp(os.path.join(S, "paper_numbers.py"))).read().splitlines()
    where = {t: locate(pn_src, t, "paper_numbers.py") for t in PN_VERBATIM + [PN_LOOP]}
    cc_src = open(inp(os.path.join(S, "check_cal_variance.py"))).read().splitlines()
    cwhere = [locate(cc_src, t, "check_cal_variance.py") for t in CCV_SETUP]
    head = locate(cc_src, CCV_LOOP_HEAD, "check_cal_variance.py")
    body = CCV_BODY.rstrip("\n").splitlines()
    diff = [i for i, ln in enumerate(body) if cc_src[head + i] != ln]
    if diff:
        sys.exit(f"icb0_refit: ABORT loop body differs from check_cal_variance.py at body lines {diff}")
    if cc_src[head + len(body)].strip() != "covs=np.array(covs);aucs=np.array(aucs);qs=np.array(qs);emps=np.array(emps)":
        sys.exit("icb0_refit: ABORT the loop body does not end where expected")
    print("verbatim: paper_numbers.py l." + ", l.".join(str(where[t]) for t in PN_VERBATIM + [PN_LOOP])
          + f"; check_cal_variance.py setup l.{', l.'.join(map(str, cwhere))}, loop l.{head + 1}-{head + len(body)}")
    if a.check_only:
        print("check-only: verbatim copies match; nothing fitted"); return

    # ---------------- (A) importances ----------------
    PN = json.load(open(inp(os.path.join(R, "PAPER_NUMBERS.json"))))
    g = {"p": pd.read_parquet(inp(os.path.join(R, "c2v2_pairs_s0.parquet"))),
         "GradientBoostingRegressor": GradientBoostingRegressor}
    exec("\n".join(PN_VERBATIM), g)
    imp = {c: float(v) for c, v in zip(g["F"], g["_gbr"].feature_importances_)}   # l.124's zip, kept unrounded
    bad = [c for c in g["F"] if round(imp[c], 4) != PN[f"imp.{c}.y_broken"]]
    if bad:
        sys.exit(f"icb0_refit: ABORT refit importances do not reproduce PAPER_NUMBERS.json for {bad}")
    for grp, key in (("_phy", "imp.phylo.max"), ("_nov", "imp.novelty.max")):
        if round(max(round(imp[c], 4) for c in g[grp]), 4) != PN[key]:
            sys.exit(f"icb0_refit: ABORT {key} not reproduced")
    print(f"(A) {len(imp)} importances reproduce PAPER_NUMBERS.json at 4 dp")

    # ---------------- (B) RIF lineage-2 calibration draws ----------------
    for f in ("cohort.parquet", "labels_int8.npy", "X_nonsyn.npz"):
        inp(os.path.join(R, f))
    h = {"np": np, "pd": pd, "sparse": sparse, "LogisticRegression": LogisticRegression,
         "roc_auc_score": roc_auc_score, "OUT": R, "DRUG": "RIF"}
    exec("\n".join(CCV_SETUP), h)
    exec(textwrap.dedent(CCV_BODY), h)
    covs, aucs, qs = h["covs"], h["aucs"], h["qs"]
    CV = json.load(open(inp(os.path.join(R, "cal_variance.json"))))["drugs"]["RIF"]
    checks = {
        "coverage.all (4 dp, draw order)": [round(c, 4) for c in covs] == CV["coverage"]["all"],
        "n_draws": len(covs) == CV["n_draws"], "n_te": int(h["TE"].size) == CV["n_te"],
        "coverage.mean": round(float(np.mean(covs)), 3) == CV["coverage"]["mean"],
        "coverage.sd": round(float(np.std(covs)), 3) == CV["coverage"]["sd"],
        "coverage.min": round(float(np.min(covs)), 3) == CV["coverage"]["min"],
        "coverage.max": round(float(np.max(covs)), 3) == CV["coverage"]["max"],
        "qhat.mean": round(float(np.mean(qs)), 4) == CV["qhat"]["mean"],
        "qhat.sd": round(float(np.std(qs)), 4) == CV["qhat"]["sd"],
        "qhat.min": round(float(np.min(qs)), 4) == CV["qhat"]["min"],
        "qhat.max": round(float(np.max(qs)), 4) == CV["qhat"]["max"],
        "auroc.mean": round(float(np.mean(aucs)), 3) == CV["auroc"]["mean"],
        "auroc.sd": round(float(np.std(aucs)), 3) == CV["auroc"]["sd"],
    }
    rr = open(inp(os.path.join(R, "cal_variance_rerun_20260906b.txt"))).read()
    m = re.search(r"RIF / Lineage-2.*?AUROC\s*: mean ([\d.]+) sd ([\d.]+) min ([\d.]+) max ([\d.]+)", rr, re.S)
    checks["rerun log AUROC min (3 dp)"] = bool(m) and f"{min(aucs):.3f}" == m.group(3)
    checks["rerun log AUROC max (3 dp)"] = bool(m) and f"{max(aucs):.3f}" == m.group(4)
    failed = [k for k, ok in checks.items() if not ok]
    if failed:
        sys.exit(f"icb0_refit: ABORT the re-run does not reproduce cal_variance.json / the rerun log: {failed}")
    print(f"(B) 30 RIF draws reproduce cal_variance.json and the rerun log ({len(checks)} checks)")

    out = {"generator": "icb0_refit.py", "sklearn": sklearn.__version__, "numpy": np.__version__,
           "importances_y_broken_unrounded": imp, "phylo_features": g["_phy"], "novelty_features": g["_nov"],
           "rif_lineage2": {"auroc": aucs, "coverage": covs, "qhat": qs, "n_te": int(h["TE"].size),
                            "auroc_min": float(min(aucs)), "auroc_max": float(max(aucs)),
                            "auroc_half_range": float((max(aucs) - min(aucs)) / 2)},
           "reproduction_checks": checks, "inputs_sha256": used}
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"phylo max importance (unrounded) {max(imp[c] for c in g['_phy'])!r}; "
          f"AUROC half-range (unrounded) {out['rif_lineage2']['auroc_half_range']!r}")
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
