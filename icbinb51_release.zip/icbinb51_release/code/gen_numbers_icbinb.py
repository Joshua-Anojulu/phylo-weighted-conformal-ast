#!/usr/bin/env python3
r"""gen_numbers_icbinb.py -- the numbers file of the ICBINB-BIO #51 camera-ready (order_16Oct_ICBINB, ICB-0a/b).

Writes numbers_icbinb.tex with exactly one \newcommand per macro of ICBINB_NUMBERS_SPEC_v2.md (names, order and
the spec's own values are READ from the spec copy in the input root, never typed here), and a provenance table
(macro, value, file relative to the root, key or expression, commit). Every value is computed from recorded data
in the input root, which fetch_inputs.py fills; nothing else is read.

Formats (order ICB-0a): ROUND_HALF_UP on the decimal string (decimal module); integers with {,} thousands
separators; "as LaTeX math" macros as $m\times10^{e}$; the five upper-bound macros are the CEILING of the
unrounded maximum at the printed precision; direction words from signs; ordinal words for ranks. Precision: the
spec's value where it gives one; otherwise the precision the submitted paper printed; otherwise the precision the
email-7 correction printed; otherwise 3 decimals. Where a recorded value is itself rounded, the generator uses an
unrounded recorded source if one exists (pairs file, an email-7 log, a refit file) and otherwise proves that every
value inside the stored value's rounding interval gives the same macro (else the macro is not decidable).

GUARDS (any failure ABORTS: exit 2, nothing written; every failure is printed with its guard name):
  INPUT-MANIFEST  every file read has the sha256 listed in INPUTS.sha256 / derived/DERIVED.sha256
  INPUT-DRIFT     every file email 7 hashed (nums_67 27baf2c e7/INPUTS_e7.sha256, 1a3949d verify_e7/...) is unchanged
  SPEC            a macro the spec gives a value for must equal that value exactly (order ICB-0b)
  EMAIL-7         a value confirmed for email 7 must agree with the e7 log (recomputed value and printed value)
  CROSS           independent recorded copies of the same quantity agree (e.g. PAPER_NUMBERS.json vs the pairs
                  file, numbers_e3.json vs e3_shift_diagnosis.json)
  ROUNDING        a macro computed from a rounded stored value must be decided by it (see above)
  MACRO-SET       the emitted names are exactly the spec's names, each once
--hold NAME,...   replace these macros by \NEEDNUM{NAME} instead of a value. Allowed ONLY for macros that fail a
                  guard (a hold on a passing macro aborts as STALE-HOLD); the run still aborts on any other failure.
                  This never emits a disputed value; it withholds it and records why.
Macros whose source is a later task (spec source "ICB-2" ... "ICB-5") are written as \NEEDNUM{NAME}; so are
macros whose deciding input (derived/icb0_refit.json, a Slurm job) is absent, and macros with an open question.

RELEASE BUILD (order ICB-6). The internal build also reads files that are not public: the email-7 verification
logs and the order's notes (paths under nums_67/ and notes/: the spec, the chat's answers, the email-7 record).
--write-release-record FILE (internal build) records every value read from those files, at the point where it is
read (the parsed spec rows, without their source paths; each matched log line; each email-7 RESULT entry used by a
guard), plus the sha256 of every file the build read or a derived file cites, and this generator's commit and sha256.
--release (release build) replays those values from release/RELEASE_RECORD.json in the input root and reads every
other file from the root as usual, so every guard runs as in the internal build except INPUT-DRIFT (it needs the
email-7 manifests). One more guard runs instead:
  RELEASE         every file the internal build read is either byte-identical in the release root or listed in
                  release/RELEASE_CHANGES.tsv (sanitized: only the project-root line differs; excerpt; omitted), and
                  this generator is the one that wrote the record (same sha256; the record supplies the commit).

Usage: gen_numbers_icbinb.py [--root DIR] --out-tex FILE --out-prov FILE [--hold A,B] [--log FILE]
                             [--write-release-record FILE | --release]
       --root defaults to the environment variable ICBINB_INPUT_ROOT.
"""
import argparse, ast, hashlib, json, os, re, subprocess, sys
from decimal import Decimal, ROUND_HALF_UP, ROUND_CEILING

import numpy as np
import pandas as pd

ROOT = None
SHA = {}          # rel -> sha256 from the manifests
USED = {}         # rel -> sha256 actually read
FAIL = []         # (guard, macro, detail)
NOTES = []        # informational lines printed by the run
V = {}            # macro -> dict(value, file, key, unrounded, rule, status)
E7_LOGS = {}
MODE = "internal"                      # "release": withheld reads are replayed from the release record
WITHHELD = ("nums_67/", "notes/")      # not public: read by the internal build only
REPLAY = {}                            # kind -> key -> recorded value (written by the internal build, read by a release build)
CITED = set()                          # files whose sha256 a derived file cites
INTERNAL_SHA = {}                      # release build: rel -> sha256 of the file the internal build read


def fail(guard, macro, detail):
    FAIL.append((guard, macro, detail))


def note(s):
    NOTES.append(s)


# ----------------------------------------------------------------------------------------------------------------
# inputs
def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def withheld(rel):
    return rel.startswith(WITHHELD)


def replay(kind, rel, key, read):
    """A value read from a withheld file: computed and recorded by the internal build, replayed by a release build."""
    if not withheld(rel):
        return read()
    book = REPLAY.setdefault(kind, {})
    if MODE == "release":
        if key not in book:
            fail("RELEASE", "-", f"the release record has no {kind} entry for {key}")
            return None
        return book[key]
    book[key] = read()
    return book[key]


def as_found(x):
    """A recorded regex match: JSON stores a tuple of groups as a list."""
    return tuple(x) if isinstance(x, list) else x


def cites(rel, h):
    """A derived file says it read rel with sha256 h: it must be the file of this build. A release build also accepts
    the internal build's file (the RELEASE guard ties the two)."""
    CITED.add(rel)
    if MODE == "release":
        return h in {SHA.get(rel), INTERNAL_SHA.get(rel)} - {None}
    return SHA.get(rel) == h


def inp(rel):
    if MODE == "release" and withheld(rel):
        fail("RELEASE", "-", f"{rel} is withheld from the release and this read is not replayed")
        return None
    p = os.path.join(ROOT, rel)
    if not os.path.exists(p):
        fail("INPUT-MANIFEST", "-", f"{rel} is missing from the input root")
        return None
    h = sha256(p)
    if rel not in SHA:
        fail("INPUT-MANIFEST", "-", f"{rel} is not listed in INPUTS.sha256 or derived/DERIVED.sha256")
    elif SHA[rel] != h:
        fail("INPUT-MANIFEST", "-", f"{rel} sha256 {h[:12]} differs from its manifest entry {SHA[rel][:12]}")
    USED[rel] = h
    return p


def load_manifests():
    for man, base in (("INPUTS.sha256", ""), (os.path.join("derived", "DERIVED.sha256"), "derived/")):
        p = os.path.join(ROOT, man)
        if os.path.exists(p):
            for ln in open(p):
                if ln.strip():
                    h, rel = ln.split(None, 1)
                    SHA[base + rel.strip()] = h


def jload(rel):
    def read():
        p = inp(rel)
        return json.load(open(p)) if p else {}
    r = replay("jload", rel, rel, read)
    return {} if r is None else r


def text(rel):
    p = inp(rel)
    return open(p).read() if p else ""


def parquet(rel):
    p = inp(rel)
    if p is None:
        print(f"ABORT gen_numbers_icbinb: INPUT-MANIFEST: -: {rel} missing"); sys.exit(2)
    import pyarrow as pa
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    import pyarrow.parquet as pq
    return pq.read_table(p, use_threads=False).to_pandas()


def code_value(rel, pattern, cast=float, what=""):
    """The value of a constant in a committed script: the regex must match exactly once."""
    def read():
        src = text(rel)
        hits = re.findall(pattern, src, re.M)
        line = src[:re.search(pattern, src, re.M).start()].count("\n") + 1 if len(hits) == 1 else None  # the matched line
        return {"n": len(hits), "first": hits[0] if len(hits) == 1 else None, "line": line}
    r = replay("code_value", rel, f"{rel} :: {pattern}", read)
    if r is None:
        return None, None
    if r["n"] != 1:
        fail("CROSS", what or "-", f"{rel}: pattern {pattern!r} matched {r['n']} times, expected once")
        return None, None
    first = as_found(r["first"])
    return cast(first) if not isinstance(first, tuple) else first, r["line"]


# ----------------------------------------------------------------------------------------------------------------
# formatting
def D(x):
    if isinstance(x, Decimal):
        return x
    if isinstance(x, (bool, np.bool_)):
        raise TypeError("bool")
    if isinstance(x, (int, np.integer)):
        return Decimal(int(x))
    if isinstance(x, str):
        return Decimal(x)
    return Decimal(repr(float(x)))


def fixed(x, places, rounding=ROUND_HALF_UP):
    v = D(x).quantize(Decimal(1).scaleb(-places), rounding=rounding)
    if v == 0:
        v = abs(v)
    return f"{v:f}"


def ceil(x, places):
    return fixed(x, places, ROUND_CEILING)


def pct(x, places):
    return fixed(D(x) * 100, places)


def integer(n):
    if float(n) != int(n):
        raise ValueError(f"not an integer: {n}")
    return f"{int(n):,}".replace(",", "{,}")


def sci_math(x, sig=None):
    """$m\\times10^{e}$; an exact integer keeps all its significant digits; mantissa 1 prints as $10^{e}$."""
    d = D(x)
    if sig is None:
        digits = str(int(d)).rstrip("0")
        e = len(str(int(d))) - 1
        m = Decimal(digits).scaleb(-(len(digits) - 1))
    else:
        e = d.adjusted()
        m = d.scaleb(-e).quantize(Decimal(1).scaleb(-(sig - 1)), rounding=ROUND_HALF_UP)
        if m >= 10:
            e += 1; m = d.scaleb(-e).quantize(Decimal(1).scaleb(-(sig - 1)), rounding=ROUND_HALF_UP)
    ms = f"{m:f}"
    if D(ms) == 1:
        return f"$10^{{{e}}}$"
    return f"${ms}\\times10^{{{e}}}$"


ORD = ["first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh",
       "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth"]


def and_list(items):
    items = list(items)
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def decimals(s):
    s = s.strip()
    return len(s.split(".")[1]) if "." in s else 0


def decided(stored, stored_places, f):
    """f(value) is decided by a value rounded to stored_places iff f agrees over the open rounding interval."""
    half = Decimal(1).scaleb(-stored_places) / 2
    tiny = Decimal(1).scaleb(-(stored_places + 12))
    lo, hi = f(D(stored) - half + tiny), f(D(stored) + half - tiny)
    return lo == hi, lo, hi


# ----------------------------------------------------------------------------------------------------------------
def put(macro, value, file, key, unrounded=None, rule="", status="OK"):
    if macro in V:
        fail("MACRO-SET", macro, "computed twice")
    V[macro] = dict(value=value, file=file, key=key, unrounded=unrounded, rule=rule, status=status)


def needs(macro, file, key, why, status):
    put(macro, None, file, key, rule=why, status=status)


def e7(rel):
    """RESULT lines of an e7 log: label -> dict(recomputed, rendered, email, verdict)."""
    if rel not in E7_LOGS:
        out = {}
        for ln in text(rel).splitlines():
            m = re.match(r"^RESULT \| (.*?) \| recomputed=(.*) \| rendered=(.*) \| email=(.*) \| (\w+)\s*$", ln)
            if m:
                out[m.group(1)] = dict(recomputed=m.group(2), rendered=m.group(3), email=m.group(4), verdict=m.group(5))
        E7_LOGS[rel] = out
    return E7_LOGS[rel]


def e7_line(rel, pattern, what):
    def read():
        hits = re.findall(pattern, text(rel), re.M)
        return {"n": len(hits), "first": hits[0] if len(hits) == 1 else None}
    r = replay("e7_line", rel, f"{rel} :: {pattern}", read)
    if r is None:
        return None
    if r["n"] != 1:
        fail("EMAIL-7", what, f"{rel}: expected one line matching {pattern!r}, found {r['n']}")
        return None
    return as_found(r["first"])


EMAIL67 = "notes/EMAIL_67_NUMBERS_CONFIRMED.md"


def doc_findall(pattern):
    """re.findall over the email-7 record (the wording sent to the organisers)."""
    return replay("doc", EMAIL67, f"{EMAIL67} :: {pattern}", lambda: re.findall(pattern, text(EMAIL67))) or []


def guard_e7(macro, rel, label, mine=None, mine_str=None, tol=1e-12):
    """mine: unrounded number (compared with the e7 recomputed value and, at the e7 email precision, with the
    printed email value). mine_str: a string compared with the email value as printed (counts, words)."""
    r = replay("e7", rel, f"{rel} :: {label}", lambda: e7(rel).get(label))
    if r is None:
        fail("EMAIL-7", macro, f"{rel}: no RESULT line '{label}'"); return
    if r["verdict"] != "CONFIRMED":
        fail("EMAIL-7", macro, f"{rel}: '{label}' was {r['verdict']} in email 7, not CONFIRMED")
    if mine is not None:
        try:
            rec = float(r["recomputed"])
        except ValueError:
            rec = None
        if rec is not None and abs(float(mine) - rec) > tol:
            fail("EMAIL-7", macro, f"unrounded {float(mine)!r} differs from the email-7 recomputation {rec!r} ({label})")
        if fixed(mine, decimals(r["email"])) != r["email"]:
            fail("EMAIL-7", macro, f"{fixed(mine, decimals(r['email']))} differs from email 7's {r['email']} ({label})")
    if mine_str is not None and mine_str != r["email"]:
        fail("EMAIL-7", macro, f"{mine_str!r} differs from email 7's {r['email']!r} ({label})")


def cross(macro, ok, detail):
    if not ok:
        fail("CROSS", macro, detail)


# ----------------------------------------------------------------------------------------------------------------
def compute():
    S67, V67 = "nums_67/27baf2c/e7/logs", "nums_67/1a3949d/verify_e7"
    RES, SRC = "amrconf/results", "amrconf/src"
    PNf = f"{RES}/PAPER_NUMBERS.json"; PN = jload(PNf)
    PQf = f"{RES}/c2v2_pairs_s0.parquet"; P = parquet(PQf)
    from scipy.stats import spearmanr
    well, res = P[P.well_characterised], P[~P.well_characterised]
    SEV, sev_line = code_value(f"{SRC}/paper_numbers.py", r"^sev=\(p\.y_cov<([0-9.]+)\)$", float, "severity")
    F = sorted(c for c in P.columns if c.startswith("f_"))       # paper_numbers.py l.46
    pnsrc = text(f"{SRC}/paper_numbers.py")
    for frag in ('_nov=[c for c in F if c.startswith("f_novel")]',
                 '_phy=[c for c in F if c.startswith("f_dist") or c=="f_domain_auc"]',
                 'F=sorted([c for c in p.columns if c.startswith("f_")])'):
        cross("feature-groups", frag in pnsrc, f"paper_numbers.py no longer defines: {frag}")
    NOV = [c for c in F if c.startswith("f_novel")]
    PHY = [c for c in F if c.startswith("f_dist") or c == "f_domain_auc"]
    rho = {c: float(spearmanr(P[c], P.y_broken).statistic) for c in F}

    def pn(key):
        if key not in PN:
            fail("CROSS", key, f"{PNf} has no key {key}"); return None
        return PN[key]

    def pn_match(macro, unrounded, key):
        cross(macro, round(float(unrounded), 4) == pn(key),
              f"recomputed {unrounded!r} does not round to {PNf} {key} = {pn(key)}")

    # ---- counts ----
    put("NPairs", integer(pn("cov.pairs")), PNf, "cov.pairs", rule="integer")
    cross("NPairs", len(P) == pn("cov.pairs"), "pairs file length differs")
    put("NClades", integer(pn("cov.clades")), PNf, "cov.clades", rule="integer")
    cross("NClades", P.clade.nunique() == pn("cov.clades"), "pairs file clade count differs")
    put("NDrugs", integer(pn("pred.n_drugs")), PNf, "pred.n_drugs", rule="integer")
    cross("NDrugs", P.drug.nunique() == pn("pred.n_drugs"), "pairs file drug count differs")
    nsev = int((P.y_cov < SEV).sum())
    put("NSevereN", integer(pn("cov.severe_n")), PNf, "cov.severe_n", rule="integer")
    cross("NSevereN", nsev == pn("cov.severe_n"), f"pairs file gives {nsev} below {SEV}")
    guard_e7("NSevereN", f"{S67}/r12a_severe_34_of_491.out", "E7 kept: holdouts below 0.70 coverage",
             mine_str=f"{nsev} of {len(P)}")
    fr = nsev / len(P)
    put("NSevereFracPct", pct(fr, 1), PQf, f"100*mean(y_cov<{SEV}) [paper_numbers.py l.{sev_line}; = {PNf} cov.severe_frac]",
        fr, "percent, 1 dp")
    pn_match("NSevereFracPct", fr, "cov.severe_frac")
    put("NCovMedian", fixed(P.y_cov.median(), 3), PQf, "median(y_cov) [= cov.median]", float(P.y_cov.median()), "3 dp")
    pn_match("NCovMedian", P.y_cov.median(), "cov.median")
    put("NCovMin", fixed(P.y_cov.min(), 2), PQf, "min(y_cov) [= cov.min]", float(P.y_cov.min()), "2 dp")
    pn_match("NCovMin", P.y_cov.min(), "cov.min")
    for m, sub, key in (("NRhoWell", well, "cov.rho_well"), ("NRhoReserve", res, "cov.rho_reserve"),
                        ("NRhoPooled", P, "cov.rho_pooled")):
        r_ = float(spearmanr(sub.auroc, sub.y_cov).statistic)
        put(m, fixed(r_, 3), PQf, f"spearman(auroc, y_cov) over {'well-characterised' if sub is well else 'reserve' if sub is res else 'all'} pairs [= {key}]", r_, "3 dp")
        pn_match(m, r_, key)
        if m == "NRhoWell":
            guard_e7(m, f"{S67}/r12b_rho_within_class.out",
                     "E7 kept: within-class Spearman(AUROC, coverage), well-characterised", mine=r_)
    put("NNWell", integer(pn("cov.n_well")), PNf, "cov.n_well", rule="integer")
    cross("NNWell", len(well) == pn("cov.n_well"), "pairs file well count differs")
    put("NNReserve", integer(pn("cov.n_reserve")), PNf, "cov.n_reserve", rule="integer")
    cross("NNReserve", len(res) == pn("cov.n_reserve"), "pairs file reserve count differs")

    # ---- LOCO R2 and bootstrap: unrounded values recorded by the email-7 refit (r08), else PAPER_NUMBERS ----
    r08 = f"{S67}/r08_sd_ratio.out"
    m = e7_line(r08, r"^\s*LOCO R2 ([0-9.]+); CI \[np\.float64\(([0-9.]+)\), np\.float64\(([0-9.]+)\)\]; bootstrap SD np\.float64\(([0-9.]+)\)", "R2")
    if m:
        r2, lo, hi, bsd = map(float, m)
        for mac, val, key in (("NRtwoCov", r2, "pred.y_cov.gbr.r2"), ("NRtwoCovLo", lo, "pred.y_cov.gbr.ci_lo"),
                              ("NRtwoCovHi", hi, "pred.y_cov.gbr.ci_hi")):
            put(mac, fixed(val, 2), PNf, f"{key} (unrounded {val!r} from {r08}, the email-7 refit of paper_numbers.py)", val, "2 dp")
            pn_match(mac, val, key)
        put("NBootSd", fixed(bsd, 3), PNf, f"pred.y_cov.gbr.boot_sd (unrounded {bsd!r} from {r08})", bsd, "3 dp")
        pn_match("NBootSd", bsd, "pred.y_cov.gbr.boot_sd")
        guard_e7("NBootSd", r08, "E7.6 clade-bootstrap SD of LOCO R2", mine=bsd)
    for mac, key, places in (("NRtwoAurocOnly", "pred.y_cov.auroc_only.r2", 2), ("NScreenAuroc", "screen.labelfree_auroc", 3),
                             ("NScreenAP", "screen.labelfree_ap", 3), ("NScreenAurocOnly", "screen.auroc_only_auroc", 3)):
        ok, a_, b_ = decided(pn(key), 4, lambda x, p=places: fixed(x, p))
        if ok:
            put(mac, a_, PNf, key, pn(key), f"{places} dp; decided over the 4-dp rounding interval")
        else:
            needs(mac, PNf, key, f"4-dp value leaves {a_} or {b_}", "UNDECIDED")
            fail("ROUNDING", mac, f"{key}={pn(key)} leaves {a_} or {b_}")
    # screening top 10%
    topk, tk_line = code_value(f"{SRC}/paper_numbers.py", r"^for topk in \[([0-9.]+),", float, "topk")
    _, k_line = code_value(f"{SRC}/paper_numbers.py", r"^\s+(k)=int\(round\(topk\*len\(p\)\)\); idx=np\.argsort\(-pr_lf\)\[:k\]$", str, "topk k")
    k = int(round(topk * len(P)))
    caught = pn("screen.top10.caught")
    put("NTopTenCaught", integer(caught), PNf, "screen.top10.caught", rule="integer")
    put("NTopTenRecallPct", pct(caught / pn("screen.n_severe"), 0), PNf,
        "100*screen.top10.caught/screen.n_severe", caught / pn("screen.n_severe"), "percent, 0 dp")
    pn_match("NTopTenRecallPct", caught / pn("screen.n_severe"), "screen.top10.recall")
    put("NTopTenPrecPct", pct(caught / k, 0), PNf,
        f"100*screen.top10.caught/k, k=int(round({topk}*{len(P)})) [paper_numbers.py l.{tk_line}, l.{k_line}]", caught / k, "percent, 0 dp")
    pn_match("NTopTenPrecPct", caught / k, "screen.top10.precision")

    # ---- feature correlations (unrounded, pairs file) ----
    for c in F:
        pn_match(f"rho:{c}", rho[c], f"feat.{c}.rho_broken")
    phy_rho = max(abs(rho[c]) for c in PHY); nov_rho = max(abs(rho[c]) for c in NOV)
    put("NPhyloRhoMax", ceil(phy_rho, 3), PQf, f"CEILING(max |spearman(f, y_broken)| over {PHY}) [= feat.phylo.absrho_max]",
        phy_rho, "upper bound: ceiling at 3 dp")
    pn_match("NPhyloRhoMax", phy_rho, "feat.phylo.absrho_max")
    put("NNoveltyRhoMax", ceil(nov_rho, 3), PQf, f"CEILING(max |spearman(f, y_broken)| over {NOV}) [= feat.novelty.absrho_max]",
        nov_rho, "upper bound: ceiling at 3 dp")
    pn_match("NNoveltyRhoMax", nov_rho, "feat.novelty.absrho_max")
    put("NMinScoreRho", fixed(rho["f_minscore_mean"], 3), PQf, "spearman(f_minscore_mean, y_broken) [= feat.f_minscore_mean.rho_broken]",
        rho["f_minscore_mean"], "3 dp")
    pn_match("NMinScoreRho", rho["f_minscore_mean"], "feat.f_minscore_mean.rho_broken")
    put("NEmptyRho", fixed(rho["f_empty_rate"], 3), PQf, "spearman(f_empty_rate, y_broken) [= feat.f_empty_rate.rho_broken]",
        rho["f_empty_rate"], "3 dp")
    rank_rho = sorted(F, key=lambda c: -abs(rho[c])).index("f_empty_rate") + 1
    put("NEmptyRankRho", ORD[rank_rho - 1], PQf, "rank of f_empty_rate by |spearman(f, y_broken)| (Fig. 3 order)", rank_rho, "ordinal word")
    guard_e7("NEmptyRankRho", f"{S67}/r07_fig3_rank.out", "E7.6 empty-set rate rank in Fig. 3 (by |Spearman rho|)",
             mine_str=str(rank_rho))
    wps = float(P.y_cov_sd.mean())
    put("NWithinPairSd", fixed(wps, 3), PQf, "mean(y_cov_sd) [= cov.within_pair_sd]", wps, "3 dp")
    pn_match("NWithinPairSd", wps, "cov.within_pair_sd")

    # ---- importances: unrounded from the refit (Slurm) when present, else PAPER_NUMBERS + rounding interval ----
    REF = "derived/icb0_refit.json"
    refit = jload(REF) if os.path.exists(os.path.join(ROOT, REF)) else None
    if refit:
        imp = refit["importances_y_broken_unrounded"]
        for rel_, h_ in refit["inputs_sha256"].items():
            cross("refit-inputs", cites(rel_, h_), f"the refit read {rel_} with sha256 {h_[:12]}, not the manifest's file")
        cross("refit-inputs", all(refit["reproduction_checks"].values()), "the refit did not reproduce the stored values")
        for c in F:
            pn_match(f"imp:{c}", imp[c], f"imp.{c}.y_broken")
        cross("refit-groups", refit["phylo_features"] == PHY and refit["novelty_features"] == NOV, "feature groups differ")
        src_imp, how = REF, "unrounded refit (paper_numbers.py l.123 verbatim)"
    else:
        imp = {c: pn(f"imp.{c}.y_broken") for c in F}
        src_imp, how = PNf, "4-dp stored value, decided over its rounding interval"
    places_imp = None if refit else 4

    def imp_macro(mac, x, f, key, rule):
        if places_imp is None:
            put(mac, f(x), src_imp, key, x, rule + "; " + how)
            return
        ok, a_, b_ = decided(x, places_imp, f)
        if ok:
            put(mac, a_, src_imp, key, x, rule + "; " + how)
        else:
            needs(mac, src_imp, key, f"needs the unrounded value ({REF}, Slurm job icb0_refit): the stored {x} leaves {a_} or {b_}",
                  "PENDING-REFIT")
            note(f"PENDING-REFIT {mac}: {key} = {x} leaves {a_} or {b_}; the refit job decides it")

    phy_imp = max(imp[c] for c in PHY); nov_imp = max(imp[c] for c in NOV)
    imp_macro("NPhyloImpMax", phy_imp, lambda x: ceil(x, 3), f"CEILING(max importance over {PHY}) [imp.phylo.max]", "upper bound: ceiling at 3 dp")
    imp_macro("NMinDistImp", imp["f_dist_min_mean"], lambda x: fixed(x, 3), "imp.f_dist_min_mean.y_broken", "3 dp")
    imp_macro("NNoveltyImpMax", nov_imp, lambda x: ceil(x, 3), f"CEILING(max importance over {NOV}) [imp.novelty.max]", "upper bound: ceiling at 3 dp")
    imp_macro("NMinScoreImp", imp["f_minscore_mean"], lambda x: fixed(x, 3), "imp.f_minscore_mean.y_broken", "3 dp")
    imp_macro("NEmptyImp", imp["f_empty_rate"], lambda x: fixed(x, 3), "imp.f_empty_rate.y_broken", "3 dp")
    guard_e7("NEmptyImp", f"{S67}/r07_fig3_rank.out", "E7.6 empty-set rate importance",
             mine=imp["f_empty_rate"], tol=1e-12 if refit else 5e-5)
    imp_macro("NImpBound", max(phy_imp, nov_imp), lambda x: ceil(x, 2),
              "CEILING(max(imp.phylo.max, imp.novelty.max)) at 2 dp", "upper bound: ceiling at 2 dp")
    order_imp = sorted(F, key=lambda c: -imp[c])
    rank_imp = order_imp.index("f_empty_rate") + 1
    gap_ok = all(abs(imp[order_imp[i]] - imp[order_imp[i + 1]]) > (0 if refit else 1e-4)
                 for i in range(max(0, rank_imp - 2), min(len(F) - 1, rank_imp)))
    if gap_ok:
        put("NEmptyRankImp", ORD[rank_imp - 1], src_imp, "rank of f_empty_rate by imp.*.y_broken", rank_imp, "ordinal word; " + how)
    else:
        needs("NEmptyRankImp", src_imp, "rank by importance", "neighbouring importances tie within rounding", "PENDING-REFIT")
    guard_e7("NEmptyRankImp", f"{S67}/r07_fig3_rank.out", "E7.6 empty-set rate rank by gradient-boosting importance",
             mine_str=str(rank_imp))

    # ---- novelty ablation (R2 differences; 4-dp stored values on both sides) ----
    for mac, t in (("NDropNoveltyCov", "y_cov"), ("NDropNoveltyBroken", "y_broken")):
        a_, b_ = pn(f"pred.{t}.gbr_nonovel.r2"), pn(f"pred.{t}.gbr.r2")
        d = D(str(a_)) - D(str(b_))
        # each side is rounded to 4 dp, so the true difference lies within d +/- 0.0001 (open)
        half = Decimal("0.0001"); tiny = Decimal("1e-16")
        lo_, hi_ = fixed(abs(d - half + tiny), 3), fixed(abs(d + half - tiny), 3)
        same_sign = (d - half + tiny) * (d + half - tiny) > 0
        if lo_ == hi_ and same_sign:
            put(mac, lo_, PNf, f"abs(pred.{t}.gbr_nonovel.r2 - pred.{t}.gbr.r2)", float(d), "3 dp; decided over both rounding intervals")
            put(mac + "Dir", "raises" if d > 0 else "lowers", PNf, f"sign(pred.{t}.gbr_nonovel.r2 - pred.{t}.gbr.r2)",
                float(d), "word from the sign")
        else:
            needs(mac, PNf, t, f"4-dp values leave {lo_} or {hi_}", "UNDECIDED"); needs(mac + "Dir", PNf, t, "sign undecided", "UNDECIDED")
            fail("ROUNDING", mac, "undecided")
        abl = jload(f"{RES}/derived_abstract_claims.json").get(f"ablation.novelty.{t}", {})
        cross(mac, abl.get("abs_delta") == round(abs(float(d)), 4), "derived_abstract_claims.json ablation differs")

    # ---- cohort, tree, features, code constants ----
    CR = jload(f"{RES}/cohort_report.json"); PB = jload(f"{RES}/phylo_build_report.json")
    put("NCohortN", integer(CR["n_in_cohort"]), f"{RES}/cohort_report.json", "n_in_cohort", rule="integer")
    cross("NCohortN", jload(f"{RES}/features_report.json").get("cohort_n") == CR["n_in_cohort"], "features_report cohort_n differs")
    put("NLineages", integer(len(CR["lineage_counts"])), f"{RES}/cohort_report.json", "len(lineage_counts)", rule="integer")
    cross("NLineages", jload(f"{RES}/derived_abstract_claims.json")["cohort.lineages"]["n_lineages"] == len(CR["lineage_counts"]), "lineage count differs")
    cross("NLineages", sum(CR["lineage_counts"].values()) == CR["n_in_cohort"], "lineage counts do not sum to the cohort")
    put("NSublineages", integer(CR["n_sublineages"]), f"{RES}/cohort_report.json", "n_sublineages", rule="integer")
    cross("NSublineages", len(CR["sublineage_counts"]) == CR["n_sublineages"], "sublineage list length differs")
    put("NTreeLeaves", integer(PB["n_leaves"]), f"{RES}/phylo_build_report.json", "n_leaves", rule="integer")
    cross("NTreeLeaves", CR["n_tree_leaves"] == PB["n_leaves"], "cohort_report n_tree_leaves differs")
    bp = f"{SRC}/build_phylo.py"
    ntri, l_tri = code_value(bp, r"^i, j, k = \(rng\.integers\(0, n, ([0-9_]+)\) for _ in range\(3\)\)$", lambda s: int(s.replace("_", "")), "NTriples")
    nquad, l_quad = code_value(bp, r"^a, b, x, y = \(rng\.integers\(0, n, ([0-9_]+)\) for _ in range\(4\)\)$", lambda s: int(s.replace("_", "")), "NQuads")
    put("NTriples", sci_math(ntri), bp, f"rng.integers(0, n, ...) at l.{l_tri}: sampled triples", ntri, "LaTeX math")
    cross("NTriples", f"triangle_violations_of_{ntri // 1000}k" in PB["checks"], "phylo_build_report key does not name this sample size")
    put("NQuads", sci_math(nquad), bp, f"rng.integers(0, n, ...) at l.{l_quad}: sampled quadruples", nquad, "LaTeX math")
    cross("NQuads", f"four_point_violations_of_{nquad // 1000}k" in PB["checks"], "phylo_build_report key does not name this sample size")
    agree = PB["checks"]["independent_walk_max_abs_err"]
    put("NTreeAgree", sci_math(agree, 2), f"{RES}/phylo_build_report.json", "checks.independent_walk_max_abs_err", agree,
        "LaTeX math, 2 significant digits (as printed)")
    with np.load(inp(f"{RES}/X_nonsyn.npz"), allow_pickle=False) as z:
        shape = [int(v) for v in z["shape"]]
    put("NFeatures", integer(shape[1]), f"{RES}/X_nonsyn.npz", "shape[1] (columns of X_nonsyn)", rule="integer")
    cross("NFeatures", jload(f"{RES}/features_report.json")["matrices"]["nonsyn"]["shape"] == shape, "features_report shape differs")
    cross("NFeatures", shape[0] == CR["n_in_cohort"], "X_nonsyn rows differ from the cohort")
    e2p = f"{SRC}/e2_conformal.py"
    minac, l_ac = code_value(e2p, r"^MIN_AC=int\(sys\.argv\[2\]\) if len\(sys\.argv\)>2 else (\d+)$", int, "NMinAC")
    put("NMinAC", integer(minac), e2p, f"MIN_AC default at l.{l_ac}", minac, "integer")
    cross("NMinAC", os.path.exists(os.path.join(ROOT, f"{RES}/e2_conformal_nonsyn_ac{minac}.json")), "the e2 result file is not the ac-default run")
    for other in ("e3_shift_diagnosis.py", "e5_selective.py", "c2v2_coverage_prediction.py", "check_cal_variance.py"):
        v_, _ = code_value(f"{SRC}/{other}", r"MIN_AC=(\d+)", int, f"MIN_AC:{other}")
        cross("NMinAC", v_ == minac, f"{other} uses MIN_AC={v_}")
    c2 = f"{SRC}/c2v2_coverage_prediction.py"
    cmin, l_c = code_value(c2, r"MIN_CLADE=(\d+);", int, "NCladeMinSize")
    ndraw, l_d = code_value(c2, r"NDRAW=(\d+);", int, "NDrawsPerPair")
    put("NCladeMinSize", integer(cmin), c2, f"MIN_CLADE at l.{l_c}", cmin, "integer")
    put("NDrawsPerPair", integer(ndraw), c2, f"NDRAW at l.{l_d}", ndraw, "integer")
    cross("NDrawsPerPair", set(P.n_draws.unique()) == {ndraw}, f"pairs file n_draws {sorted(P.n_draws.unique())} != {ndraw}")

    # ---- random split (e2) ----
    E2f = f"{RES}/e2_conformal_nonsyn_ac{minac}.json"; E2 = jload(E2f)
    alpha2, _ = code_value(e2p, r"^ALPHA=([0-9.]+)$", float, "ALPHA e2")
    marg, l_m = code_value(e2p, r'flag=" <-- UNDERCOVER" if v\["coverage"\]<1-ALPHA-([0-9.]+) else ""', float, "margin")
    covs = [v["coverage"] for v in E2["random"].values()]
    thr2 = D(1) - D(alpha2) - D(marg)
    put("NRandCov", fixed(float(np.mean(covs)), 3), E2f, f"mean(random[*].coverage) over {len(covs)} drugs", float(np.mean(covs)), "3 dp (as printed)")
    nund = sum(D(x) < thr2 for x in covs)
    put("NRandUnder", integer(nund), E2f, f"count(random[*].coverage < 1-ALPHA-{marg}) [e2_conformal.py l.{l_m}]", nund, "integer")

    # ---- pairs-file class means, domain AUROC (email 7 items 3 and 6) ----
    r04 = f"{S67}/r04_reserve_vs_well.out"
    for mac, ser, label in (("NWellAuroc", well.auroc, "E7.3 other (well-characterised) mean AUROC"),
                            ("NReserveAuroc", res.auroc, "E7.3 reserve mean AUROC"),
                            ("NWellCov", well.y_cov, "E7.3 other (well-characterised) mean coverage"),
                            ("NReserveCov", res.y_cov, "E7.3 reserve mean coverage")):
        x = float(ser.mean())
        put(mac, fixed(x, 3), PQf, f"mean({ser.name}) over {'well-characterised' if 'Well' in mac else 'reserve'} pairs", x, "3 dp (as email 7)")
        guard_e7(mac, r04, label, mine=x)
    r10 = f"{S67}/r10_domain_auc.out"
    dm, dn = float(P.f_domain_auc.mean()), float(P.f_domain_auc.min())
    put("NDomainAucMean", fixed(dm, 4), PQf, "mean(f_domain_auc) over the 491 clade holdouts", dm, "4 dp (as email 7)")
    guard_e7("NDomainAucMean", r10, "E7.6 domain-classifier AUROC mean over 491 holdouts (canonical)", mine=dm)
    put("NDomainAucMin", fixed(dn, 3), PQf, "min(f_domain_auc)", dn, "3 dp (as email 7)")
    guard_e7("NDomainAucMin", r10, "E7.6 domain-classifier AUROC minimum (canonical)", mine=dn)

    # ---- calibration-draw instability (cal_variance.json, RIF) ----
    CVf = f"{RES}/cal_variance.json"; CV = jload(CVf)["drugs"]["RIF"]
    vals = CV["coverage"]["all"]
    cross("NBimodalDraws", len(vals) == CV["n_draws"], "n_draws differs from the list length")
    put("NBimodalDraws", integer(CV["n_draws"]), CVf, "drugs.RIF.n_draws", rule="integer")
    r09s = "nums_67/27baf2c/e7/r09_cal_clusters_recount.py"
    G, l_g = code_value(r09s, r"^G = ([0-9.]+)$", float, "cluster rule")
    v = sorted(vals)
    runs, cur = [], [v[0]]
    for a_, b_ in zip(v, v[1:]):
        if D(b_) - D(a_) <= D(G):
            cur.append(b_)
        else:
            runs.append(cur); cur = [b_]
    runs.append(cur)
    lo_c, hi_c = sorted(sorted(runs, key=len, reverse=True)[:2], key=lambda r_: r_[0])
    btw = [x for x in v if lo_c[-1] < x < hi_c[0]]
    cross("clusters", len(lo_c) + len(hi_c) + len(btw) == len(v), "the partition does not cover every draw once")
    steps_in = max(D(b_) - D(a_) for r_ in (lo_c, hi_c) for a_, b_ in zip(r_, r_[1:]))
    edge = min(D(btw[0]) - D(lo_c[-1]), D(hi_c[0]) - D(btw[-1])) if btw else D(hi_c[0]) - D(lo_c[-1])
    cross("clusters", steps_in <= D(G) < edge, f"G={G} is not inside the invariance interval [{steps_in}, {edge})")
    gaps = sorted((D(b_) - D(a_) for a_, b_ in zip(v, v[1:])), reverse=True)
    ncut = sum(g > D(G) for g in gaps)
    note(f"clusters: sorted coverages cut at the {ncut} largest gaps (every gap > G={G}, the email-7 rule, {r09s} l.{l_g}); "
         f"low {len(lo_c)}, high {len(hi_c)}, between {len(btw)}; same partition for every G in [{steps_in}, {edge})")
    rule_txt = f"gap rule of {r09s} l.{l_g} (G={G}); clusters = the two largest runs"
    lo_m, hi_m = float(np.mean(lo_c)), float(np.mean(hi_c))
    put("NBimodalLow", fixed(lo_m, 2), CVf, f"mean of the low cluster ({len(lo_c)} draws); {rule_txt}", lo_m, "2 dp (as printed)")
    put("NBimodalHigh", fixed(hi_m, 2), CVf, f"mean of the high cluster ({len(hi_c)} draws); {rule_txt}", hi_m, "2 dp (as printed)")
    put("NBimodalBetween", integer(len(btw)), CVf, f"draws strictly between the clusters; {rule_txt}", len(btw), "integer")
    put("NBimodalBetweenVals", and_list(fixed(x, 2) for x in btw), CVf, f"their coverages; {rule_txt}", btw, "2 dp list")
    r09o = f"{S67}/r09_cal_clusters_recount.out"
    guard_e7("NBimodalDraws", r09o, "E7.6 recount: total draws (RIF, lineage-2)", mine_str=str(len(vals)))
    guard_e7("NBimodalBetween", r09o, "E7.6 recount: draws between the two clusters (gap rule G=0.02)", mine_str=str(len(btw)))
    mline = e7_line(r09o, r"^\s*total draws (\d+); low cluster (\d+) \(([0-9.]+)-([0-9.]+)\); high (\d+) \(([0-9.]+)-([0-9.]+)\); between \[(.*)\]$", "clusters")
    if mline:
        cross("NBimodalBetweenVals", [float(x) for x in mline[7].split(",")] == btw and int(mline[1]) == len(lo_c)
              and int(mline[4]) == len(hi_c), "partition differs from the email-7 recount")
    mm = doc_findall(r"Three of the 30 draws \(coverage ([0-9., and]+)\) lie between")
    cross("NBimodalBetweenVals", mm == [and_list(fixed(x, 2) for x in btw)], f"EMAIL_67 wording lists {mm}")
    put("NBimodalMean", fixed(CV["coverage"]["mean"], 3), CVf, "drugs.RIF.coverage.mean", CV["coverage"]["mean"], "3 dp (stored 3 dp)")
    cross("NBimodalMean", fixed(float(np.mean(vals)), 3) == fixed(CV["coverage"]["mean"], 3), "mean of the 30 stored draws differs")
    put("NBimodalSd", fixed(CV["coverage"]["sd"], 3), CVf, "drugs.RIF.coverage.sd (np.std, ddof 0)", CV["coverage"]["sd"], "3 dp (stored 3 dp)")
    cross("NBimodalSd", fixed(float(np.std(vals)), 3) == fixed(CV["coverage"]["sd"], 3), "sd of the 30 stored draws differs")
    for mac, key in (("NQhatLo", "min"), ("NQhatHi", "max")):
        ok, a_, b_ = decided(CV["qhat"][key], 4, lambda x: fixed(x, 3))
        if ok:
            put(mac, a_, CVf, f"drugs.RIF.qhat.{key}", CV["qhat"][key], "3 dp (as printed); decided over the 4-dp interval")
        else:
            needs(mac, CVf, key, "undecided", "UNDECIDED"); fail("ROUNDING", mac, "undecided")
    if refit:
        rl = refit["rif_lineage2"]
        cross("NAurocStab", [round(x, 4) for x in rl["coverage"]] == vals, "refit coverages differ from cal_variance.json")
        hr = rl["auroc_half_range"]
        put("NAurocStab", fixed(hr, 3), REF, "(max - min)/2 of the 30 unrounded RIF AUROCs (check_cal_variance.py l.19-36 verbatim)",
            hr, "3 dp (as printed)")
    else:
        rr = text(f"{RES}/cal_variance_rerun_20260906b.txt")
        mr = re.search(r"RIF / Lineage-2.*?AUROC\s*: mean [\d.]+ sd [\d.]+ min ([\d.]+) max ([\d.]+)", rr, re.S)
        lo3, hi3 = D(mr.group(1)), D(mr.group(2))
        cand = sorted({fixed((hi3 - lo3 + s) / 2, 3) for s in (Decimal("-0.000999"), Decimal("0.000999"))})
        needs("NAurocStab", f"{RES}/cal_variance_rerun_20260906b.txt", "AUROC min/max (3 dp)",
              f"recorded min/max are 3 dp ({lo3}, {hi3}); the half-range can be {' or '.join(cand)}", "PENDING-REFIT")
        note(f"PENDING-REFIT NAurocStab: recorded AUROC min/max {lo3}/{hi3} (3 dp) leave {' or '.join(cand)}; the refit job decides it")

    # ---- weight degeneracy ----
    WDf = f"{RES}/weight_degeneracy.json"; WD = jload(WDf)
    L2T = WD["lineage2_holdout|tree"]
    nar = min(L2T, key=lambda r_: r_["bandwidth_x_median"]); wide = max(L2T, key=lambda r_: r_["bandwidth_x_median"])
    put("NCosMean", fixed(nar["cos_mean"], 4), WDf, "lineage2_holdout|tree[narrow].cos_mean", nar["cos_mean"], "4 dp (as printed)")
    guard_e7("NCosMean", f"{S67}/r12c_cosine.out",
             "E7 kept: mean pairwise cosine of normalised tree-kernel weights, lineage-2 holdout, h=0.25x", mine=nar["cos_mean"])
    put("NCosMin", fixed(nar["cos_min"], 4), WDf, "lineage2_holdout|tree[narrow].cos_min", nar["cos_min"], "4 dp (as printed)")
    put("NTvMean", fixed(nar["tv_mean"], 4), WDf, "lineage2_holdout|tree[narrow].tv_mean", nar["tv_mean"], "4 dp (as printed)")
    put("NBwNarrow", fixed(nar["bandwidth_x_median"], 2), WDf, "smallest bandwidth_x_median", nar["bandwidth_x_median"], "2 dp (as printed)")
    put("NBwWide", fixed(wide["bandwidth_x_median"], 1), WDf, "largest bandwidth_x_median", wide["bandwidth_x_median"], "1 dp (as printed)")
    # \NCosWide and \NWideRelDiffMaxPct (ANSWERS_16Oct_ICB0 Q2; they replace the retired \NIdentDecimals). Same setting
    # as \NCosMean except the bandwidth. The element-wise quantity is not stored in weight_degeneracy.json: it comes from
    # wd_replay_l2.py, a no-fit replay of the same draws that must reproduce every stored field of that JSON.
    RPf = "derived/wd_replay_l2.json"
    rp = jload(RPf) if os.path.exists(os.path.join(ROOT, RPf)) else None
    if not {"NCosWide", "NWideRelDiffMaxPct"} <= set(AMEND["added"]):
        fail("AMEND", "NCosWide", f"{AMEND['file']} does not define NCosWide and NWideRelDiffMaxPct")
    elif rp is None:
        fail("INPUT-MANIFEST", "NCosWide", f"{RPf} is missing (run wd_replay_l2.py)")
    else:
        cross("NCosWide", rp["replay_check_max_abs_diff"] <= 1e-12, "the replay does not reproduce weight_degeneracy.json")
        rec = [r_ for r_ in rp["rows_recomputed"] if r_["bandwidth_x_median"] == wide["bandwidth_x_median"]]
        cross("NCosWide", len(rec) == 1 and abs(rec[0]["cos_mean"] - wide["cos_mean"]) <= 1e-12,
              "the replay's recomputed wide-bandwidth cos_mean differs from weight_degeneracy.json")
        p_cw = AMEND["added"]["NCosWide"]["places"]
        put("NCosWide", fixed(wide["cos_mean"], p_cw), WDf, "lineage2_holdout|tree[wide].cos_mean (= the replay's recomputed value)",
            wide["cos_mean"], f"{p_cw} dp ({AMEND['file']} Q2)")
        wrow = [b for b in rp["by_bandwidth"] if b["bandwidth_x_median"] == wide["bandwidth_x_median"]][0]
        am = wrow["argmax_entry"]
        cross("NWideRelDiffMaxPct", abs((am["w_large"] - am["w_small"]) / am["w_small"] - wrow["max_rel_elementwise_diff"]) <= 1e-12,
              "the stored maximum is not (w_large - w_small)/w_small at its own argmax entry")
        p_rd = AMEND["added"]["NWideRelDiffMaxPct"]["places"]
        put("NWideRelDiffMaxPct", pct(wrow["max_rel_elementwise_diff"], p_rd), RPf,
            f"100 x {rp['rel_diff_definition']}; at bandwidth {wide['bandwidth_x_median']} x median, lineage2_holdout, patristic "
            f"distance; n_test {rp['n_test']}, n_cal {rp['n_cal']} (the draws of weight_degeneracy.json)",
            wrow["max_rel_elementwise_diff"], f"percent, {p_rd} dp ({AMEND['file']} Q2)")
        note(f"NWideRelDiffMaxPct: denominator = the smaller of the two weights; with the larger weight the maximum is "
             f"{wrow['context_max_rel_diff_over_larger_weight']:.4f}, with their mean {wrow['context_max_rel_diff_over_mean_weight']:.4f} "
             f"(percent at {p_rd} dp: {pct(wrow['max_rel_elementwise_diff'], p_rd)}, {pct(wrow['context_max_rel_diff_over_larger_weight'], p_rd)}, "
             f"{pct(wrow['context_max_rel_diff_over_mean_weight'], p_rd)}); the smallest weight at this bandwidth is "
             f"{wrow['min_weight_over_uniform']:.3f} x the uniform weight 1/n_cal, so no near-zero weight inflates the ratio")
    rnd = [r_ for r_ in WD["random_holdout|tree"] if r_["bandwidth_x_median"] == nar["bandwidth_x_median"]][0]
    put("NCosRandom", fixed(rnd["cos_mean"], 3), WDf, "random_holdout|tree[narrow].cos_mean", rnd["cos_mean"], "3 dp (as printed)")
    snp = [r_ for r_ in WD["lineage2_holdout|snp"] if r_["bandwidth_x_median"] == nar["bandwidth_x_median"]][0]
    put("NCosSnp", fixed(snp["cos_mean"], 4), WDf, "lineage2_holdout|snp[narrow].cos_mean", snp["cos_mean"], "4 dp (as printed)")
    SDf = f"{RES}/snp_distance.json"; SDj = jload(SDf)
    put("NSnpPatSpearman", fixed(SDj["tree_vs_snp_spearman"], 3), SDf, "tree_vs_snp_spearman (not in weight_degeneracy.json)",
        SDj["tree_vs_snp_spearman"], "3 dp (as printed)")
    put("NSnpPatPearson", fixed(SDj["tree_vs_snp_pearson"], 3), SDf, "tree_vs_snp_pearson (not in weight_degeneracy.json)",
        SDj["tree_vs_snp_pearson"], "3 dp (as printed)")

    # ---- shift diagnosis and Table 1 (e3) ----
    E3f = f"{RES}/e3_shift_diagnosis.json"; E3 = jload(E3f)
    pr = {(s_, d_): v_["prior_ratio"] for s_, dd in E3.items() for d_, v_ in dd.items()}
    pmax = max(pr.values())
    put("NPriorRatioMax", fixed(pmax, 2), E3f, f"max prior_ratio over splits and drugs ({max(pr, key=pr.get)})", pmax, "2 dp (as printed)")
    disc = {s_: [v_["pxy_discriminator_auc"][c_] for v_ in dd.values() for c_ in ("S", "R")] for s_, dd in E3.items()}
    for s_ in disc:
        cross("disc", all(x is not None for x in disc[s_]), f"{s_} has a missing discriminator AUC")
    dl, rlo, rhi = min(disc["lineage2_blocked"]), min(disc["random"]), max(disc["random"])
    put("NDiscAucLineage", fixed(dl, 3), E3f, "min over drugs and classes of lineage2_blocked[*].pxy_discriminator_auc", dl, "3 dp (as printed)")
    put("NDiscAucRandLo", fixed(rlo, 3), E3f, "min over random[*].pxy_discriminator_auc", rlo, "3 dp (as printed)")
    put("NDiscAucRandHi", fixed(rhi, 3), E3f, "max over random[*].pxy_discriminator_auc", rhi, "3 dp (as printed)")
    DAC = jload(f"{RES}/derived_abstract_claims.json")
    cross("disc", (DAC["pxy.lineage2_blocked"]["min"], DAC["pxy.random"]["min"], DAC["pxy.random"]["max"]) ==
          (round(dl, 4), round(rlo, 4), round(rhi, 4)), "derived_abstract_claims.json pxy differs")
    thr = {DAC[k]["threshold"] for k in DAC if k.startswith("tab2.")}
    cross("NTabUnderThr", len(thr) == 1, f"tab2 thresholds {thr}")
    THR = thr.pop()
    e3thr, l_thr = code_value(f"{SRC}/e3_shift_diagnosis.py", r"undercovered \{sum\(1 for x in c if x<([0-9.]+)\)\}", float, "NTabUnderThr")
    cross("NTabUnderThr", e3thr == THR, "e3 print threshold differs")
    ndr = {len(dd) for dd in E3.values()}
    cross("NTabDrugs", len(ndr) == 1, f"drug counts per split {ndr}")
    put("NTabDrugs", integer(ndr.pop()), E3f, "drugs per split", rule="integer")
    put("NTabUnderThr", fixed(THR, 2), f"{RES}/derived_abstract_claims.json",
        f"tab2.*.threshold (= e3_shift_diagnosis.py l.{l_thr})", THR, "2 dp (as printed)")
    NE3 = jload("amrconf/paper/icbinb/numbers_e3.json")
    SPL = {"Random": "random", "Sub": "sublineage_blocked", "Lin": "lineage2_blocked"}
    VAR = {"Vanilla": "vanilla", "Mondrian": "class_conditional", "Oracle": "oracle_prior", "Covshift": "covshift_weighted"}
    for vn, vk in VAR.items():
        for sn, sk in SPL.items():
            cs = [E3[sk][d_]["variants"][vk]["coverage"] for d_ in E3[sk]]
            mcov = float(np.mean(cs)); kund = sum(D(x) < D(THR) for x in cs)
            put(f"NT{vn}{sn}", fixed(mcov, 3), E3f, f"mean({sk}[*].variants.{vk}.coverage)", mcov, "3 dp (as printed)")
            put(f"NK{vn}{sn}", integer(kund), E3f, f"count({sk}[*].variants.{vk}.coverage < {THR})", kund, "integer")
            ne = NE3.get(f"{sk}|{vk}")
            cross(f"NT{vn}{sn}", ne is not None and abs(ne[0] - mcov) < 1e-12 and ne[1] == kund and ne[2] == len(cs),
                  f"numbers_e3.json {ne} differs")
            t2 = DAC.get(f"tab2.{sk}.{vk}", {})
            cross(f"NT{vn}{sn}", t2.get("mean_coverage") == round(mcov, 4) and t2.get("n_under_threshold") == kund,
                  "derived_abstract_claims.json tab2 differs")
    guard_e7("NTVanillaLin", f"{S67}/r06_lolo_folds.out", "E7.5 Table 1 lineage-2 vanilla (e3, one draw)",
             mine=V["NTVanillaLin"]["unrounded"])
    guard_e7("NTabDrugs", f"{S67}/r06_lolo_folds.out", "E7.5 drugs behind Table 1's 0.615", mine_str=V["NTabDrugs"]["value"])
    guard_e7("NTVanillaLin", f"{S67}/r12d_mondrian.out", "E7 kept: lineage-2 mean coverage, vanilla", mine=V["NTVanillaLin"]["unrounded"])
    guard_e7("NTMondrianLin", f"{S67}/r12d_mondrian.out", "E7 kept: lineage-2 mean coverage, class-conditional (Mondrian)",
             mine=V["NTMondrianLin"]["unrounded"])

    # ---- four-fold leave-one-lineage-out run (f17_robust, the vanilla logistic-regression cells) ----
    F17f = f"{RES}/f17_robust.parquet"; F17 = parquet(F17f)
    dsrc = text(f"{SRC}/derive_abstract_claims.py")
    sel = '_s = _f[(_f.kind == "lineage_blocked") & (_f.featset == "nonsyn") & (_f.model == "logreg")]'
    cross("NFourFold", sel in dsrc, "derive_abstract_claims.py no longer selects the vanilla LOLO cells this way")
    s17 = F17[(F17.kind == "lineage_blocked") & (F17.featset == "nonsyn") & (F17.model == "logreg")]
    fm = s17.groupby("instance").coverage.mean()
    worst = fm.idxmin()
    r06 = f"{S67}/r06_lolo_folds.out"
    put("NFourFoldMean", fixed(float(s17.coverage.mean()), 3), F17f, "mean coverage over the lineage_blocked/nonsyn/logreg cells",
        float(s17.coverage.mean()), "3 dp (as printed)")
    guard_e7("NFourFoldMean", r06, "E7.5 four-fold mean vanilla coverage", mine=float(s17.coverage.mean()))
    sd17 = float(s17.coverage.std(ddof=1))
    put("NFourFoldSd", fixed(sd17, 3), F17f, f"sample sd (ddof 1) over the {len(s17)} fold x drug cells", sd17, "3 dp (as printed)")
    guard_e7("NFourFoldSd", r06, "E7.5 +/- (sample SD over the 24 fold x drug cells)", mine=sd17)
    put("NFourFoldDrugs", integer(s17.drug.nunique()), F17f, "distinct drugs in those cells", rule="integer")
    guard_e7("NFourFoldDrugs", r06, "E7.5 drugs in the four-fold run", mine_str=str(s17.drug.nunique()))
    cross("NFourFoldDrugs", s17.groupby("instance").drug.nunique().eq(s17.drug.nunique()).all(), "folds are not balanced")
    put("NFourFoldLinTwo", fixed(float(fm["Lineage2"]), 3), F17f, "mean coverage of fold Lineage2", float(fm["Lineage2"]), "3 dp (as email 7)")
    guard_e7("NFourFoldLinTwo", r06, "E7.5 lineage-2 fold mean", mine=float(fm["Lineage2"]))
    put("NFourFoldWorstLin", integer(int(re.fullmatch(r"Lineage(\d+)", worst).group(1))), F17f, "fold with the lowest mean coverage",
        worst, "integer (lineage number)")
    guard_e7("NFourFoldWorstLin", r06, "E7.5 worst fold", mine_str=worst)
    put("NFourFoldWorst", fixed(float(fm[worst]), 3), F17f, f"mean coverage of fold {worst}", float(fm[worst]), "3 dp (as email 7)")
    guard_e7("NFourFoldWorst", r06, "E7.5 lineage-3 fold mean", mine=float(fm[worst]))

    # ---- abstention (e5) ----
    E5f = f"{RES}/e5_selective.json"; E5 = jload(E5f); e5p = f"{SRC}/e5_selective.py"
    drugs5, l_dr = code_value(e5p, r'^DRUGS=(\[.*\])$', ast.literal_eval, "NAbstDrugs")
    budgets, l_bu = code_value(e5p, r'^BUDGETS=(\[.*\])$', ast.literal_eval, "budgets")
    b20, l_b20 = code_value(e5p, r'c=\[x for x in r\[d\]\["curves"\]\[rule\] if x\.get\("budget"\)==([0-9.]+) and', float, "budget")
    L2 = E5["lineage2_blocked"]
    cross("NAbstDrugs", list(L2) == drugs5, "e5 JSON drug list differs from DRUGS")
    put("NAbstDrugs", integer(len(drugs5)), e5p, f"len(DRUGS) at l.{l_dr}", len(drugs5), "integer")

    def vme(dr, rule, b):
        c_ = [x for x in L2[dr]["curves"][rule] if x["budget"] == b]
        if len(c_) != 1 or c_[0].get("insufficient"):
            fail("CROSS", "e5", f"{dr} {rule} budget {b}: no usable point"); return float("nan")
        return c_[0]["vme"]

    b0, bmax = min(budgets), max(budgets)
    mean20 = {rule: float(np.mean([vme(d_, rule, b20) for d_ in L2])) for rule in ("confidence", "phylo", "snp", "random")}
    none = float(np.mean([vme(d_, "confidence", b0) for d_ in L2]))
    cross("NVmeNone", all(vme(d_, r_, b0) == vme(d_, "confidence", b0) for d_ in L2 for r_ in ("phylo", "snp", "random", "oracle")),
          "budget-0 VME differs between rules")
    key20 = f"lineage2_blocked: mean over {len(L2)} drugs of curves[{{rule}}] at budget {b20} (e5_selective.py l.{l_b20})"
    r01 = f"{S67}/r01_vme_lineage2.out"
    for mac, rule, label in (("NVmeConf", "confidence", None), ("NVmePat", "phylo", "E7.1 patristic mean VME @20%, lineage-2, 9 drugs"),
                             ("NVmeSnp", "snp", "E7.1 SNP mean VME @20%, lineage-2")):
        put(mac, fixed(mean20[rule], 4), E5f, key20.format(rule=rule), mean20[rule], "4 dp (as printed)")
        if label:
            guard_e7(mac, r01, label, mine=mean20[rule])
    cl = e7_line(r01, r"^\s*mean VME @20% lineage-2, confidence = ([0-9.]+)$", "NVmeConf")
    cross("NVmeConf", cl is not None and abs(float(cl) - mean20["confidence"]) <= 1e-12, "differs from the email-7 r01 line")
    put("NVmeNone", fixed(none, 4), E5f, f"lineage2_blocked: mean over drugs of the VME at budget {b0} (no abstention)", none, "4 dp (as email 7)")
    guard_e7("NVmeNone", r01, "E7.1 no-abstention mean VME, lineage-2", mine=none)
    beats = sum(vme(d_, "phylo", b20) < vme(d_, "confidence", b20) for d_ in L2)
    put("NPatBeatsConf", integer(beats), E5f, f"count of drugs with phylo VME < confidence VME at budget {b20}", beats, "integer")
    guard_e7("NPatBeatsConf", r01, "E7.1 drugs on which patristic beats confidence (strictly lower VME)", mine_str=f"{beats} of {len(L2)}")
    worse = [d_ for d_ in L2 if vme(d_, "phylo", b20) > vme(d_, "phylo", b0)]
    put("NPatWorseThanNone", integer(len(worse)), E5f, f"count of drugs with phylo VME at budget {b20} > VME at budget {b0} ({', '.join(worse)})",
        len(worse), "integer")
    wl = e7_line(r01, r"^\s*context: patristic @20% raises VME above no-abstention on (\d+) of 9 drugs (\[.*\])$", "NPatWorseThanNone")
    cross("NPatWorseThanNone", wl is not None and int(wl[0]) == len(worse) and ast.literal_eval(wl[1]) == worse,
          "differs from the email-7 r01 context line")
    for mac, rule, b in (("NRifConfStart", "confidence", b0), ("NRifConfEnd", "confidence", bmax),
                         ("NRifPatStart", "phylo", b0), ("NRifPatEnd", "phylo", bmax)):
        x = vme("RIF", rule, b)
        put(mac, fixed(x, 3), E5f, f"lineage2_blocked.RIF.curves.{rule} at budget {b}", x, "3 dp (as printed)")
    # 20,000 random-abstention draws (email-7 adversarial check, nums_67 1a3949d)
    P01f = f"{V67}/logs/p01_random_null_e5.json"; P01 = jload(P01f)
    put("NRandDraws", integer(P01["B"]), P01f, "B", rule="integer")
    put("NVmeRandMean", fixed(P01["null_mean"], 4), P01f, "null_mean", P01["null_mean"], "4 dp (VME, as email 7)")
    le, ge = P01["frac_null_le"]["phylo"], P01["frac_null_ge"]["phylo"]
    cross("NPatBelowRandPct", abs(le + ge - 1) < 1e-12, "ties between random draws and patristic: '>' and '>=' differ")
    above = 1 - le
    put("NPatBelowRandPct", pct(above, 1), P01f, "100*(1 - frac_null_le.phylo): share of random draws with higher VME", above,
        "percent, 1 dp (as email 7)")
    cross("NPatBelowRandPct", abs(P01["stored"]["phylo"] - mean20["phylo"]) <= 1e-12, "p01 'stored' patristic VME differs from e5")
    cross("NVmeRandMean", abs(P01["stored"]["none"] - none) <= 1e-12, "p01 'stored' no-abstention VME differs from e5")
    md = doc_findall(r"below (\d+\.\d)% of draws"); mn = doc_findall(r"null mean (0\.\d+), sd")
    cross("NPatBelowRandPct", md == [V["NPatBelowRandPct"]["value"]], f"EMAIL_67 says {md}")
    cross("NVmeRandMean", mn == [V["NVmeRandMean"]["value"]], f"EMAIL_67 says {mn}")
    # discrete conformal abstention, random split, rifampicin
    spec_rows = SPEC_ROWS
    a_from = float(re.search(r"alpha ([0-9.]+)", spec_rows["NAbstFromPct"]["status"]).group(1))
    a_to = float(re.search(r"alpha ([0-9.]+)", spec_rows["NAbstToPct"]["status"]).group(1))
    alphas, l_al = code_value(e5p, r'^ALPHAS=(\[.*\])$', ast.literal_eval, "ALPHAS")
    cross("NAbstFromPct", a_from in alphas and a_to in alphas, "spec alphas not in ALPHAS")
    for mac, al in (("NAbstFromPct", a_from), ("NAbstToPct", a_to)):
        pt = [x for x in E5["random"]["RIF"]["conformal_discrete"] if x["alpha"] == al]
        cross(mac, len(pt) == 1, "alpha point missing")
        put(mac, pct(pt[0]["abstain_rate"], 1), E5f, f"random.RIF.conformal_discrete[alpha={al}].abstain_rate (ALPHAS l.{l_al})",
            pt[0]["abstain_rate"], "percent, 1 dp (as printed)")
    cells = [pt for dd in E5.values() for v_ in dd.values() for pt in v_["conformal_discrete"]]
    same = sum(1 for pt in cells if not pt.get("insufficient") and "matched_confidence_vme" in pt
               and pt["vme"] == pt["matched_confidence_vme"] and pt["acc"] == pt["matched_confidence_acc"])
    put("NCells", integer(len(cells)), E5f, f"conformal_discrete points over splits x drugs x alphas (identical VME and accuracy in {same})",
        len(cells), "integer")
    cross("NCells", same == len(cells), f"only {same} of {len(cells)} cells identical")
    guard_e7("NCells", f"{S67}/r12f_189_cells.out", "E7 kept: cells with identical error rates (VME and accuracy)",
             mine_str=f"{same} of {len(cells)}")

    # ---- seed spread ----
    SSf = f"{RES}/seed_spread.json"; SS = jload(SSf)
    r2s = [x["r2_y_cov"] for x in SS]
    cross("NSeedDraws", len({x["seed"] for x in SS}) == len(SS), "repeated seeds")
    put("NSeedDraws", integer(len(SS)), SSf, "number of records (distinct master seeds)", rule="integer")
    smean, ssd = float(np.mean(r2s)), float(np.std(r2s, ddof=1))
    put("NRtwoCovSeedMean", fixed(smean, 2), SSf, "mean(r2_y_cov)", smean, "2 dp (as printed)")
    put("NRtwoCovSeedSd", fixed(ssd, 3), SSf, "sample sd (ddof 1) of r2_y_cov", ssd, "3 dp (spec)")
    guard_e7("NRtwoCovSeedSd", r08, "E7.6 calibration-seed SD of LOCO R2", mine=ssd)
    cross("NRtwoCovSeedMean", pn("pred.y_cov.gbr.r2") == [x for x in SS if x["seed"] == 0][0]["r2_y_cov"], "seed 0 is not the canonical run")
    if "NBootSd" in V:
        ratio = V["NBootSd"]["unrounded"] / ssd
        put("NSdRatio", fixed(ratio, 1), f"{r08} ; {SSf}", "bootstrap SD (unrounded, r08) / seed SD", ratio, "1 dp (spec)")
        rl_ = e7_line(r08, r"^\s*ratio ([0-9.]+)$", "NSdRatio")
        cross("NSdRatio", rl_ is not None and abs(float(rl_) - ratio) <= 1e-12, "differs from the email-7 r08 ratio")
        cross("NSdRatio", fixed(D(V["NBootSd"]["value"]) / D(V["NRtwoCovSeedSd"]["value"]), 1) == fixed(ratio, 1),
              "the ratio of the printed values rounds differently")

    # ---- identity check (email-7 r12e, the committed re-implementation of the 10^6 check) ----
    r12e = f"{S67}/r12e_identity_1e6.out"
    mi = e7_line(r12e, r"^\s*mismatches over ([\d,]+) x ([\d,]+) = ([\d,]+) draws: (\d+)$", "NMismatchDraws")
    if mi:
        nd = int(mi[2].replace(",", ""))
        cross("NMismatchDraws", int(mi[0].replace(",", "")) * int(mi[1].replace(",", "")) == nd, "draw count arithmetic")
        put("NMismatchDraws", sci_math(nd), r12e, "draws in the 10^6 identity check (r12e, nums_67 27baf2c)", nd, "LaTeX math")
        put("NMismatch", integer(int(mi[3])), r12e, "mismatches found", int(mi[3]), "integer")
        guard_e7("NMismatch", r12e, "E7 kept: mismatches between conformal abstention and |p-0.5|<|q-0.5| over 10^6 draws",
                 mine_str=str(int(mi[3])))

    # ---- ICB-3: the one-feature screen (icb3_screen.py, no fit) and the one-feature linear fit (icb3_refit.py, Slurm)
    S3f, R3f = "derived/icb3_screen.json", "derived/icb3_refit.json"
    if os.path.exists(os.path.join(ROOT, S3f)) and os.path.exists(os.path.join(ROOT, R3f)):
        s3, r3 = jload(S3f), jload(R3f)
        r2_r08 = float(e7_line(r08, r"^\s*LOCO R2 ([0-9.]+); CI", "NRtwoOneFeature") or "nan")
        for mac in ("NScreenMeanUncAuroc", "NScreenMeanUncAP"):
            cross(mac, s3.get("mutate") is None and r3.get("checks_failed") == [], "a control run, or the refit's own guard failed")
            cross(mac, abs(s3["auroc"] - s3["auroc_independent"]) <= 1e-12 and abs(s3["ap"] - s3["ap_independent"]) <= 1e-12,
                  "sklearn and the independent AUROC/AP differ")
            cross(mac, s3["n_pairs"] == pn("cov.pairs") and s3["n_severe"] == pn("screen.n_severe") and s3["n_clades"] == pn("cov.clades"),
                  "pairs, severe pairs or clades differ from PAPER_NUMBERS.json")
            cross(mac, r3["identity_rule_same_harness"] == {"auroc": s3["auroc"], "ap": s3["ap"]},
                  "the refit job's run of the same harness gives a different AUROC/AP")
            cross(mac, all(cites(r_, h_) for r_, h_ in s3["inputs_sha256"].items()), "icb3_screen.py read files that are not the manifest's")
        cross("NRtwoOneFeature", abs(r3["reproduce_pred_y_cov_gbr_r2"] - r2_r08) <= 1e-12 and
              round(r3["reproduce_pred_y_cov_gbr_r2"], 4) == pn("pred.y_cov.gbr.r2"),
              "the refit's harness does not reproduce pred.y_cov.gbr (email-7 r08 and PAPER_NUMBERS.json)")
        cross("NRtwoOneFeature", round(r3["reproduce_screen_labelfree"]["auroc"], 4) == pn("screen.labelfree_auroc") and
              round(r3["reproduce_screen_labelfree"]["ap"], 4) == pn("screen.labelfree_ap"), "the refit does not reproduce the screen")
        cross("NRtwoOneFeature", r3.get("checks_failed") == [] and all(len(v) == 1 for v in r3["guard_negative_controls"].values()),
              "the refit's guard failed or its negative controls did not all fire")
        cross("NRtwoOneFeature", all(cites("derived/icb3_screen.json" if r_ == "icb3_screen.json" else r_, h_)
                                     for r_, h_ in r3["inputs_sha256"].items()), "icb3_refit.py read files that are not the manifest's")
        lab = ("pooled over all pairs: the leave-one-clade-out out-of-fold scores of the identity rule (no fit; paper_numbers.py "
               "loco_clf, l.98-104, with l.103 replaced by the pair's own f_minscore_mean)")
        put("NScreenMeanUncAuroc", fixed(s3["auroc"], 3), S3f, f"auroc: roc_auc_score (l.107's call), {lab}", s3["auroc"], "3 dp (new)")
        put("NScreenMeanUncAP", fixed(s3["ap"], 3), S3f, f"ap: average_precision_score (l.108's call), {lab}", s3["ap"], "3 dp (new)")
        ridge = r3["context_r2_one_feature_ridge_alpha1"]
        q = AMEND_ICB.get("qicb3")
        ctx = ""
        if q:
            # ANSWERS_16Oct_ICB Q-ICB3: print the OLS value; Ridge(1.0) is context in this row only. The values the chat
            # quoted are guard values.
            if fixed(r3["r2_one_feature_ols"], 3) != q["ols"] or fixed(ridge, 3) != q["ridge"]:
                fail("ANSWER", q["macro"], f"OLS {fixed(r3['r2_one_feature_ols'], 3)} and Ridge(1.0) {fixed(ridge, 3)} differ from "
                                           f"{q['file']} Q-ICB3's {q['ols']} and {q['ridge']}")
            ctx = (f"; context only, not in the paper ({q['file']} Q-ICB3): Ridge(alpha=1.0) on the same feature and folds gives "
                   f"{fixed(ridge, 3)} (unrounded {ridge!r}; context_r2_one_feature_ridge_alpha1)")
        put("NRtwoOneFeature", fixed(r3["r2_one_feature_ols"], 3), R3f,
            "r2_one_feature_ols: pooled leave-one-clade-out r2_score (l.65) of LinearRegression() on f_minscore_mean for y_cov, "
            "paper_numbers.py loco (l.49-54) with only l.52's model changed; same folds; the harness first reproduced pred.y_cov.gbr",
            r3["r2_one_feature_ols"], "3 dp (new)" + ctx)

    # ---- ICB-2: the correction comparison over many calibration draws (icb2_corrections.py, Slurm; icb2_summary.py, no fit)
    CVf, RJf, SMf = "derived/icb2_coverage.csv", "derived/icb2_run.json", "derived/icb2_summary.json"
    if all(os.path.exists(os.path.join(ROOT, f_)) for f_ in (CVf, RJf, SMf)):
        rj, sm = jload(RJf), jload(SMf)
        cv = pd.read_csv(inp(CVf))
        VARS2 = ["vanilla", "class_conditional", "oracle_prior", "covshift_weighted"]
        cm2 = cv.groupby(["lineage", "draw", "variant"])["coverage"].mean().unstack("variant")
        margin = float(re.findall(r"by more than ([0-9.]+)", SPEC_ROWS["NCorrSummary"]["status"])[0])
        below = cm2["vanilla"] < THR
        a_n, a_k = int(below.sum()), int((cm2[VARS2[1:]][below] >= THR).any(axis=1).sum())
        b_n, b_k = int(len(cm2)), int((cm2[VARS2[1:]].sub(cm2["vanilla"], axis=0) > margin).any(axis=1).sum())
        nd = {L: sorted(cv.loc[cv.lineage == L, "draw"].unique().tolist()) for L in sorted(cv.lineage.unique())}
        N2 = len(next(iter(nd.values())))
        for mac in ("NCorrDraws", "NCorrSummary"):
            cross(mac, rj["table1_reproduction"].get("ok") is True and not rj["skipped"], "the job did not reproduce Table 1, or skipped a drug")
            cross(mac, all(v_ == list(range(N2)) for v_ in nd.values()) and rj["draws"] == [0, N2 - 1] and sm["n_draws"] == N2,
                  "the lineages' draws differ, or differ from the job's and the summary's")
            cross(mac, (a_n, a_k, b_n, b_k) == (sm["a"]["cells_vanilla_below"], sm["a"]["any_correction_reaches"], sm["b"]["cells"],
                                                sm["b"]["any_correction_beats"]),
                  f"the generator's (a) {a_k}/{a_n} and (b) {b_k}/{b_n} differ from icb2_summary.json")
            cross(mac, sm["threshold"] == THR and sm["margin"] == margin and sm.get("implementations_agree") is True and sm.get("mutate") is None,
                  "the summary's threshold or margin is not Table 1's / the spec's, or it is a control run")
            cross(mac, all(cites(r_, h_) for r_, h_ in list(sm["inputs_sha256"].items()) + list(rj["inputs_sha256"].items())),
                  "the ICB-2 scripts read files that are not the manifests'")
        put("NCorrDraws", integer(N2), CVf, f"calibration draws per lineage holdout (draws 0..N-1 for each of {len(nd)} lineages)", N2, "integer")
        TEMPLATE = ("Over {nd} calibration draws for each of the {nl} lineage holdouts ({nc} lineage-draw cells), vanilla split conformal "
                    "averaged below {thr} coverage in {an} cells, and at least one of the three corrections reached {thr} in {ak} of them "
                    "({ap}\\%). In {bk} of all {nc} cells ({bp}\\%), at least one correction exceeded vanilla's mean coverage by more than {mg}.")
        sentence = TEMPLATE.format(nd=integer(N2), nl=integer(len(nd)), nc=integer(b_n), thr=fixed(THR, 2), an=integer(a_n), ak=integer(a_k),
                                   ap=pct(a_k / a_n, 1), bk=integer(b_k), bp=pct(b_k / b_n, 1), mg=fixed(margin, 2))
        put("NCorrSummary", sentence, CVf, f"(a) {a_k} of {a_n} cells with vanilla mean below {THR}; (b) {b_k} of {b_n} cells beat by more than "
            f"{margin}; generated from TEMPLATE in gen_numbers_icbinb.py", None, "generated sentence (counts exact; percents 1 dp)")

    # ---- ICB-5: tree-kernel-weighted conformal prediction (icb5_treekernel.py, Slurm)
    TKf = "derived/icb5_treekernel.json"
    if os.path.exists(os.path.join(ROOT, TKf)):
        tk = jload(TKf); key = "A|narrow|split_median"; A = tk["means_over_drugs"][key]
        TV, E3V = tk["means_over_drugs"]["textbook_vanilla"], tk["means_over_drugs"]["e3_vanilla"]
        ns = A["empty"] + A["full"]
        abst = 1 - A["singleton"]        # the share of sets that are not singletons: the spec's definition of NTreeKernelAbstPct
        rec_cov = float(np.mean([tk["per_drug"][d_][key]["coverage"] for d_ in tk["drugs"]]))
        rec_ns = float(np.mean([tk["per_drug"][d_][key]["empty"] for d_ in tk["drugs"]])) + \
                 float(np.mean([tk["per_drug"][d_][key]["full"] for d_ in tk["drugs"]]))
        new5 = [n for n in ("NVanillaCovAsImpl", "NVanillaCovTextbook", "NTreeKernelEmptyPct", "NTreeKernelFullPct",
                            "NVanillaEmptyPct", "NVanillaFullPct") if n in SPEC_ROWS]       # added by ANSWERS_16Oct_ICB / _b
        stale = [f"{run}.{f}" for run in (key, "textbook_vanilla") for f in ("coverage", "singleton", "empty", "full")
                 if abs(float(np.mean([tk["per_drug"][d_][run][f] for d_ in tk["drugs"]])) - tk["means_over_drugs"][run][f]) > 1e-12]
        for mac in new5:
            cross(mac, not stale, f"stored means are not the means of the per-drug values: {stale}")
        for mac in ["NTreeKernelCov", "NTreeKernelAbstPct"] + new5:
            cross(mac, tk["checks_failed"] == [] and all(len(v_) == 1 for v_ in tk["guard_negative_controls"].values()),
                  "the job's guard failed or its negative controls did not all fire")
            cross(mac, tk["reproduction_max_abs_diff"] is not None and tk["reproduction_max_abs_diff"] <= 1e-12 and tk["uniform_limit_ok"]
                  and tk["shares_ok"], "the refit did not reproduce Table 1, or the uniform-weight limit or the shares check failed")
            cross(mac, tk["drugs"] == list(E3["lineage2_blocked"]) and not tk["skipped"], "the drugs are not Table 1's nine")
            cross(mac, abs(tk["means_over_drugs"]["e3_vanilla"]["coverage"] - V["NTVanillaLin"]["unrounded"]) <= 1e-12,
                  "the job's e3 vanilla mean is not Table 1's lineage-2 vanilla")
            cross(mac, tk["bandwidth_multiples"] == {"narrow": nar["bandwidth_x_median"], "wide": wide["bandwidth_x_median"]},
                  "the bandwidth multiples are not Figure 2's narrow and wide")
            cross(mac, abs(rec_cov - A["coverage"]) <= 1e-12 and abs(rec_ns - ns) <= 1e-12, "the stored means are not the means of the per-drug values")
            cross(mac, all(cites(r_, h_) for r_, h_ in tk["inputs_sha256"].items()), "icb5_treekernel.py read files that are not the manifests'")
        how = (f"version A (the test point's own weight exp(0) = 1 in the normalisation, Tibshirani Eq. 7), narrow bandwidth "
               f"{tk['bandwidth_multiples']['narrow']} x the median patristic test-to-calibration distance of Table 1's lineage-2 split; "
               f"mean over the nine drugs")
        put("NTreeKernelCov", fixed(A["coverage"], 3), TKf, f"means_over_drugs[{key}].coverage: {how}", A["coverage"], "3 dp (new)")
        put("NTreeKernelAbstPct", pct(abst, 1), TKf, f"100 x (1 - singleton share): the share of prediction sets that are not "
            f"singletons, means_over_drugs[{key}]: {how}", abst, "percent, 1 dp (= 3 decimals as a fraction)")
        if new5:
            # ANSWERS_16Oct_ICB Q-ICB5 (vanilla as implemented and with the textbook rank) and ANSWERS_16Oct_ICB_b (the
            # shares of empty and full {S, R} sets), with the _b file's two guards
            ADD = AMEND_ICB["added"]
            tvhow = ("textbook vanilla = version A with uniform weights: split conformal with the textbook rank k = "
                     "ceil((n+1)(1-alpha)) on Table 1's lineage-2 split and drugs; mean over the nine drugs")
            e3how = ("vanilla as implemented in e3_shift_diagnosis.py (np.quantile at level ceil((n+1)(1-alpha))/n, method "
                     "'higher': the (k+1)-th smallest calibration score), Table 1's lineage-2 split; mean over the nine drugs")
            dC, dF = A["coverage"] - TV["coverage"], A["full"] - TV["full"]
            gain = (f"dC = {dC!r} (mean coverage, version A narrow minus textbook vanilla), dF = {dF!r} (share of {{S, R}} sets, "
                    f"same runs), dC - dF = {dC - dF!r} (the change in the share of correctly covered singletons)")
            src5 = {"NVanillaCovAsImpl": (E3V["coverage"], f"means_over_drugs[e3_vanilla].coverage: {e3how}", False),
                    "NVanillaCovTextbook": (TV["coverage"], f"means_over_drugs[textbook_vanilla].coverage: {tvhow}", False),
                    "NTreeKernelEmptyPct": (A["empty"], f"100 x means_over_drugs[{key}].empty (share of empty sets): {how}", True),
                    "NTreeKernelFullPct": (A["full"], f"100 x means_over_drugs[{key}].full (share of sets equal to {{S, R}}): {how}; "
                                                      f"guard GAIN: {gain}", True),
                    "NVanillaEmptyPct": (TV["empty"], f"100 x means_over_drugs[textbook_vanilla].empty (share of empty sets): {tvhow}", True),
                    "NVanillaFullPct": (TV["full"], f"100 x means_over_drugs[textbook_vanilla].full (share of sets equal to {{S, R}}): "
                                                    f"{tvhow}; guard GAIN: {gain}", True)}
            for n in new5:
                x, k_, is_pct = src5[n]
                p_ = ADD[n]["places"]
                put(n, pct(x, p_) if is_pct else fixed(x, p_), TKf, k_, x, f"{'percent, ' if is_pct else ''}{p_} dp ({ADD[n]['file']})")
            four = [n for n in ("NTreeKernelEmptyPct", "NTreeKernelFullPct", "NVanillaEmptyPct", "NVanillaFullPct") if n in new5]
            if four:
                # guard GAIN (_b guard 1): "almost all of the coverage gain is that rise", on unrounded values
                fac = D(AMEND_ICB["gain_factor"])
                if not (D(dC) > 0 and D(dF) >= fac * D(dC)):
                    for n in four:
                        fail("GAIN", n, f"not (dC > 0 and dF >= {fac} x dC): {gain}")
                # guard SHARES (_b guard 2): empty + full = the share behind NTreeKernelAbstPct (1 - singleton)
                tol = D(AMEND_ICB["shares_tol"])
                if not abs(D(ns) - D(abst)) < tol:
                    for n in ("NTreeKernelEmptyPct", "NTreeKernelFullPct", "NTreeKernelAbstPct"):
                        fail("SHARES", n, f"empty + full = {ns!r} differs from 1 - singleton = {abst!r} (the share behind "
                                          f"NTreeKernelAbstPct) by {abs(ns - abst)!r}, limit {tol}")
                note(f"guard GAIN: {gain}; dF/dC = {(dF / dC if dC else float('nan'))!r} (dF >= {fac} x dC required); guard SHARES: |empty + full - "
                     f"(1 - singleton)| = {abs(ns - abst)!r} (below {tol} required)")

    # ---- ICB-4b: lineage-grouped validation (icb4b_lingroup.py, Slurm)
    LGf = "derived/icb4b_lingroup.json"
    if os.path.exists(os.path.join(ROOT, LGf)):
        lg = jload(LGf); rc_ = lg["reproduce_clade_grouped"]; lgv = lg["lineage_grouped"]
        r2_r08b = float(e7_line(r08, r"^\s*LOCO R2 ([0-9.]+); CI", "NRtwoLinGroup") or "nan")
        for mac in ("NScreenLinGroupAuroc", "NScreenLinGroupAP", "NRtwoLinGroup"):
            cross(mac, lg.get("checks_failed") == [] and all(len(v) == 1 for v in lg["guard_negative_controls"].values()),
                  "the job's guard failed or its negative controls did not all fire")
            cross(mac, abs(rc_["r2_y_cov_gbr"] - r2_r08b) <= 1e-12 and round(rc_["r2_y_cov_gbr"], 4) == pn("pred.y_cov.gbr.r2")
                  and round(rc_["screen_auroc"], 4) == pn("screen.labelfree_auroc") and round(rc_["screen_ap"], 4) == pn("screen.labelfree_ap"),
                  "the unchanged harness did not reproduce the paper's clade-grouped values")
            cross(mac, lg["n_pairs"] == pn("cov.pairs") and lg["n_severe"] == pn("screen.n_severe")
                  and sum(f["pairs"] for f in lg["folds"]) == lg["n_pairs"] and sum(f["severe"] for f in lg["folds"]) == lg["n_severe"],
                  "the lineage folds do not partition the pairs and severe pairs of PAPER_NUMBERS.json")
            cross(mac, all(cites(r_, h_) for r_, h_ in lg["inputs_sha256"].items()), "icb4b_lingroup.py read files that are not the manifest's")
        grp = f"{len(lg['folds'])} folds, each a lineage with all of its sublineage clades; single-class training folds {lg['single_class_training_folds']}"
        put("NScreenLinGroupAuroc", fixed(lgv["screen_auroc"], 3), LGf, f"lineage_grouped.screen_auroc: pooled roc_auc_score (l.107's call) of "
            f"paper_numbers.py loco_clf (unchanged) with only the groups changed ({grp})", lgv["screen_auroc"], "3 dp (new)")
        put("NScreenLinGroupAP", fixed(lgv["screen_ap"], 3), LGf, f"lineage_grouped.screen_ap: pooled average_precision_score (l.108's call), "
            f"same run ({grp})", lgv["screen_ap"], "3 dp (new)")
        put("NRtwoLinGroup", fixed(lgv["r2_y_cov_gbr"], 3), LGf, f"lineage_grouped.r2_y_cov_gbr: pooled r2_score (l.65) of paper_numbers.py "
            f"loco(F, y_cov, gbr) (unchanged) with only the groups changed ({grp})", lgv["r2_y_cov_gbr"], "3 dp (new)")

    # ---- ICB-4a: nested clades in the leave-one-clade-out folds (icb4a_nested.py, no fit)
    NEf = "derived/icb4a_nested.json"
    if os.path.exists(os.path.join(ROOT, NEf)):
        ne = jload(NEf)
        cross("NNestedPairs", ne["nested_by_fold"] == ne["nested_by_hierarchy"], "fold-based and hierarchy-based nesting differ")
        cross("NNestedPairs", len(ne["nested_by_fold"]) == ne["n_nested_heldout_clades"], "the count does not match its list")
        cross("NNestedPairs", ne["n_clades"] == pn("cov.clades") and ne["n_pairs"] == pn("cov.pairs"),
              "clade or pair count differs from PAPER_NUMBERS.json")
        cross("NNestedPairs", all(cites(r_, h_) for r_, h_ in ne["inputs_sha256"].items()),
              "icb4a_nested.py read files that are not the manifest's")
        cross("NNestedPairs", ne.get("mutate") is None, "the result comes from a mutated (control) run")
        put("NNestedPairs", integer(ne["n_nested_heldout_clades"]), NEf,
            f"held-out clades (of {ne['n_clades']}) whose parent lineage or child sublineage clade, sharing isolates, stayed in "
            "the LOCO training folds (fold-based count = hierarchy-based count)", ne["n_nested_heldout_clades"], "integer")


# ----------------------------------------------------------------------------------------------------------------
def parse_spec(rel):
    """The spec's macro rows in order. A row's source column is kept only where it names a queue item ("ICB-n"), the
    one use the generator makes of it (later-task macros); elsewhere it is a cluster path and is not recorded."""
    def read():
        rows, order, twice = {}, [], []
        for ln in text(rel).splitlines():
            m = re.match(r"^\| \\(N[A-Za-z]+) \| (.*?) \| (.*?) \|\s*$", ln)
            if m:
                name, status, source = m.groups()
                if name in rows:
                    twice.append(name)
                src = source.strip()
                rows[name] = dict(status=status.strip(), source=src if re.match(r"^ICB-\d", src) else "-")
                order.append(name)
        return {"order": order, "rows": rows, "twice": twice}
    r = replay("spec", rel, rel, read) or {"order": [], "rows": {}, "twice": []}
    for name in r["twice"]:
        fail("MACRO-SET", name, "listed twice in the spec")
    return list(r["order"]), {k: dict(v) for k, v in r["rows"].items()}


SPEC_ROWS = {}
AMEND = {"file": "-", "retired": [], "withdrawn": [], "added": {}, "q1_phrase": ""}
AMEND_FILE = "notes/ANSWERS_16Oct_ICB0.md"


def parse_answers(rel):
    """The chat's amendments to the spec, read from its answers file (never transcribed): retired macros, spec values
    withdrawn in favour of the computed value, and added macros with their precision."""
    def read():
        if not os.path.exists(os.path.join(ROOT, rel)):
            return None
        t = text(rel)
        out = {"file": os.path.basename(rel), "retired": re.findall(r"retire \\(N[A-Za-z]+)", t), "withdrawn": [], "added": {},
               "q1_phrase": ""}
        q1 = re.findall(r"^## Q1\. \\(N[A-Za-z]+) and \\(N[A-Za-z]+)\s*$", t, re.M)
        if len(q1) == 1 and "are withdrawn" in t and "Use the computed values" in t:
            out["withdrawn"] = list(q1[0])
        ph = re.findall(r'Record "([^"]+)" in their provenance_icbinb\.tsv rows', t)
        out["q1_phrase"] = ph[0] if len(ph) == 1 else ""
        for name, definition, places in re.findall(r"^\| \\(N[A-Za-z]+) \| (.*?) \| (\d+) dp \|\s*$", t, re.M):
            out["added"][name] = dict(definition=definition.strip(), places=int(places))
        return out
    r = replay("answers", rel, rel, read)
    if r is None:
        fail("AMEND", "-", f"{rel} is missing from the input root"); return
    AMEND.update({k: (dict(v) if isinstance(v, dict) else v) for k, v in r.items()})
    for what, ok in (("a retired macro", AMEND["retired"]), ("the two Q1 macros", AMEND["withdrawn"]),
                     ("the Q1 provenance phrase", AMEND["q1_phrase"]), ("the added macros", AMEND["added"])):
        if not ok:
            fail("AMEND", "-", f"{rel}: could not read {what}")


RECORD, CHANGES = "release/RELEASE_RECORD.json", "release/RELEASE_CHANGES.tsv"


def release_setup():
    """Release build: load the record (replayed reads, the internal build's file hashes, the generator's commit) and
    run the RELEASE guard. Returns the recorded commit and the internal build's INPUT-DRIFT note."""
    p = inp(RECORD)
    rec = json.load(open(p)) if p else {}
    REPLAY.update(rec.get("replay", {}))
    INTERNAL_SHA.update(rec.get("internal_sha256", {}))
    mine = sha256(os.path.abspath(__file__))
    if rec.get("generator_sha256") != mine:
        fail("COMMIT", "-", f"this generator (sha256 {mine[:12]}) is not the one that wrote the release record "
                            f"({str(rec.get('generator_sha256'))[:12]})")
    changes = {}
    pc = inp(CHANGES)
    if pc:
        rows = [ln.split("\t") for ln in open(pc).read().splitlines() if ln.strip()]
        for r in rows[1:]:
            d = dict(zip(rows[0], r))
            changes[d["file"]] = d
    counts = {}
    for rel, h in sorted(INTERNAL_SHA.items()):
        path = os.path.join(ROOT, rel)
        actual = sha256(path) if os.path.isfile(path) else None
        ch = changes.get(rel)
        kind = ch["change"] if ch else ("missing" if actual is None else "identical")
        counts[kind] = counts.get(kind, 0) + 1
        if ch is not None:
            if ch["internal_sha256"] != h:
                fail("RELEASE", "-", f"{CHANGES} gives {rel} the internal sha256 {ch['internal_sha256'][:12]}, the record {h[:12]}")
            if ch["change"] in ("sanitized", "excerpt"):
                if actual is None or actual != ch["released_sha256"] or SHA.get(rel) != actual:
                    fail("RELEASE", "-", f"{rel}: the released file is not the {ch['change']} that {CHANGES} lists")
            elif ch["change"] == "omitted":
                if actual is not None or rel in SHA:
                    fail("RELEASE", "-", f"{rel} is listed as omitted but is in the release")
            else:
                fail("RELEASE", "-", f"{rel}: unknown change {ch['change']!r} in {CHANGES}")
        elif withheld(rel):
            fail("RELEASE", "-", f"{rel} is withheld but not listed in {CHANGES}")
        elif actual != h or SHA.get(rel) != h:
            fail("RELEASE", "-", f"{rel} is not the file the internal build read (sha256 {str(actual)[:12]}, internal {h[:12]}) "
                                  f"and {CHANGES} does not list it")
    for rel in sorted(set(changes) - set(INTERNAL_SHA)):       # files this generator never reads (other scripts' inputs)
        ch, path = changes[rel], os.path.join(ROOT, rel)
        actual = sha256(path) if os.path.isfile(path) else None
        if ch["change"] == "omitted" and actual is not None:
            fail("RELEASE", "-", f"{rel} is listed as omitted but is in the release")
        elif ch["change"] in ("sanitized", "excerpt") and actual != ch["released_sha256"]:
            fail("RELEASE", "-", f"{rel}: the released file is not the {ch['change']} that {CHANGES} lists")
    note(f"release build: {len(INTERNAL_SHA)} files of the internal build: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items()))
         + "; replayed reads of withheld files: " + ", ".join(f"{k} {len(v)}" for k, v in REPLAY.items()))
    return rec.get("generator_commit", "unrecorded"), rec.get("notes", {}).get("input_drift", "-")


AMEND_ICB = {"files": [], "q3": None, "qicb3": None, "added": {}, "gain_factor": None, "shares_tol": None}
ANSWERS_ICB, ANSWERS_ICB_B = "notes/ANSWERS_16Oct_ICB.md", "notes/ANSWERS_16Oct_ICB_b.md"


def parse_answers_icb(rel):
    """ANSWERS_16Oct_ICB.md: Q3 (a withdrawn spec value and the value to print), Q-ICB3 (the OLS value to print and the
    Ridge value for the provenance row) and Q-ICB5 (two added macros with their precision and the logged values)."""
    def read():
        if not os.path.exists(os.path.join(ROOT, rel)):
            return None
        t, f = text(rel), os.path.basename(rel)
        tn = " ".join(t.split())                     # sentences wrap across lines
        out = {"file": f, "q3": None, "qicb3": None, "added": {}}
        m = re.findall(r"\*\*Q3\. \\(N[A-Za-z]+) = ([0-9.]+)\.\*\*", tn)
        w = re.findall(r"The spec's ([0-9.]+) is withdrawn", tn)
        if len(m) == 1 and len(w) == 1 and "Release the hold" in tn:
            out["q3"] = {"file": f, "macro": m[0][0], "value": m[0][1], "withdrawn": w[0]}
        k = re.findall(r"Keep \\(N[A-Za-z]+) as the OLS leave-one-clade-out R\^2 \(([0-9.]+)\)", tn)
        r = re.findall(r"Put the Ridge\(1\.0\) value \(([0-9.]+)\) in its provenance row as context", tn)
        if len(k) == 1 and len(r) == 1:
            out["qicb3"] = {"file": f, "macro": k[0][0], "ols": k[0][1], "ridge": r[0]}
        pl = re.findall(r"Add two macros from ICB-5's job, both at (\d+) dp", tn)
        items = re.findall(r"^- \\(N[A-Za-z]+): (.*?) \(your log:\s*([0-9.]+)\)", t, re.M | re.S)
        if len(pl) == 1:
            for name, definition, logged in items:
                out["added"][name] = {"file": f + " Q-ICB5", "definition": " ".join(definition.split()), "places": int(pl[0]),
                                      "check": logged, "check_kind": "unrounded"}
        return out
    return replay("answers", rel, rel, read)


def parse_answers_icb_b(rel):
    """ANSWERS_16Oct_ICB_b.md: four added macros (the table: definition, precision and the 4-dp value the chat read
    from ICB-5's table) and the constants of its two guards."""
    def read():
        if not os.path.exists(os.path.join(ROOT, rel)):
            return None
        t, f = text(rel), os.path.basename(rel)
        out = {"file": f, "added": {}}
        for name, definition, places in re.findall(r"^\| \\(N[A-Za-z]+) \| (.*?) \| (\d+) dp \|\s*$", t, re.M):
            chk = re.findall(r"\(your (?:ICB-5 )?table: ([0-9.]+)\)", definition)
            out["added"][name] = {"file": f, "definition": definition.strip(), "places": int(places),
                                  "check": chk[0] if len(chk) == 1 else None, "check_kind": "4dp"}
        tn = " ".join(t.split())
        g = re.findall(r"dF >= ([0-9.]+) x dC", tn)
        tol = re.findall(r"difference below (1e-\d+)", tn)
        out["gain_factor"] = g[0] if len(set(g)) == 1 else None
        out["shares_tol"] = tol[0] if len(set(tol)) == 1 else None
        return out
    return replay("answers", rel, rel, read)


def apply_answers_icb(order):
    """Q3: the spec value is withdrawn (the guard is the answer's value); the six added macros go after the ICB-5 macros."""
    a, b = parse_answers_icb(ANSWERS_ICB), parse_answers_icb_b(ANSWERS_ICB_B)
    for rel, r in ((ANSWERS_ICB, a), (ANSWERS_ICB_B, b)):
        if r is None:
            fail("AMEND", "-", f"{rel} is missing from the input root")
    if a is None or b is None:
        return order
    AMEND_ICB["files"] = [a["file"], b["file"]]
    AMEND_ICB["q3"], AMEND_ICB["qicb3"] = a["q3"], a["qicb3"]
    AMEND_ICB["added"] = {**a["added"], **b["added"]}
    AMEND_ICB["gain_factor"], AMEND_ICB["shares_tol"] = b["gain_factor"], b["shares_tol"]
    for what, ok in (("Q3", a["q3"]), ("Q-ICB3", a["qicb3"]), ("the two Q-ICB5 macros", len(a["added"]) == 2),
                     ("the four added macros", len(b["added"]) == 4 and all(d["check"] for d in b["added"].values())),
                     ("the GAIN factor", b["gain_factor"]), ("the SHARES limit", b["shares_tol"])):
        if not ok:
            fail("AMEND", "-", f"could not read {what} from the answers")
    q3 = a["q3"]
    if q3:
        n = q3["macro"]
        if n not in SPEC_ROWS or SPEC_ROWS[n]["status"] != q3["withdrawn"]:
            fail("AMEND", n, f"Q3 withdraws the spec value {q3['withdrawn']}, but the spec gives {SPEC_ROWS.get(n, {}).get('status')}")
        else:
            SPEC_ROWS[n]["withdrawn"] = SPEC_ROWS[n]["status"]
            SPEC_ROWS[n]["status"] = f"PENDING ({q3['file']} Q3)"
    new = list(AMEND_ICB["added"])
    for n in new:
        if n in SPEC_ROWS:
            fail("AMEND", n, "added by the answers but already in the spec")
    pos = order.index("NTreeKernelAbstPct") + 1 if "NTreeKernelAbstPct" in order else len(order)
    for n, d in AMEND_ICB["added"].items():
        SPEC_ROWS[n] = dict(status=f"PENDING ({d['file']}): {d['definition']}", source=d["file"])
    note(f"amendments ({', '.join(AMEND_ICB['files'])}): Q3 {q3['macro'] if q3 else '-'} spec value {q3['withdrawn'] if q3 else '-'} "
         f"withdrawn, the answer gives {q3['value'] if q3 else '-'}; added {new}; GAIN factor {AMEND_ICB['gain_factor']}, "
         f"SHARES limit {AMEND_ICB['shares_tol']}")
    return order[:pos] + new + order[pos:]


def check_answers_icb():
    """The values the chat stated in its answers are guard values for what the generator computed."""
    q3 = AMEND_ICB["q3"]
    if q3:
        r = V.get(q3["macro"])
        if r is None or r["status"] != "OK" or r["value"] != q3["value"]:
            fail("ANSWER", q3["macro"], f"emitted {r['value'] if r else None} but {q3['file']} Q3 gives {q3['value']}")
        else:
            r["rule"] = (f"Q3 ({q3['file']}): the spec's {q3['withdrawn']} withdrawn; the answer's {q3['value']} = the computed "
                         f"value; {r['rule']}")
    for n, d in AMEND_ICB["added"].items():
        r = V.get(n)
        if r is None or r["unrounded"] is None:
            fail("ANSWER", n, "not computed"); continue
        if d["check_kind"] == "unrounded":
            ok, got = abs(float(r["unrounded"]) - float(d["check"])) <= 1e-12, repr(r["unrounded"])
        else:
            ok, got = fixed(r["unrounded"], decimals(d["check"])) == d["check"], fixed(r["unrounded"], decimals(d["check"]))
        if not ok:
            fail("ANSWER", n, f"the source value {got} differs from the {d['check']} that {d['file']} quotes")


def main():
    global ROOT, SPEC_ROWS, MODE
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.environ.get("ICBINB_INPUT_ROOT"))
    ap.add_argument("--out-tex", required=True); ap.add_argument("--out-prov", required=True)
    ap.add_argument("--hold", default=""); ap.add_argument("--log")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--write-release-record", metavar="FILE", help="internal build: also record the reads of withheld files")
    g.add_argument("--release", action="store_true", help="release build: replay them from release/RELEASE_RECORD.json")
    a = ap.parse_args()
    if not a.root:
        ap.error("give --root or set ICBINB_INPUT_ROOT")
    ROOT = os.path.abspath(a.root)
    hold = [h for h in a.hold.split(",") if h]
    load_manifests()

    # commit of this generator (the provenance 'commit' column)
    here = os.path.dirname(os.path.abspath(__file__))
    drift_internal = "-"
    if a.release:
        MODE = "release"
        commit, drift_internal = release_setup()
    else:
        try:
            # the last commit that changed THIS file (commits touching other files do not change the output)
            commit = subprocess.run(["git", "-C", here, "log", "-1", "--format=%H", "--", os.path.basename(__file__)],
                                    capture_output=True, text=True, check=True).stdout.strip() or "uncommitted"
            dirty = subprocess.run(["git", "-C", here, "status", "--porcelain", "--", os.path.basename(__file__)],
                                   capture_output=True, text=True, check=True).stdout.strip()
            if dirty:
                fail("COMMIT", "-", "gen_numbers_icbinb.py differs from the committed version: commit it before generating")
        except (subprocess.CalledProcessError, FileNotFoundError):
            commit = "not-a-git-checkout"
            note("WARNING: not run from a git checkout; the commit column says so")

    order, SPEC_ROWS = parse_spec("notes/ICBINB_NUMBERS_SPEC_v2.md")
    parse_answers(AMEND_FILE)
    for n in AMEND["retired"]:
        if n not in SPEC_ROWS:
            fail("AMEND", n, "retired by the answers but not in the spec")
    slot = order.index(AMEND["retired"][0]) if AMEND["retired"] and AMEND["retired"][0] in order else len(order)
    for n in AMEND["added"]:
        if n in SPEC_ROWS:
            fail("AMEND", n, "added by the answers but already in the spec")
    order = [n for n in order[:slot] if n not in AMEND["retired"]] + list(AMEND["added"]) + \
            [n for n in order[slot:] if n not in AMEND["retired"]]
    for n in AMEND["retired"]:
        SPEC_ROWS.pop(n, None)
    for n, d in AMEND["added"].items():
        SPEC_ROWS[n] = dict(status=f"PENDING ({AMEND['file']} Q2): {d['definition']}", source=f"{AMEND['file']} Q2")
    for n in AMEND["withdrawn"]:
        if n not in SPEC_ROWS or SPEC_ROWS[n]["status"].startswith("PENDING"):
            fail("AMEND", n, "a withdrawn spec value, but the spec gives no value for it")
        else:
            SPEC_ROWS[n]["withdrawn"] = SPEC_ROWS[n]["status"]
            SPEC_ROWS[n]["status"] = f"PENDING ({AMEND['file']} Q1)"
    note(f"amendments ({AMEND['file']}): retired {AMEND['retired']}; added {list(AMEND['added'])}; spec values withdrawn "
         f"{[(n, SPEC_ROWS[n].get('withdrawn')) for n in AMEND['withdrawn'] if n in SPEC_ROWS]}")
    order = apply_answers_icb(order)
    compute()
    check_answers_icb()

    # later tasks
    for name in order:
        src = SPEC_ROWS[name]["source"]
        if re.match(r"^ICB-\d", src) and name not in V:
            needs(name, "-", src, f"produced by {src} (later queue item)", "LATER-TASK")
    # MACRO-SET
    missing = [n for n in order if n not in V]
    extra = [n for n in V if n not in SPEC_ROWS and ":" not in n]
    for n in missing:
        fail("MACRO-SET", n, "in the spec but not computed")
    for n in extra:
        fail("MACRO-SET", n, "computed but not in the spec")
    # Q1 (answers): for the withdrawn macros the guard is the unrounded recorded source, at the spec's precision
    for n in AMEND["withdrawn"]:
        r = V.get(n)
        if r is None or r["status"] != "OK" or r["unrounded"] is None:
            fail("Q1", n, "no value from an unrounded recorded source"); continue
        want = fixed(r["unrounded"], decimals(SPEC_ROWS[n]["withdrawn"]))
        if r["value"] != want:
            fail("Q1", n, f"emitted {r['value']} is not the single rounding {want} of the unrounded source {r['unrounded']!r}")
        r["rule"] = f"{AMEND['q1_phrase']} (spec {SPEC_ROWS[n]['withdrawn']} withdrawn); guard: single rounding of the unrounded source; {r['rule']}"
    # SPEC values
    for n in order:
        st = SPEC_ROWS[n]["status"]
        if st.startswith("PENDING") or n not in V:
            continue
        got = V[n]["value"]
        if V[n]["status"] != "OK":
            continue        # undecided / pending-refit: reported, never emitted
        if got != st:
            fail("SPEC", n, f"computed {got} (unrounded {V[n]['unrounded']!r}) but the spec gives {st}")
    # INPUT-DRIFT since email 7 (internal build only: the email-7 manifests are withheld from a release)
    if MODE == "release":
        note(f"INPUT-DRIFT: not run in a release build (the email-7 manifests are withheld); the internal build: {drift_internal}")
    else:
        e7man = {}
        for man in ("nums_67/27baf2c/e7/INPUTS_e7.sha256", "nums_67/1a3949d/verify_e7/INPUTS_verify_e7.sha256"):
            for ln in text(man).splitlines():
                if ln.strip():
                    h, pth = ln.split(None, 1)
                    e7man.setdefault(pth.strip(), set()).add(h)
        checked = 0
        for rel, h in sorted(USED.items()):
            for pre, tail in (("amrconf/", "/amrconf/"), ("submitted/", "/01_icbinb/")):
                if rel.startswith(pre):
                    hits = {hh for pth, hs in e7man.items() if pth.endswith(tail + rel[len(pre):]) for hh in hs}
                    if hits:
                        checked += 1
                        if hits != {h}:
                            fail("INPUT-DRIFT", "-", f"{rel} changed since email 7 (now {h[:12]}, then {sorted(x[:12] for x in hits)})")
        note(f"INPUT-DRIFT: {checked} input files were also read by email 7; all byte-identical" if not any(f[0] == "INPUT-DRIFT" for f in FAIL)
             else "INPUT-DRIFT: see failures")

    # holds
    failing = {m for g, m, d in FAIL}
    for h in hold:
        if h not in SPEC_ROWS:
            fail("STALE-HOLD", h, "not a spec macro")
        elif h not in failing:
            fail("STALE-HOLD", h, "held but passes every guard: remove the hold")
    blocking = [f for f in FAIL if f[1] not in hold or f[0] in ("STALE-HOLD", "INPUT-MANIFEST", "INPUT-DRIFT", "COMMIT", "MACRO-SET",
                                                                 "AMEND", "Q1", "RELEASE", "ANSWER", "SHARES")]
    held = [f for f in FAIL if f not in blocking]

    digest = hashlib.sha256(open(os.path.join(ROOT, "INPUTS.sha256"), "rb").read()).hexdigest()
    lines = [f"gen_numbers_icbinb: {len(order)} spec macros (after amendments); inputs {len(USED)} files; commit {commit[:12]}; "
             f"{MODE} build; input manifest INPUTS.sha256 sha256 {digest[:12]}"]
    lines += [f"  note: {s}" for s in NOTES]
    for g, m, d in held:
        lines.append(f"  HELD {g}: {m}: {d}")
    if blocking:
        lines += [f"ABORT gen_numbers_icbinb: {g}: {m}: {d}" for g, m, d in blocking]
        lines.append(f"ABORT gen_numbers_icbinb: {len(blocking)} guard failure(s); nothing written")
        print("\n".join(lines))
        if a.log:
            open(a.log, "w").write("\n".join(lines) + "\n")
        sys.exit(2)

    # write (the header names no commit and no input hash: the provenance table carries the commit per row, and a
    # release build from the public bundle must write the same bytes)
    tex = ["% numbers_icbinb.tex -- generated by gen_numbers_icbinb.py; do not edit by hand.",
           f"% one \\newcommand per macro of ICBINB_NUMBERS_SPEC_v2.md as amended by {and_list([AMEND['file']] + AMEND_ICB['files'])}, in spec order;",
           "% \\NEEDNUM{name} = not yet decided",
           "% (later task, refit job pending, open question or held disagreement: see the provenance table)."]
    prov = ["macro\tvalue\tfile\tkey or expression\tcommit\tstatus\tunrounded\trule"]
    counts = {}
    for n in order:
        r = V[n]
        st = "HELD" if n in hold else r["status"]
        counts[st] = counts.get(st, 0) + 1
        val = r["value"] if st == "OK" else f"\\NEEDNUM{{{n}}}"
        tex.append(f"\\newcommand{{\\{n}}}{{{val}}}")
        why = r["rule"] if st != "HELD" else "; ".join(d for g, m, d in held if m == n)
        unr = "" if r["unrounded"] is None else (repr(r["unrounded"]) if not isinstance(r["unrounded"], list) else str(r["unrounded"]))
        prov.append("\t".join([f"\\{n}", val, r["file"], r["key"], commit, st, unr, why]))
    for path, body in ((a.out_tex, tex), (a.out_prov, prov)):
        tmp = path + ".tmp"
        open(tmp, "w").write("\n".join(body) + "\n")
        os.replace(tmp, path)
    lines.append("wrote " + os.path.basename(a.out_tex) + " and " + os.path.basename(a.out_prov) + ": "
                 + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
    if a.write_release_record:
        # everything a release build needs that is not public: the withheld reads, and the hashes of every file this
        # build read or a derived file cites (so a release build can tell identical, sanitized and omitted files apart)
        rec = {"record": "gen_numbers_icbinb.py release record: values read from withheld files (nums_67/: the email-7 "
                         "verification logs; notes/: the numbers spec, the chat's answers, the email-7 record) by the internal "
                         "build, replayed by gen_numbers_icbinb.py --release",
               "generator": os.path.basename(__file__), "generator_commit": commit,
               "generator_sha256": sha256(os.path.abspath(__file__)), "hold": hold,
               "outputs_sha256": {os.path.basename(a.out_tex): sha256(a.out_tex), os.path.basename(a.out_prov): sha256(a.out_prov)},
               "notes": {"input_drift": " | ".join(n for n in NOTES if n.startswith("INPUT-DRIFT"))},
               "internal_sha256": {r_: SHA[r_] for r_ in sorted(set(USED) | CITED) if r_ in SHA},
               "replay": REPLAY}
        tmp = a.write_release_record + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(rec, fh, indent=1)
            fh.write("\n")
        os.replace(tmp, a.write_release_record)
        lines.append(f"wrote {os.path.basename(a.write_release_record)}: {len(rec['internal_sha256'])} file hashes; replayed reads "
                     + ", ".join(f"{k} {len(v)}" for k, v in REPLAY.items()))
    print("\n".join(lines))
    if a.log:
        open(a.log, "w").write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
