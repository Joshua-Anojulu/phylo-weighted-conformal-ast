#!/usr/bin/env python3
"""wd_replay_l2.py -- replay weight_degeneracy.py for the lineage-2 holdout, patristic distance (the first analyse()
call of that script) and measure how far the normalised weight vectors of different test isolates differ at the
wide bandwidth. Purpose: \\NIdentDecimals ("decimal places to which weight vectors agree at the wide bandwidth"),
which weight_degeneracy.json does not store (it stores cosines and total-variation distances only).

No model is fitted. The script reproduces the original random stream (default_rng(0); the two permutations of
l.56 and l.62; then analyse() of l.27-53, run VERBATIM: its text is read from the source file and compared line by
line with the copy below before anything runs), and accepts the replay only if every stored field of all four
bandwidth rows of weight_degeneracy.json["lineage2_holdout|tree"] is reproduced (abs diff <= 1e-12).

Usage: wd_replay_l2.py --root INPUT_ROOT --out OUT.json     (INPUT_ROOT as written by fetch_inputs.py)
"""
import argparse, json, os, sys
import numpy as np, pandas as pd

ANALYSE_SRC = '''def analyse(Dm,name,te_mask,n_test=300,n_cal=1500):
    tr=np.where(~te_mask)[0]; te=np.where(te_mask)[0]
    cal=rng.choice(tr,min(n_cal,tr.size),replace=False)
    tsel=rng.choice(te,min(n_test,te.size),replace=False)
    Dblk=Dm[np.ix_(tsel,cal)]                       # (n_test, n_cal)
    med=np.median(Dblk)
    rows=[]
    for mult in (0.25,0.5,1.0,2.0):
        h=med*mult
        W=np.exp(-Dblk/h)
        W/= W.sum(axis=1,keepdims=True)             # normalise
        # pairwise similarity between test points' weight vectors
        Wn=W/np.linalg.norm(W,axis=1,keepdims=True)
        C=Wn@Wn.T
        iu=np.triu_indices(len(tsel),1)
        cos=C[iu]
        # total-variation distance between normalised weight vectors
        idx=rng.choice(len(tsel),(4000,2))
        idx=idx[idx[:,0]!=idx[:,1]]
        tv=0.5*np.abs(W[idx[:,0]]-W[idx[:,1]]).sum(axis=1)
        # effective sample size spread (does the weight MASS vary?)
        ess=1.0/ (W**2).sum(axis=1)
        rows.append({"bandwidth_x_median":mult,"cos_mean":float(cos.mean()),
                     "cos_min":float(cos.min()),"tv_mean":float(tv.mean()),
                     "tv_max":float(tv.max()),
                     "ess_mean":float(ess.mean()),"ess_cv":float(ess.std()/ess.mean())})
    return rows
'''
# the setup lines of weight_degeneracy.py that touch the random stream before the first analyse() call
SETUP_SRC = [
    'n=Dtree.shape[0]; rng=np.random.default_rng(0)',
    'vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())',
    'rm=np.zeros(n,bool); rm[rng.permutation(n)[:int(0.2*n)]]=True',
]


class LazyD:
    """Dm[np.ix_(rows, cols)] == float64(M[tidx[rows], tidx[cols]]), i.e. exactly the block of the original
    Dtree = M[np.ix_(tidx, tidx)].astype(np.float64), without building the 10,227 x 10,227 matrix."""
    def __init__(self, M, tidx):
        self.M, self.tidx, self.shape = M, tidx, (tidx.size, tidx.size)

    def __getitem__(self, key):
        r, c = key
        return np.asarray(self.M[np.ix_(self.tidx[np.ravel(r)], self.tidx[np.ravel(c)])]).astype(np.float64)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    res = os.path.join(a.root, "amrconf", "results")
    src = open(os.path.join(a.root, "amrconf", "src", "weight_degeneracy.py")).read().splitlines()
    # verbatim check of the analyse() copy (l.27-53) and the three setup lines
    copy = ANALYSE_SRC.rstrip("\n").splitlines()
    start = src.index(copy[0])
    bad = [i for i, ln in enumerate(copy) if src[start + i] != ln]
    if bad:
        sys.exit(f"wd_replay_l2: ABORT analyse() copy differs from the source at copy lines {bad}")
    for ln in SETUP_SRC:
        if ln not in src:
            sys.exit(f"wd_replay_l2: ABORT setup line not found verbatim in the source: {ln}")
    print(f"verbatim: analyse() = weight_degeneracy.py l.{start + 1}-{start + len(copy)}; setup lines "
          + ", ".join(f"l.{src.index(ln) + 1}" for ln in SETUP_SRC))

    coh = pd.read_parquet(os.path.join(res, "cohort.parquet")); keep = coh["in_cohort"].to_numpy()
    lin = coh.loc[keep, "Lineage"].to_numpy(); sub = coh.loc[keep, "Sublineage"].to_numpy()
    tidx = coh.loc[keep, "tree_idx"].to_numpy()
    M = np.load(os.path.join(res, "cophenetic_f32.npy"), mmap_mode="r")
    Dtree = LazyD(M, tidx)
    g = {"np": np, "pd": pd, "Dtree": Dtree, "sub": sub}
    for ln in SETUP_SRC:
        exec(ln, g)
    exec(ANALYSE_SRC, g)
    te_mask = (lin == "Lineage 2")
    rows = g["analyse"](Dtree, "tree", te_mask)

    stored = json.load(open(os.path.join(res, "weight_degeneracy.json")))["lineage2_holdout|tree"]
    worst = 0.0
    for r, s in zip(rows, stored):
        for k in s:
            worst = max(worst, abs(r[k] - s[k]))
    if len(rows) != len(stored) or worst > 1e-12:
        sys.exit(f"wd_replay_l2: ABORT replay does not reproduce weight_degeneracy.json (max abs diff {worst:.3e})")
    print(f"replay reproduces all {len(stored)} stored rows x {len(stored[0])} fields (max abs diff {worst:.3e})")

    # element-wise spread of the normalised weight vectors at the WIDE bandwidth (same tsel, cal, med as above)
    # (re-derived from the same random draws: re-run the stream and keep the matrices this time)
    g2 = {"np": np, "pd": pd, "Dtree": Dtree, "sub": sub}
    for ln in SETUP_SRC:
        exec(ln, g2)
    rng = g2["rng"]
    tr = np.where(~te_mask)[0]; te = np.where(te_mask)[0]
    cal = rng.choice(tr, min(1500, tr.size), replace=False)
    tsel = rng.choice(te, min(300, te.size), replace=False)
    Dblk = Dtree[np.ix_(tsel, cal)]; med = np.median(Dblk)
    out = {"n_test": int(tsel.size), "n_cal": int(cal.size), "median_patristic": float(med),
           "rows_recomputed": rows,
           "rel_diff_definition": ("max over all pairs (t, t') of the n_test sampled test isolates and all n_cal calibration "
                                   "entries i of |w_i(t) - w_i(t')| / min(w_i(t), w_i(t')), where w(t) is t's weight vector "
                                   "normalised over the calibration points (weight_degeneracy.py l.36-37); for each entry i the "
                                   "maximising pair is the isolates with the largest and the smallest w_i"),
           "by_bandwidth": []}
    for mult in (0.25, 0.5, 1.0, 2.0):
        W = np.exp(-Dblk / (med * mult)); W /= W.sum(axis=1, keepdims=True)
        hi_, lo_ = W.max(axis=0), W.min(axis=0)
        spread = hi_ - lo_                              # per calibration entry: largest gap between any two test isolates
        rel = spread / lo_                              # the definition above (denominator: the smaller weight)
        i = int(rel.argmax())
        out["by_bandwidth"].append({"bandwidth_x_median": mult,
                                    "max_abs_elementwise_diff": float(spread.max()),
                                    "mean_abs_elementwise_range": float(spread.mean()),
                                    "max_weight": float(W.max()), "min_weight": float(W.min()),
                                    "min_weight_over_uniform": float(W.min() * W.shape[1]),
                                    "max_rel_elementwise_diff": float(rel.max()),
                                    "argmax_entry": {"cal_entry": i, "w_small": float(lo_[i]), "w_large": float(hi_[i]),
                                                     "t_small": int(W[:, i].argmin()), "t_large": int(W[:, i].argmax())},
                                    "context_max_rel_diff_over_larger_weight": float((spread / hi_).max()),
                                    "context_max_rel_diff_over_mean_weight": float((spread / ((hi_ + lo_) / 2)).max())})
    out["replay_check_max_abs_diff"] = worst
    json.dump(out, open(a.out, "w"), indent=1)
    for b in out["by_bandwidth"]:
        print(f"  h={b['bandwidth_x_median']:<5} max |w_i(t)-w_i(t')| = {b['max_abs_elementwise_diff']:.3e}   "
              f"max relative (smaller weight) = {b['max_rel_elementwise_diff']:.4f}   "
              f"[larger weight {b['context_max_rel_diff_over_larger_weight']:.4f}, mean {b['context_max_rel_diff_over_mean_weight']:.4f}]   "
              f"weights in [{b['min_weight']:.3e}, {b['max_weight']:.3e}] (min = {b['min_weight_over_uniform']:.3f} x uniform)")
    print(f"wrote {os.path.basename(a.out)}")


if __name__ == "__main__":
    main()
