# Release bundle: phylogeny-weighted conformal prediction for genomic antibiotic susceptibility testing

Code and result tables of the workshop paper "Phylogeny-weighted conformal prediction for genomic antibiotic
susceptibility testing: four failures of a natural idea" (ICBINB, NeurIPS 2026). The camera-ready paper takes its
numbers from LaTeX macros written by `code/gen_numbers_icbinb.py` (`expected/numbers_icbinb.tex`) and its three figures
from `code/make_figs_icbinb.py`. This bundle rebuilds both from the result tables, and lists the commands that rebuild
the result tables from the public data.

## Contents

| folder | what |
|---|---|
| `inputs/` | the input root of every script in `code/` (pass `--root inputs`) |
| `inputs/amrconf/src/` | the paper's analysis scripts (pipeline below) |
| `inputs/amrconf/results/` | their result tables; `c2v2_pairs_s0.parquet` is the per-(drug, clade) table behind Figures 1 and 3 and the coverage-prediction numbers (`_s1` to `_s4`: master seeds 1-4; `c2v2_pairs.parquet`: an earlier unseeded run that `derive_abstract_claims.py` still reads) |
| `inputs/amrconf/paper/icbinb/numbers_e3.json` | Table 1 numbers written by the submitted figure script |
| `inputs/derived/` | outputs of the camera-ready analyses (one-feature screen, corrections over draws, nested clades, lineage-grouped validation, tree-kernel coverage, refits), with `DERIVED.sha256` |
| `inputs/release/` | `RELEASE_RECORD.json` and `RELEASE_CHANGES.tsv` (below) |
| `inputs/submitted/`, `inputs/notes/`, `inputs/nums_67/` | short excerpts and the submitted figures: inputs some scripts read (below) |
| `code/` | the camera-ready scripts, `release_check.py`, `requirements.txt` |
| `expected/` | `numbers_icbinb.tex`, `provenance_icbinb.tsv` and the three figures as delivered for the camera-ready |
| `MANIFEST.sha256` | sha256 of every other file (`sha256sum -c MANIFEST.sha256`) |

`expected/provenance_icbinb.tsv` gives, for every macro, its value, the file (relative to `inputs/`) and the key or
expression it comes from, the unrounded value and the rounding rule.

## Data

All data are from the CRyPTIC consortium's public June 2022 release (no credentials needed): https://ftp.ebi.ac.uk/pub/databases/cryptic/release_june2022/
Cite: The CRyPTIC Consortium (2022), PLOS Biology 20(8): e3001721, doi:10.1371/journal.pbio.3001721, and
The CRyPTIC Consortium (2022), PLOS Biology 20(8): e3001755, doi:10.1371/journal.pbio.3001755.
The scripts read these 6 files from `inputs/amrconf/data/` (create it; paths relative to it on the left, relative
to the release folder on the right):

| file | in the release | bytes | sha256 of the copy we used |
|---|---|---|---|
| `CRyPTIC_reuse_table_20240917.csv` | `reuse/CRyPTIC_reuse_table_20240917.csv` | 5,393,811 | `f785ae87f2bfb7f39f08d2ca2618a1925a290c39bfdfd5a535995b1827541c1b` |
| `cryptic_R1_15228_GPI_SNP_dists_NJ_tree_R_2_subset_10228GWAS_fixednegativelengths` | `pubs/gwas2022/data/cryptic_R1_15228_GPI_SNP_dists_NJ_tree_R_2_subset_10228GWAS_fixednegativelengths` | 733,467 | `03813a1e8b9866d8de1d58601b22bb87dd2ac48ef512feff82eb7fa5a1281b67` |
| `cryptic_R1_10422_protein_kmer_kinship_to_distance_matrix_NJ_tree_information.txt` | `pubs/gwas2022/data/cryptic_R1_10422_protein_kmer_kinship_to_distance_matrix_NJ_tree_information.txt` | 726,928 | `f6d1bbbac6ee5f9c90c4c802ed24f8932051618e861d9561c15cac59d7bf93df` |
| `tables/MUTATIONS_GPI.csv.gz` | `reproducibility/data_tables/cryptic-analysis-group/MUTATIONS_GPI.csv.gz` | 273,330,616 | `736c809f70d945a75c72cff9d703139f8ac4f11e7aba76e1f48b4be32d30b178` |
| `tables/GPI_SNP_DISTANCES_LABELS.npy` | `reproducibility/data_tables/cryptic-analysis-group/GPI_SNP_DISTANCES_LABELS.npy` | 3,472,112 | `611512d71d066bb71ff1dd289950b63abf5538af94654884d9c8b8c0dce25e61` |
| `tables/GPI_SNP_DISTANCES_VALUES.npy` | `reproducibility/data_tables/cryptic-analysis-group/GPI_SNP_DISTANCES_VALUES.npy` | 463,784,096 | `02d7cd4602a0bc900448f0fb290cf958a3b2c834f0bd878ca880af91eedef5dd` |

## Software

Python 3.12.13; numpy 2.5.2, pandas 3.0.5, scipy 1.18.1, scikit-learn 1.9.0, pyarrow 25.0.1, matplotlib 3.11.1, joblib 1.5.3, DendroPy 5.0.13 (`code/requirements.txt`). Every script is single-threaded unless its command below
says otherwise; set `OMP_NUM_THREADS=1` (and the MKL/OpenBLAS equivalents). `make_figs_icbinb.py` refuses any other
matplotlib version than the one that drew the figures; `check_figs_icbinb.py` also needs `pdffonts` (poppler).

The paper's scripts in `inputs/amrconf/src/` read and write under the project root `AMRCONF_ROOT` (default: the
working directory), so run them from `inputs/amrconf/` (or set `AMRCONF_ROOT` to it).

## Seeds

The seeds are set in the code, in these lines (calls in code; the camera-ready scripts that run the paper's
own lines from its source text inherit that text's seeds):

| file | line | code |
|---|---|---|
| `code/icb2_corrections.py` | 112 | `r = np.random.default_rng(zlib.crc32(f"ICB2|{lineage}|{draw}".encode()))` |
| `inputs/amrconf/src/build_phylo.py` | 135 | `rng = np.random.default_rng(0)` |
| `inputs/amrconf/src/c2v2_coverage_prediction.py` | 25 | `SEED=int(os.environ.get("SEED","0"))   # master seed; 0 is canonical, 1-4 give run spread` |
| `inputs/amrconf/src/c2v2_coverage_prediction.py` | 60 | `r=np.random.default_rng(zlib.crc32(f"{SEED}|{clade}|{d}|{s}".encode()))` |
| `inputs/amrconf/src/c2v2_coverage_prediction.py` | 93 | `for tri,tei in StratifiedKFold(3,shuffle=True,random_state=0).split(np.zeros(yd.size),yd):` |
| `inputs/amrconf/src/check_cal_variance.py` | 24 | `r=np.random.default_rng(10_000+s); rp=r.permutation(rest); cut=int(.75*rest.size)` |
| `inputs/amrconf/src/e2_conformal.py` | 80 | `rng=np.random.default_rng(0)` |
| `inputs/amrconf/src/e3_shift_diagnosis.py` | 37 | `n=X.shape[0]; rng=np.random.default_rng(0)` |
| `inputs/amrconf/src/e3_shift_diagnosis.py` | 106 | `for tri,tei in StratifiedKFold(3,shuffle=True,random_state=0).split(np.zeros(yd.size),yd):` |
| `inputs/amrconf/src/e5_selective.py` | 38 | `n=X.shape[0]; rng=np.random.default_rng(0)` |
| `inputs/amrconf/src/f17_robust.py` | 34 | `r=np.random.default_rng(1000+s); p=r.permutation(n)` |
| `inputs/amrconf/src/f17_robust.py` | 39 | `r=np.random.default_rng(2000+s)` |
| `inputs/amrconf/src/f17_robust.py` | 47 | `r=np.random.default_rng(3000)` |
| `inputs/amrconf/src/paper_numbers.py` | 52 | `m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))` |
| `inputs/amrconf/src/paper_numbers.py` | 56 | `rng=np.random.default_rng(0); cl=p.clade.unique(); b=[]` |
| `inputs/amrconf/src/paper_numbers.py` | 77 | `pr[te]=GradientBoostingRegressor(random_state=0).fit(X[tr],y[tr]).predict(X[te])` |
| `inputs/amrconf/src/paper_numbers.py` | 88 | `m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))` |
| `inputs/amrconf/src/paper_numbers.py` | 103 | `pr[te]=GradientBoostingClassifier(random_state=0).fit(X[tr],ysev[tr]).predict_proba(X[te])[:,1]` |
| `inputs/amrconf/src/paper_numbers.py` | 123 | `_gbr=GradientBoostingRegressor(random_state=0).fit(p[F].to_numpy(),p.y_broken.to_numpy())` |
| `inputs/amrconf/src/seed_spread.py` | 20 | `pr[te]=GradientBoostingRegressor(random_state=0).fit(X[tr],y[tr]).predict(X[te])` |
| `inputs/amrconf/src/snp_distance.py` | 45 | `rng=np.random.default_rng(0); s=rng.choice(n,3000,replace=False)` |
| `inputs/amrconf/src/weight_degeneracy.py` | 25 | `n=Dtree.shape[0]; rng=np.random.default_rng(0)` |

`c2v2_coverage_prediction.py` derives each draw's seed from (master seed, clade, drug, draw) with `zlib.crc32`, so
results do not depend on Python's hash salt or on the number of workers; master seed 0 is the canonical run.

## Rebuild the numbers file (no fitting)

    python code/release_check.py

It checks `MANIFEST.sha256`, runs

    python code/gen_numbers_icbinb.py --release --root inputs --out-tex numbers_icbinb.tex --out-prov provenance_icbinb.tsv

and compares both outputs byte for byte with `expected/` (and with the sha256 recorded by the build that produced
them), then runs negative controls: a changed spec value, an unlisted file change, a changed released file, a
changed replayed value, a changed derived value, a changed generator, a needless hold, a coverage gain that the rise
in full {S, R} sets no longer carries, and empty plus full shares that no longer equal the non-singleton share must
each make the generator abort with its own message. The generator aborts rather than write a value that disagrees with its source, with an
independent recorded copy of the same quantity, or with the numbers specification; `--hold` withholds a macro
(written as `\NEEDNUM{name}`) that fails a guard, and is refused for one that passes.

**The release record.** The internal build (generator commit `cf1033f21c17`) also read files that are not public: the logs
of an internal check of the numbers and the order's notes (the numbers specification and its amendments).
`inputs/release/RELEASE_RECORD.json` holds every value it read from them, at the point where it was read, and the sha256
of every file it read; `--release` replays those values, so every guard of the internal build runs again except the
one that compared input hashes with that check's manifests. The RELEASE guard requires every other file the internal
build read to be byte-identical here or listed in `inputs/release/RELEASE_CHANGES.tsv` (41 rows:
16 sanitized, 4 excerpts, 21 omitted), and the generator to be the one that wrote the record.
Sanitized means that only the lines naming the project root changed: the root, a cluster path in the original, became
`__import__("os").environ.get("AMRCONF_ROOT", ".")` (in a log line, `$AMRCONF_ROOT`); line numbers are unchanged. The
excerpts keep, verbatim, the lines that other scripts read: the unrounded LOCO R2 line of the internal check's log
(`icb3_refit.py`, `icb4b_lingroup.py`), the `NCorrSummary` row of the numbers specification (`icb2_summary.py`) and
the figure widths of the submitted LaTeX source (`make_figs_icbinb.py`, `check_figs_icbinb.py`); the submitted figures
are shipped whole for their page sizes.

## Rebuild the figures (no fitting)

    python code/make_figs_icbinb.py --root inputs --out figs --png
    python code/check_figs_icbinb.py --root inputs --figs figs --report figs/check.txt

The PDFs carry no creation date, so with the same matplotlib they are byte-identical to `expected/`
(`figs_icbinb_layout.json` too, when drawn with `--png` as here; without it a few measured extents differ in the last
digit). The print sizes are read from the submitted LaTeX source (excerpt in `inputs/submitted/`); the check needs
`pdffonts`.

## Rebuild the camera-ready analyses (`inputs/derived/`)

Without fitting (seconds; compare with `inputs/derived/`: every field except `inputs_sha256`, which names the
sanitized copies):

    python code/icb3_screen.py --root inputs --out rebuilt/icb3_screen.json
    python code/icb4a_nested.py --root inputs --out rebuilt/icb4a_nested.json
    python code/icb2_summary.py --root inputs --out rebuilt/icb2_summary.json

With model fitting (run on a cluster node; the second column is the walltime we requested; `--check-only` verifies
the copied lines of the paper's code without fitting):

| command | walltime |
|---|---|
| `python code/icb0_refit.py --root inputs --out rebuilt/icb0_refit.json` | 00:15:00 |
| `python code/icb2_corrections.py --root inputs --out rebuilt/icb2 --draws 0-199 --jobs 120` | 00:30:00 |
| `python code/icb3_refit.py --root inputs --screen rebuilt/icb3_screen.json --out rebuilt/icb3_refit.json` | 00:15:00 |
| `python code/icb4b_lingroup.py --root inputs --out rebuilt/icb4b_lingroup.json` | 00:15:00 |
| `python code/icb5_treekernel.py --root inputs --out rebuilt/icb5_treekernel.json` | 00:20:00 |

`icb2_corrections.py` writes `icb2_coverage.csv` and `icb2_run.json` into its `--out` folder. `wd_replay_l2.py --root inputs --out rebuilt/wd_replay_l2.json`
fits nothing but needs the cophenetic matrix (below), as does `icb5_treekernel.py` (also with `--check-only`): put
the rebuilt matrix in `inputs/amrconf/results/`.

## Rebuild the result tables from the data (model fitting; not run for this release)

From `inputs/amrconf/` with the data in `data/` as above (the scripts write into `results/`), in this order:

    python src/build_phylo.py            # tree -> results/cophenetic_f32.npy, cophenetic_leaf_order.txt, phylo_build_report.json
    python src/build_cohort.py           # -> results/cohort.parquet, labels_int8.npy, cohort_report.json
    python src/build_features.py         # -> results/X_*.npz, features_report.json
    python src/snp_distance.py           # -> results/snp_dist_cohort_i32.npy, snp_distance.json
    python src/weight_degeneracy.py      # -> results/weight_degeneracy.json
    python src/e2_conformal.py nonsyn 5; python src/e2_conformal.py syn 5
    python src/e3_shift_diagnosis.py     # -> results/e3_shift_diagnosis.json (Table 1)
    python src/e5_selective.py           # -> results/e5_selective.json
    NJOBS=64 python src/f17_robust.py    # -> results/f17_robust.parquet
    for s in 0 1 2 3 4; do SEED=$s NJOBS=40 python src/c2v2_coverage_prediction.py; done   # -> results/c2v2_pairs_s$s.parquet
    python src/seed_spread.py            # -> results/seed_spread.json
    python src/paper_numbers.py          # -> results/PAPER_NUMBERS.json
    python src/check_cal_variance.py     # -> results/cal_variance.json
    python src/derive_abstract_claims.py # -> results/derived_abstract_claims.json
    mkdir -p paper/icbinb/figs; python src/make_figs_icbinb.py   # the submitted figures and paper/icbinb/numbers_e3.json

`e5_selective.py` prints, next to its results, the error rates of the CRyPTIC catalogue from `baseline_catalogue.json`
(shipped; it does not enter `e5_selective.json`).

**The cophenetic matrix is not in the bundle.** It is 418,448,064 bytes of float32; compressed with `gzip -6` it is
325,619,592 bytes, above the 100 MB limit for this release. `src/build_phylo.py` rebuilds it from the published tree and
checks it (symmetry, zero diagonal, sampled triangle and four-point conditions, agreement with an
independent ancestor walk; `phylo_build_report.json`). The matrix used for the paper has sha256 `3f47d3a39152e7ac5f931fbce19d047e9f54145d584b4222b8da9898d7da3dc0`.
`results/snp_dist_cohort_i32.npy` (also about 0.4 GB) is not shipped either; `src/snp_distance.py` rebuilds it.
