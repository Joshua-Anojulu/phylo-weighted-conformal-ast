#!/usr/bin/env python3
"""Single source of truth for every number quoted in either paper.

Usage:  python src/paper_numbers.py [pairs_file]
Writes results/PAPER_NUMBERS.json and prints a human-readable audit.
Point both main.tex files at these values; never transcribe by hand.
"""
import sys, json, numpy as np, pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.metrics import r2_score, mean_absolute_error, roc_auc_score, average_precision_score
from scipy.stats import spearmanr

OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
PAIRS=sys.argv[1] if len(sys.argv)>1 else f"{OUT}/c2v2_pairs_s0.parquet"  # canonical (crc32-seeded); the un-suffixed file is the pre-F26 non-reproducible run
N={}

# ---------- syn control (F17/F21) ----------
d=pd.read_parquet(f"{OUT}/f17_robust.parquet")
for kind in ["random","sublineage_blocked","lineage_blocked"]:
    for mod in ["logreg","lgbm"]:
        for fs in ["nonsyn","syn"]:
            v=d[(d.kind==kind)&(d.model==mod)&(d.featset==fs)].auroc
            N[f"syn.{kind}.{mod}.{fs}.mean"]=round(float(v.mean()),4)
            N[f"syn.{kind}.{mod}.{fs}.sd"]=round(float(v.std()),4)
N["syn.n_cells"]=int(len(d))

# ---------- conformal coverage over clade holdouts ----------
p=pd.read_parquet(PAIRS)
well=p[p.well_characterised]; res=p[~p.well_characterised]
N["cov.pairs"]=int(len(p)); N["cov.clades"]=int(p.clade.nunique())
N["cov.median"]=round(float(p.y_cov.median()),4)
N["cov.mean"]=round(float(p.y_cov.mean()),4)
N["cov.min"]=round(float(p.y_cov.min()),4)
N["cov.within_pair_sd"]=round(float(p.y_cov_sd.mean()),4)
sev=(p.y_cov<0.70)
N["cov.severe_frac"]=round(float(sev.mean()),4); N["cov.severe_n"]=int(sev.sum())
N["cov.rho_well"]=round(float(spearmanr(well.auroc,well.y_cov).statistic),4)
N["cov.n_well"]=int(len(well))
N["cov.rho_reserve"]=round(float(spearmanr(res.auroc,res.y_cov).statistic),4)
N["cov.n_reserve"]=int(len(res))
N["cov.rho_pooled"]=round(float(spearmanr(p.auroc,p.y_cov).statistic),4)

# ---------- leave-one-clade-out prediction + bootstrap CI ----------
F=sorted([c for c in p.columns if c.startswith("f_")])
Fno=[c for c in F if not c.startswith("f_novel")]
g=p["clade"].to_numpy()
def loco(cols,target,model="gbr"):
    X=p[cols].to_numpy(); y=p[target].to_numpy(); pr=np.zeros_like(y,dtype=float)
    for tr,te in LeaveOneGroupOut().split(X,y,g):
        m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))
        pr[te]=m.fit(X[tr],y[tr]).predict(X[te])
    return y,pr
def boot(y,pr,n=2000):
    rng=np.random.default_rng(0); cl=p.clade.unique(); b=[]
    for _ in range(n):
        pick=rng.choice(cl,size=len(cl),replace=True)
        idx=np.concatenate([np.where(g==c)[0] for c in pick])
        b.append(r2_score(y[idx],pr[idx]))
    return np.percentile(b,2.5),np.percentile(b,97.5),np.std(b)
for target in ["y_cov","y_broken"]:
    for name,cols,mod in [("gbr",F,"gbr"),("ridge",F,"ridge"),("gbr_nonovel",Fno,"gbr")]:
        y,pr=loco(cols,target,mod)
        N[f"pred.{target}.{name}.r2"]=round(float(r2_score(y,pr)),4)
        N[f"pred.{target}.{name}.mae"]=round(float(mean_absolute_error(y,pr)),4)
        if name=="gbr":
            lo,hi,sd=boot(y,pr)
            N[f"pred.{target}.gbr.ci_lo"]=round(float(lo),4)
            N[f"pred.{target}.gbr.ci_hi"]=round(float(hi),4)
            N[f"pred.{target}.gbr.boot_sd"]=round(float(sd),4)
            jack=[r2_score(y[g!=c],pr[g!=c]) for c in p.clade.unique()]
            N[f"pred.{target}.gbr.dropone_range"]=round(float(max(jack)-min(jack)),4)
    # AUROC-only baseline
    y=p[target].to_numpy(); X=p[["auroc"]].to_numpy(); pr=np.zeros_like(y,dtype=float)
    for tr,te in LeaveOneGroupOut().split(X,y,g):
        pr[te]=GradientBoostingRegressor(random_state=0).fit(X[tr],y[tr]).predict(X[te])
    N[f"pred.{target}.auroc_only.r2"]=round(float(r2_score(y,pr)),4)

# ---------- leave-one-DRUG-out generalisation (same protocol, drug as the group) ----------
# The paper claims the predictor is not memorising drugs. That claim previously had no
# canonical source: it came from c2v2_predict.py, which read the RETIRED pairs file AND
# used a different model configuration, so it was not comparable to the numbers beside it.
gd=p["drug"].to_numpy()
def lodo(cols,target,model="gbr"):
    X=p[cols].to_numpy(); y=p[target].to_numpy(); pr=np.zeros_like(y,dtype=float)
    for tr,te in LeaveOneGroupOut().split(X,y,gd):
        m=(GradientBoostingRegressor(random_state=0) if model=="gbr" else Ridge(alpha=1.0))
        pr[te]=m.fit(X[tr],y[tr]).predict(X[te])
    return y,pr
for target in ["y_cov","y_broken"]:
    y,pr=lodo(F,target,"gbr")
    N[f"pred.{target}.gbr_lodo.r2"]=round(float(r2_score(y,pr)),4)
    N[f"pred.{target}.gbr_lodo.mae"]=round(float(mean_absolute_error(y,pr)),4)
N["pred.n_drugs"]=int(p.drug.nunique())

# ---------- severe-failure screening (the deployable claim) ----------
ysev=(p.y_cov<0.70).astype(int).to_numpy()
def loco_clf(cols):
    X=p[cols].to_numpy(); pr=np.zeros(len(p))
    for tr,te in LeaveOneGroupOut().split(X,ysev,g):
        if len(np.unique(ysev[tr]))<2: pr[te]=ysev[tr].mean(); continue
        pr[te]=GradientBoostingClassifier(random_state=0).fit(X[tr],ysev[tr]).predict_proba(X[te])[:,1]
    return pr
pr_lf=loco_clf(F); pr_au=loco_clf(["auroc"])
N["screen.n_severe"]=int(ysev.sum()); N["screen.frac_severe"]=round(float(ysev.mean()),4)
N["screen.labelfree_auroc"]=round(float(roc_auc_score(ysev,pr_lf)),4)
N["screen.labelfree_ap"]=round(float(average_precision_score(ysev,pr_lf)),4)
N["screen.auroc_only_auroc"]=round(float(roc_auc_score(ysev,pr_au)),4)
for topk in [0.10,0.20,0.30]:
    k=int(round(topk*len(p))); idx=np.argsort(-pr_lf)[:k]
    N[f"screen.top{int(topk*100)}.recall"]=round(float(ysev[idx].sum()/max(ysev.sum(),1)),4)
    N[f"screen.top{int(topk*100)}.precision"]=round(float(ysev[idx].mean()),4)
    N[f"screen.top{int(topk*100)}.caught"]=int(ysev[idx].sum())

# ---------- feature rank correlations ----------
for c in F:
    N[f"feat.{c}.rho_broken"]=round(float(spearmanr(p[c],p.y_broken).statistic),4)

# ---------- gradient-boosting feature importances (target y_broken) ----------
# added after the F29b stale-number audit: the papers quote these, so they must be
# regenerated from canonical data like everything else.
_gbr=GradientBoostingRegressor(random_state=0).fit(p[F].to_numpy(),p.y_broken.to_numpy())
for c,v in zip(F,_gbr.feature_importances_):
    N[f"imp.{c}.y_broken"]=round(float(v),4)
_nov=[c for c in F if c.startswith("f_novel")]
_phy=[c for c in F if c.startswith("f_dist") or c=="f_domain_auc"]
N["imp.novelty.max"]=round(max(N[f"imp.{c}.y_broken"] for c in _nov),4)
N["imp.phylo.max"]=round(max(N[f"imp.{c}.y_broken"] for c in _phy),4)
N["feat.novelty.absrho_max"]=round(max(abs(N[f"feat.{c}.rho_broken"]) for c in _nov),4)
N["feat.phylo.absrho_max"]=round(max(abs(N[f"feat.{c}.rho_broken"]) for c in _phy),4)

json.dump(N,open(f"{OUT}/PAPER_NUMBERS.json","w"),indent=1,sort_keys=True)
print(f"source: {PAIRS}\n")
for k in sorted(N):
    if k.startswith(("cov.","pred.","screen.")): print(f"  {k:42} {N[k]}")
print(f"\nwrote {OUT}/PAPER_NUMBERS.json ({len(N)} values)")
