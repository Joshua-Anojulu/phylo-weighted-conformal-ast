#!/usr/bin/env python3
"""Stream MUTATIONS_GPI.csv.gz once and build three sparse binary feature matrices over
the 10,227-isolate cohort. Feature key = "GENE@MUTATION".

  X_nonsyn : IS_NONSYNONYMOUS -- candidate causal resistance determinants
  X_syn    : IS_SYNONYMOUS    -- CANNOT be causal for resistance; a genome-derived
                                phylogeny proxy. If this matches X_nonsyn under a random
                                split, random-split AUROC is measuring taxonomy (F4).
  X_all    : every filter-passing mutation

Rows are kept only for cohort isolates with IS_FILTER_PASS==True and IS_HET/IS_NULL False.
"""
import gzip, csv, time, json, sys
import numpy as np, pandas as pd
from scipy import sparse
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
T=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/data/tables"
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
cid=coh.loc[keep,"UNIQUEID"].to_numpy()
row_of={u:i for i,u in enumerate(cid.tolist())}
n=len(cid); log(f"cohort rows: {n}")

cats=["all","nonsyn","syn"]
vocab={c:{} for c in cats}
rows={c:[] for c in cats}; cols={c:[] for c in cats}

stats=dict(total=0,cohort=0,filter_fail=0,het=0,null=0,kept=0,
           nonsyn=0,syn=0,neither=0)
t0=time.time()
with gzip.open(f"{T}/MUTATIONS_GPI.csv.gz","rt",newline="") as fh:
    rd=csv.reader(fh)
    hdr=next(rd)
    ix={h:i for i,h in enumerate(hdr)}
    iU,iG,iM=ix["UNIQUEID"],ix["GENE"],ix["MUTATION"]
    iFP,iH,iN=ix["IS_FILTER_PASS"],ix["IS_HET"],ix["IS_NULL"]
    iS,iNS=ix["IS_SYNONYMOUS"],ix["IS_NONSYNONYMOUS"]
    for rec in rd:
        stats["total"]+=1
        if stats["total"]%10_000_000==0:
            log(f"  {stats['total']:,} rows  ({time.time()-t0:.0f}s)  kept={stats['kept']:,}")
        r=row_of.get(rec[iU])
        if r is None: continue
        stats["cohort"]+=1
        if rec[iFP]!="True": stats["filter_fail"]+=1; continue
        if rec[iH]=="True":  stats["het"]+=1;        continue
        if rec[iN]=="True":  stats["null"]+=1;       continue
        stats["kept"]+=1
        key=rec[iG]+"@"+rec[iM]
        which=["all"]
        if rec[iNS]=="True": which.append("nonsyn"); stats["nonsyn"]+=1
        elif rec[iS]=="True": which.append("syn");   stats["syn"]+=1
        else: stats["neither"]+=1
        for c in which:
            v=vocab[c]
            j=v.get(key)
            if j is None: j=len(v); v[key]=j
            rows[c].append(r); cols[c].append(j)
log(f"stream done in {time.time()-t0:.0f}s")
log(json.dumps(stats,indent=2))

rep={"cohort_n":n,"stream_stats":stats,"matrices":{}}
for c in cats:
    m=len(vocab[c])
    X=sparse.coo_matrix((np.ones(len(rows[c]),dtype=np.int8),
                         (np.array(rows[c],dtype=np.int32),np.array(cols[c],dtype=np.int32))),
                        shape=(n,m)).tocsr()
    X.data[:]=1                      # binary presence, collapse duplicates
    X.sum_duplicates(); X.data[:]=1
    ac=np.asarray((X>0).sum(axis=0)).ravel()      # allele count per feature
    log(f"{c:7} shape={X.shape} nnz={X.nnz:,} density={X.nnz/(n*m):.5f} "
        f"features_ac>=5={int((ac>=5).sum())} ac>=20={int((ac>=20).sum())}")
    sparse.save_npz(f"{OUT}/X_{c}.npz",X)
    names=np.array(sorted(vocab[c],key=vocab[c].get))
    np.save(f"{OUT}/featnames_{c}.npy",names)
    np.save(f"{OUT}/allelecount_{c}.npy",ac)
    rep["matrices"][c]={"shape":list(X.shape),"nnz":int(X.nnz),
                        "n_ac_ge5":int((ac>=5).sum()),"n_ac_ge20":int((ac>=20).sum())}
json.dump(rep,open(f"{OUT}/features_report.json","w"),indent=2)
log("saved X_all.npz X_nonsyn.npz X_syn.npz + featnames/allelecount")
