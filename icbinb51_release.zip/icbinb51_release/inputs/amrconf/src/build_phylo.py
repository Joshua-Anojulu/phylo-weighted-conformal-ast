#!/usr/bin/env python3
"""Build + validate the cophenetic (patristic) distance matrix for the CRyPTIC NJ tree.

d(i,j) = depth(i) + depth(j) - 2*depth(LCA(i,j))   -- exact path length, rooting-invariant.

One postorder pass: at each internal node, every pair of leaves from two *distinct* child
subtrees has that node as LCA, so each cross-block is written exactly once (total writes
== C(n,2), asserted). Distances are then formed chunkwise as (-2L) + (d_i + d_j), where
d_i+d_j is a single symmetric quantity -- this keeps the result *exactly* symmetric in
float32 (IEEE addition is commutative but not associative).

NJ trees can carry negative branch lengths; --clamp-negative (default) sets them to 0,
which is standard practice, and the script reports the effect either way.
"""
import time, json, argparse
import numpy as np
import dendropy

DATA = __import__("os").environ.get("AMRCONF_ROOT", ".") + "/data"
OUT  = __import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
TREE = f"{DATA}/cryptic_R1_15228_GPI_SNP_dists_NJ_tree_R_2_subset_10228GWAS_fixednegativelengths"

ap = argparse.ArgumentParser()
ap.add_argument("--clamp-negative", dest="clamp", action="store_true", default=True)
ap.add_argument("--keep-negative",  dest="clamp", action="store_false")
args = ap.parse_args()

def log(*a):
    print(f"[{time.strftime('%H:%M:%S')}]", *a, flush=True)

report = {}

log("reading tree ...")
t0 = time.time()
tree = dendropy.Tree.get(path=TREE, schema="newick",
                         preserve_underscores=True,
                         suppress_internal_node_taxa=True)
log(f"  parsed in {time.time()-t0:.1f}s")

leaves = [nd for nd in tree.leaf_node_iter()]
names  = [nd.taxon.label for nd in leaves]
n = len(names)
assert len(set(names)) == n, "duplicate leaf labels"
log(f"  leaves: {n}")
report["n_leaves"] = n

# ---- branch-length audit + optional clamp --------------------------------
edges = [nd for nd in tree.preorder_node_iter() if nd.edge.length is not None]
bl = np.array([nd.edge.length for nd in edges], dtype=np.float64)
report["branch_lengths"] = {
    "n": int(bl.size), "min": float(bl.min()), "max": float(bl.max()),
    "n_negative": int((bl < 0).sum()), "n_zero": int((bl == 0).sum()),
    "sum_negative_mass": float(bl[bl < 0].sum()),
    "clamped_negatives_to_zero": bool(args.clamp),
}
log(f"  branch lengths: n={bl.size} min={bl.min():.3e} max={bl.max():.3e} "
    f"neg={(bl<0).sum()} zero={(bl==0).sum()} neg_mass={bl[bl<0].sum():.3e}")
if args.clamp and (bl < 0).any():
    nfix = 0
    for nd in edges:
        if nd.edge.length < 0:
            nd.edge.length = 0.0
            nfix += 1
    log(f"  clamped {nfix} negative branch lengths to 0")

# ---- leaf indices + root depths ------------------------------------------
for i, nd in enumerate(leaves):
    nd._leaf_idx = i
depth = np.zeros(n, dtype=np.float64)
for nd in tree.preorder_node_iter():
    e = nd.edge.length or 0.0
    nd._depth = (nd.parent_node._depth + e) if nd.parent_node is not None else 0.0
    if nd.is_leaf():
        depth[nd._leaf_idx] = nd._depth
log(f"  root-depth: min={depth.min():.3e} max={depth.max():.3e}")

# ---- postorder: LCA depth into every cross-subtree block ------------------
log(f"building LCA-depth matrix (float32, {n*n*4/2**30:.2f} GiB) ...")
M = np.zeros((n, n), dtype=np.float32)
t0, writes, multifurc = time.time(), 0, 0
for nd in tree.postorder_node_iter():
    if nd.is_leaf():
        nd._leafset = np.array([nd._leaf_idx], dtype=np.int32)
        continue
    kids = [c._leafset for c in nd.child_node_iter()]
    if len(kids) > 2:
        multifurc += 1
    d = np.float32(nd._depth)
    for a in range(len(kids)):
        for b in range(a + 1, len(kids)):
            A, B = kids[a], kids[b]
            M[np.ix_(A, B)] = d
            M[np.ix_(B, A)] = d
            writes += A.size * B.size
    nd._leafset = np.concatenate(kids)
    for c in nd.child_node_iter():
        c._leafset = None
log(f"  done in {time.time()-t0:.1f}s writes={writes} expected={n*(n-1)//2} "
    f"multifurcating_nodes={multifurc}")
assert writes == n*(n-1)//2, "LCA block coverage is wrong"
report["multifurcating_internal_nodes"] = multifurc

# ---- LCA depth -> distance, chunkwise, symmetric by construction ---------
log("converting to distances (chunkwise, symmetry-preserving) ...")
dep32 = depth.astype(np.float32)
CH = 512
for s in range(0, n, CH):
    e = min(s + CH, n)
    blk = M[s:e]
    blk *= np.float32(-2.0)
    blk += (dep32[s:e, None] + dep32[None, :])   # one symmetric quantity
    M[s:e] = blk
np.fill_diagonal(M, 0.0)
neg_before_clamp = int((M < 0).sum())
np.maximum(M, 0.0, out=M)
log(f"  distance: min={M.min():.4e} max={M.max():.4e} mean={M.mean():.4e} "
    f"(clamped {neg_before_clamp} tiny negatives)")

# ---- structural validation ----------------------------------------------
log("validating ...")
c = {}
c["exactly_symmetric"] = bool(np.array_equal(M, M.T))
c["zero_diagonal"]     = bool(np.all(np.diag(M) == 0))
c["nonnegative"]       = bool(np.all(M >= 0))
c["all_finite"]        = bool(np.all(np.isfinite(M)))
c["n_negative_pre_clamp"] = neg_before_clamp

off = ~np.eye(n, dtype=bool)
zero_pairs = (M[off] == 0).sum() // 2
c["n_zero_distance_pairs"] = int(zero_pairs)
# how many isolates are involved in >=1 zero-distance pair?
Z = (M == 0) & off
c["n_isolates_with_a_zero_distance_twin"] = int(Z.any(axis=1).sum())

rng = np.random.default_rng(0)
i, j, k = (rng.integers(0, n, 200_000) for _ in range(3))
scale = float(M.max())
c["triangle_violations_of_200k"] = int((M[i, j] > M[i, k] + M[k, j] + 1e-6 * scale).sum())

# 4-point condition: cophenetic distances on a tree must satisfy it
a, b, x, y = (rng.integers(0, n, 20_000) for _ in range(4))
s1, s2, s3 = M[a, b] + M[x, y], M[a, x] + M[b, y], M[a, y] + M[b, x]
srt = np.sort(np.stack([s1, s2, s3]), axis=0)
c["four_point_violations_of_20k"] = int((srt[2] - srt[1] > 1e-6 * scale).sum())

# ---- INDEPENDENT check: explicit LCA walk (no block algorithm involved) ---
log("cross-checking 400 random pairs via independent ancestor-walk ...")
def path_len(u, v):
    au, cur = {}, u
    tot = 0.0
    while cur is not None:
        au[id(cur)] = tot
        tot += (cur.edge.length or 0.0)
        cur = cur.parent_node
    tot, cur = 0.0, v
    while cur is not None:
        if id(cur) in au:
            return au[id(cur)] + tot
        tot += (cur.edge.length or 0.0)
        cur = cur.parent_node
    raise RuntimeError("no common ancestor")

errs, absd = [], []
for _ in range(400):
    p, q = rng.integers(0, n, 2)
    if p == q:
        continue
    ref = path_len(leaves[p], leaves[q])
    got = float(M[p, q])
    absd.append(abs(got - ref))
    errs.append(abs(got - ref) / max(abs(ref), 1e-15))
errs, absd = np.array(errs), np.array(absd)
log(f"  n={errs.size} max_rel_err={errs.max():.3e} median_rel_err={np.median(errs):.3e} "
    f"max_abs_err={absd.max():.3e}")
c["independent_walk_max_rel_err"] = float(errs.max())
c["independent_walk_max_abs_err"] = float(absd.max())

report["checks"] = c
log(json.dumps(c, indent=2))

# ---- persist -------------------------------------------------------------
np.save(f"{OUT}/cophenetic_f32.npy", M)
with open(f"{OUT}/cophenetic_leaf_order.txt", "w") as f:
    f.write("\n".join(names) + "\n")
np.save(f"{OUT}/root_depth_f64.npy", depth)
with open(f"{OUT}/phylo_build_report.json", "w") as f:
    json.dump(report, f, indent=2)
log(f"saved {OUT}/cophenetic_f32.npy shape={M.shape} dtype={M.dtype}")
