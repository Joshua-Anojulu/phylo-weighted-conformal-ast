#!/usr/bin/env python3
"""E2 -- the go/no-go experiment for the ML4H anchor paper.

Two questions, one run:
  Q1 Does a MUTATION-BASED predictor retain useful accuracy across clades?
     (if no, there is no useful predictor left to calibrate and the anchor paper dies)
  Q2 Does VANILLA split conformal lose its coverage guarantee on a held-out clade?
     (if no, there is nothing to fix)

Deployment-realistic design: train AND calibrate on the isolates you already have
(in-distribution lineages), then test on a novel clade. That is precisely the
exchangeability violation -- calibration is not exchangeable with test.

Binary conformal: nonconformity s(x,y)=1-p_hat(y|x); qhat = ceil((n+1)(1-alpha))/n
quantile of calibration scores; set(x)={y : 1-p_hat(y|x) <= qhat}.
Sets may be EMPTY (both labels implausible = OOD signal) or AMBIGUOUS {S,R} (abstain).

Feature selection (allele-count threshold) is fit on TRAIN ONLY -- no leakage.
"""
import numpy as np, pandas as pd, json, time, sys
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
DRUGS=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
ALPHA=0.10
FEATSET=sys.argv[1] if len(sys.argv)>1 else "nonsyn"
MIN_AC=int(sys.argv[2]) if len(sys.argv)>2 else 5
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
Y=np.load(f"{OUT}/labels_int8.npy")[keep]
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
X=sparse.load_npz(f"{OUT}/X_{FEATSET}.npz").tocsr()
n=X.shape[0]; log(f"X_{FEATSET} {X.shape} nnz={X.nnz:,}  alpha={ALPHA} min_ac={MIN_AC}")

def conformal(p_cal,y_cal,p_te,alpha=ALPHA):
    """p_* = P(R|x). Returns per-test-point set membership for S and R."""
    s_cal=np.where(y_cal==1,1-p_cal,1-(1-p_cal))          # 1 - p_hat(true label)
    m=s_cal.size
    lvl=min(np.ceil((m+1)*(1-alpha))/m,1.0)
    qhat=np.quantile(s_cal,lvl,method="higher")
    inS=(1-(1-p_te))<=qhat        # label S plausible
    inR=(1-p_te)<=qhat            # label R plausible
    return inS,inR,float(qhat)

def run(tr_idx,cal_idx,te_idx,tag):
    res={}
    for j,d in enumerate(DRUGS):
        y=Y[:,j]
        tr=tr_idx[y[tr_idx]>=0]; ca=cal_idx[y[cal_idx]>=0]; te=te_idx[y[te_idx]>=0]
        if tr.size<200 or ca.size<100 or te.size<100: continue
        if len(np.unique(y[tr]))<2 or len(np.unique(y[te]))<2: continue
        ac=np.asarray((X[tr]>0).sum(axis=0)).ravel()       # TRAIN-ONLY selection
        cols=np.where(ac>=MIN_AC)[0]
        if cols.size<5: continue
        Xtr=X[tr][:,cols]; Xca=X[ca][:,cols]; Xte=X[te][:,cols]
        clf=LogisticRegression(penalty="l2",C=1.0,solver="liblinear",
                               max_iter=2000,class_weight="balanced")
        clf.fit(Xtr,y[tr])
        pca=clf.predict_proba(Xca)[:,1]; pte=clf.predict_proba(Xte)[:,1]
        auc=roc_auc_score(y[te],pte)
        yhat=(pte>=0.5).astype(np.int8)
        TP=int(((yhat==1)&(y[te]==1)).sum()); FN=int(((yhat==0)&(y[te]==1)).sum())
        TN=int(((yhat==0)&(y[te]==0)).sum()); FP=int(((yhat==1)&(y[te]==0)).sum())
        inS,inR,qhat=conformal(pca,y[ca],pte)
        covered=np.where(y[te]==1,inR,inS)
        size=inS.astype(int)+inR.astype(int)
        res[d]={"n_feat":int(cols.size),"n_tr":int(tr.size),"n_cal":int(ca.size),
                "n_te":int(te.size),"prev_te":float((y[te]==1).mean()),
                "auroc":float(auc),
                "sens":TP/max(TP+FN,1),"spec":TN/max(TN+FP,1),
                "coverage":float(covered.mean()),"target":1-ALPHA,
                "mean_set_size":float(size.mean()),
                "pct_singleton":float((size==1).mean()),
                "pct_ambiguous":float((size==2).mean()),
                "pct_empty":float((size==0).mean()),"qhat":qhat}
    return res

rng=np.random.default_rng(0)
splits={}
# random: 60/20/20
p=rng.permutation(n); a,b=int(.6*n),int(.8*n)
splits["random"]=(p[:a],p[a:b],p[b:])
# sublineage-blocked: hold out whole sublineages as TEST; cal from remaining (in-dist)
vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())
held,tot=[],0
for sl in order:
    if tot>=0.2*n: break
    held.append(sl); tot+=int(vc[sl])
tem=np.isin(sub,held); rest=np.where(~tem)[0]; rp=rng.permutation(rest)
cut=int(.75*rest.size)
splits["sublineage_blocked"]=(rp[:cut],rp[cut:],np.where(tem)[0])
# lineage-blocked: hold out Lineage 2
tem2=(lin=="Lineage 2"); rest2=np.where(~tem2)[0]; rp2=rng.permutation(rest2)
cut2=int(.75*rest2.size)
splits["lineage2_blocked"]=(rp2[:cut2],rp2[cut2:],np.where(tem2)[0])

allres={}
for tag,(tr,ca,te) in splits.items():
    log(f"running {tag}: n_tr={tr.size} n_cal={ca.size} n_te={te.size}")
    allres[tag]=run(tr,ca,te,tag)

print(f"\n{'='*104}\nFEATURES = X_{FEATSET} (min allele count {MIN_AC}), target coverage {1-ALPHA:.2f}\n{'='*104}")
for tag in splits:
    r=allres[tag]
    print(f"\n--- {tag} ---")
    print(f"  {'drug':5} {'nfeat':>6} {'AUROC':>7} {'sens':>6} {'spec':>6} | "
          f"{'COVER':>6} {'setsz':>6} {'%1':>6} {'%ambig':>7} {'%empty':>7}")
    for d in DRUGS:
        if d not in r: continue
        v=r[d]
        flag=" <-- UNDERCOVER" if v["coverage"]<1-ALPHA-0.02 else ""
        print(f"  {d:5} {v['n_feat']:6} {v['auroc']:7.3f} {v['sens']:6.3f} {v['spec']:6.3f} | "
              f"{v['coverage']:6.3f} {v['mean_set_size']:6.3f} {v['pct_singleton']:6.3f} "
              f"{v['pct_ambiguous']:7.3f} {v['pct_empty']:7.3f}{flag}")
    if r:
        cov=np.array([r[d]['coverage'] for d in r]); au=np.array([r[d]['auroc'] for d in r])
        print(f"  MEAN  {'':6} {au.mean():7.3f} {'':6} {'':6} | {cov.mean():6.3f}   "
              f"undercovered: {int((cov<1-ALPHA-0.02).sum())}/{len(r)}")
json.dump(allres,open(f"{OUT}/e2_conformal_{FEATSET}_ac{MIN_AC}.json","w"),indent=2)
log(f"saved e2_conformal_{FEATSET}_ac{MIN_AC}.json")
