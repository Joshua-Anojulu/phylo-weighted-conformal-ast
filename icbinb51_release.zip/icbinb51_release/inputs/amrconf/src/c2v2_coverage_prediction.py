#!/usr/bin/env python3
"""C2-v2 -- predict conformal coverage on an UNSEEN clade from LABEL-FREE quantities.

Fixes the C2-v1 design flaw exposed by F22: coverage is bimodal in the calibration draw,
so a one-draw target is mostly noise. Here every (drug, clade) pair is evaluated over
NDRAW independent calibration draws, giving two stable targets:

  y_cov     = mean realised coverage                      (regression)
  y_broken  = P(coverage < 0.88) across draws             (the deployable question:
                                                           "how likely is my guarantee void?")

Only label-free covariates are used as predictors, all averaged over the same draws.
Parallelised over clades (each worker owns one clade's distance block).
"""
import numpy as np, pandas as pd, json, time, os, zlib
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from joblib import Parallel, delayed
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
WELL=["RIF","RFB","INH","EMB","LEV","MXF","ETH","KAN","AMI"]
ALPHA=0.10; MIN_AC=5; MIN_CLADE=50; NDRAW=8; UNDER=0.88
SEED=int(os.environ.get("SEED","0"))   # master seed; 0 is canonical, 1-4 give run spread
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
Y=np.load(f"{OUT}/labels_int8.npy")[keep]
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
tidx=coh.loc[keep,"tree_idx"].to_numpy()
X=sparse.load_npz(f"{OUT}/X_nonsyn.npz").tocsr()
n=Y.shape[0]
TREE=f"{OUT}/cophenetic_f32.npy"

vc=pd.Series(sub).value_counts()
clades=[(c,"sublineage") for c in vc[vc>=MIN_CLADE].index.tolist()]
clades+=[(c,"lineage") for c in pd.Series(lin).value_counts().index.tolist()]

def qlev(m): return min(np.ceil((m+1)*(1-ALPHA))/m,1.0)

def do_clade(clade,kind):
    memb=(sub==clade) if kind=="sublineage" else (lin==clade)
    te_all=np.where(memb)[0]; rest=np.where(~memb)[0]
    if te_all.size<MIN_CLADE or rest.size<1000: return []
    M=np.load(TREE,mmap_mode="r")
    Dblock=np.asarray(M[np.ix_(tidx[te_all],tidx[rest])])   # n_te x n_rest
    pos={v:i for i,v in enumerate(rest)}
    out=[]
    for d in ALL:
        j=ALL.index(d); y=Y[:,j]
        TE=te_all[y[te_all]>=0]
        if TE.size<40 or len(np.unique(y[TE]))<2: continue
        te_rows=np.searchsorted(te_all,TE)
        covs=[];aucs=[];feats=[]
        for s in range(NDRAW):
            # zlib.crc32, NOT hash(): CPython salts str hashing per process (PYTHONHASHSEED),
            # so hash((clade,d,s)) gave DIFFERENT calibration draws on every run. Given F22
            # (coverage is bimodal in the draw) that silently injected run-to-run noise.
            r=np.random.default_rng(zlib.crc32(f"{SEED}|{clade}|{d}|{s}".encode()))
            rp=r.permutation(rest); cut=int(.75*rest.size)
            TR=rp[:cut]; CA=rp[cut:]
            TR=TR[y[TR]>=0]; CA=CA[y[CA]>=0]
            if TR.size<300 or CA.size<150 or len(np.unique(y[TR]))<2: continue
            ac=np.asarray((X[TR]>0).sum(axis=0)).ravel(); cols=np.where(ac>=MIN_AC)[0]
            if cols.size<5: continue
            Xtr,Xca,Xte=X[TR][:,cols],X[CA][:,cols],X[TE][:,cols]
            clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                                   class_weight="balanced").fit(Xtr,y[TR])
            pca=clf.predict_proba(Xca)[:,1]; pte=clf.predict_proba(Xte)[:,1]
            s_ca=np.where(y[CA]==1,1-pca,pca)
            q=np.quantile(s_ca,qlev(s_ca.size),method="higher")
            inS,inR=(pte<=q),((1-pte)<=q)
            covs.append(float(np.where(y[TE]==1,inR,inS).mean()))
            aucs.append(float(roc_auc_score(y[TE],pte)))
            size=inS.astype(int)+inR.astype(int)
            cacols=np.array([pos[v] for v in CA])
            dmin=Dblock[np.ix_(te_rows,cacols)].min(axis=1)
            # NOVELTY MUST BE COMPUTED ON THE FULL FEATURE MATRIX.
            # Bug (F23/F24): computing it on Xtr/Xte -- which are already restricted to
            # columns with train allele count >= MIN_AC -- makes `~seen` empty BY
            # CONSTRUCTION, so f_novel_* were identically zero. Use the unfiltered X.
            unseen=(np.asarray((X[TR]>0).sum(axis=0)).ravel()==0).astype(np.float64)
            Xte_full=X[TE]
            te_cnt=np.asarray((Xte_full>0).sum(axis=1)).ravel()
            nov=np.asarray((Xte_full>0).astype(np.float64)@unseen).ravel()
            # same quantity measured against the CALIBRATION set, which is what the
            # conformal guarantee is actually anchored to
            unseen_ca=(np.asarray((X[CA]>0).sum(axis=0)).ravel()==0).astype(np.float64)
            nov_ca=np.asarray((Xte_full>0).astype(np.float64)@unseen_ca).ravel()
            Xd=sparse.vstack([Xca,Xte]); yd=np.r_[np.zeros(CA.size),np.ones(TE.size)]
            au=[]
            for tri,tei in StratifiedKFold(3,shuffle=True,random_state=0).split(np.zeros(yd.size),yd):
                dc=LogisticRegression(C=1.0,solver="liblinear",max_iter=800,
                                      class_weight="balanced").fit(Xd[tri],yd[tri])
                au.append(roc_auc_score(yd[tei],dc.predict_proba(Xd[tei])[:,1]))
            feats.append(dict(
                f_empty_rate=float((size==0).mean()), f_ambig_rate=float((size==2).mean()),
                f_dist_min_mean=float(dmin.mean()), f_dist_min_med=float(np.median(dmin)),
                f_dist_mean=float(Dblock[np.ix_(te_rows,cacols)].mean()),
                f_domain_auc=float(np.mean(au)),
                f_p_shift=float(pte.mean()-pca.mean()), f_p_te_mean=float(pte.mean()),
                f_p_te_sd=float(pte.std()),
                f_minscore_mean=float(np.minimum(pte,1-pte).mean()),
                f_novel_frac=float((nov/np.maximum(te_cnt,1)).mean()),
                f_novel_cnt=float(nov.mean()),
                f_novel_any=float((nov>0).mean()),
                f_novel_ca_frac=float((nov_ca/np.maximum(te_cnt,1)).mean()),
                f_novel_ca_cnt=float(nov_ca.mean()), f_qhat=float(q),
                f_log_n_te=float(np.log(TE.size)), f_log_n_cal=float(np.log(CA.size)),
            ))
        if len(covs)<max(3,NDRAW//2): continue
        covs=np.array(covs)
        rec={"clade":clade,"kind":kind,"drug":d,"well_characterised":d in WELL,
             "n_draws":len(covs),"n_te":int(TE.size),
             "y_cov":float(covs.mean()),"y_cov_sd":float(covs.std()),
             "y_cov_min":float(covs.min()),"y_cov_max":float(covs.max()),
             "y_broken":float((covs<UNDER).mean()),
             "auroc":float(np.mean(aucs)),"prev_te":float((y[TE]==1).mean())}
        for k in feats[0]: rec[k]=float(np.mean([f[k] for f in feats]))
        out.append(rec)
    return out

NJ=int(os.environ.get("NJOBS","40"))
log(f"{len(clades)} clades, NDRAW={NDRAW}, n_jobs={NJ}, SEED={SEED}")
res=Parallel(n_jobs=NJ,verbose=5)(delayed(do_clade)(c,k) for c,k in clades)
df=pd.DataFrame([r for sub_ in res for r in sub_])
df.to_parquet(f"{OUT}/c2v2_pairs_s{SEED}.parquet",index=False)
log(f"{len(df)} (drug,clade) pairs over {df.clade.nunique()} clades")

print(f"\n=== realised coverage over {len(df)} clade holdouts (target {1-ALPHA:.2f}) ===")
print(f"  mean {df.y_cov.mean():.3f}  median {df.y_cov.median():.3f}  "
      f"min {df.y_cov.min():.3f}  max {df.y_cov.max():.3f}")
print(f"  mean within-pair sd across draws: {df.y_cov_sd.mean():.3f}")
print(f"  P(broken) mean {df.y_broken.mean():.3f};  pairs always-broken "
      f"{(df.y_broken==1).mean():.3f};  never-broken {(df.y_broken==0).mean():.3f}")
print(f"  mean AUROC {df.auroc.mean():.3f}   spearman(AUROC, coverage) = "
      f"{df[['auroc','y_cov']].corr(method='spearman').iloc[0,1]:+.3f}")
print(f"\n=== label-free feature spearman vs y_cov / y_broken ===")
fcols=sorted([c for c in df.columns if c.startswith("f_")])
for c in fcols:
    print(f"  {c:20} cov {df[[c,'y_cov']].corr(method='spearman').iloc[0,1]:+.3f}   "
          f"broken {df[[c,'y_broken']].corr(method='spearman').iloc[0,1]:+.3f}")
log(f"saved c2v2_pairs_s{SEED}.parquet")
