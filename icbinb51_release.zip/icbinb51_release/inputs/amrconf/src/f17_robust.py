#!/usr/bin/env python3
"""F17-ROBUST -- the synonymous-control centrepiece, with error bars and two model classes.

The single-seed, single-model version (F17) is the paper's central claim, so it must survive:
  * 5 random-split seeds
  * 5 independent sublineage-blocked holdout draws
  * leave-one-lineage-out over all 4 lineages
  * two model classes (L2 logistic regression, LightGBM)
  * two feature sets (X_nonsyn = can cause resistance, X_syn = cannot)

Reports mean +/- sd of AUROC and realised conformal coverage for every cell.
"""
import numpy as np, pandas as pd, json, time, os
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from joblib import Parallel, delayed
import lightgbm as lgb
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
DRUGS=["RIF","RFB","INH","EMB","LEV","MXF"]
ALPHA=0.10; MIN_AC=5; NSEED=5
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
Y=np.load(f"{OUT}/labels_int8.npy")[keep]
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
XS={fs:sparse.load_npz(f"{OUT}/X_{fs}.npz").tocsr() for fs in ("nonsyn","syn")}
n=Y.shape[0]

# ---- build split instances -------------------------------------------------
splits=[]
for s in range(NSEED):
    r=np.random.default_rng(1000+s); p=r.permutation(n)
    a,b=int(.6*n),int(.8*n)
    splits.append(("random",f"seed{s}",p[:a],p[a:b],p[b:]))
vc=pd.Series(sub).value_counts()
for s in range(NSEED):
    r=np.random.default_rng(2000+s)
    order=r.permutation(vc.index.to_numpy()); held,tot=[],0
    for sl in order:
        if tot>=0.2*n: break
        held.append(sl); tot+=int(vc[sl])
    m=np.isin(sub,held); rest=np.where(~m)[0]; rp=r.permutation(rest); cut=int(.75*rest.size)
    splits.append(("sublineage_blocked",f"draw{s}",rp[:cut],rp[cut:],np.where(m)[0]))
for L in ["Lineage 1","Lineage 2","Lineage 3","Lineage 4"]:
    r=np.random.default_rng(3000)
    m=(lin==L); rest=np.where(~m)[0]; rp=r.permutation(rest); cut=int(.75*rest.size)
    splits.append(("lineage_blocked",L.replace(" ",""),rp[:cut],rp[cut:],np.where(m)[0]))
log(f"{len(splits)} split instances")

def one(si,fs,model,drug):
    kind,inst,tr,ca,te=splits[si]
    X=XS[fs]; j=ALL.index(drug); y=Y[:,j]
    TR=tr[y[tr]>=0]; CA=ca[y[ca]>=0]; TE=te[y[te]>=0]
    if TR.size<300 or CA.size<150 or TE.size<50: return None
    if len(np.unique(y[TR]))<2 or len(np.unique(y[TE]))<2: return None
    ac=np.asarray((X[TR]>0).sum(axis=0)).ravel(); cols=np.where(ac>=MIN_AC)[0]
    if cols.size<5: return None
    Xtr,Xca,Xte=X[TR][:,cols],X[CA][:,cols],X[TE][:,cols]
    if model=="logreg":
        clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                               class_weight="balanced").fit(Xtr,y[TR])
        pca=clf.predict_proba(Xca)[:,1]; pte=clf.predict_proba(Xte)[:,1]
    else:
        clf=lgb.LGBMClassifier(n_estimators=300,num_leaves=31,learning_rate=0.05,
                               min_child_samples=10,class_weight="balanced",
                               n_jobs=1,verbose=-1,force_col_wise=True)
        clf.fit(Xtr.astype(np.float32),y[TR])
        pca=clf.predict_proba(Xca.astype(np.float32))[:,1]
        pte=clf.predict_proba(Xte.astype(np.float32))[:,1]
    s_ca=np.where(y[CA]==1,1-pca,pca)
    q=np.quantile(s_ca,min(np.ceil((s_ca.size+1)*(1-ALPHA))/s_ca.size,1.0),method="higher")
    inS,inR=(pte<=q),((1-pte)<=q)
    cov=float(np.where(y[TE]==1,inR,inS).mean())
    size=inS.astype(int)+inR.astype(int)
    return {"kind":kind,"instance":inst,"featset":fs,"model":model,"drug":drug,
            "auroc":float(roc_auc_score(y[TE],pte)),"coverage":cov,
            "n_te":int(TE.size),"n_feat":int(cols.size),
            "pct_empty":float((size==0).mean()),"pct_ambig":float((size==2).mean())}

tasks=[(si,fs,mo,dr) for si in range(len(splits)) for fs in ("nonsyn","syn")
       for mo in ("logreg","lgbm") for dr in DRUGS]
log(f"{len(tasks)} tasks")
NJ=int(os.environ.get("NJOBS","64"))
res=Parallel(n_jobs=NJ,verbose=5)(delayed(one)(*t) for t in tasks)
df=pd.DataFrame([r for r in res if r]); df.to_parquet(f"{OUT}/f17_robust.parquet",index=False)
log(f"{len(df)} completed cells")

print(f"\n{'='*104}\nAUROC mean +/- sd  (X_nonsyn = CAN cause resistance | X_syn = CANNOT)\n{'='*104}")
for kind in ["random","sublineage_blocked","lineage_blocked"]:
    d=df[df["kind"]==kind]
    if not len(d): continue
    print(f"\n--- {kind} ({d.instance.nunique()} instances) ---")
    print(f"  {'model':8} {'drug':5} {'nonsyn':>16} {'syn':>16} {'gap':>8} {'ratio':>7}")
    for mo in ["logreg","lgbm"]:
        for dr in DRUGS:
            a=d[(d.model==mo)&(d.featset=="nonsyn")&(d.drug==dr)]["auroc"]
            b=d[(d.model==mo)&(d.featset=="syn")&(d.drug==dr)]["auroc"]
            if not len(a) or not len(b): continue
            print(f"  {mo:8} {dr:5} {a.mean():8.3f}+/-{a.std():5.3f} "
                  f"{b.mean():8.3f}+/-{b.std():5.3f} {a.mean()-b.mean():+8.3f} {b.mean()/a.mean():7.3f}")
        a=d[(d.model==mo)&(d.featset=="nonsyn")]["auroc"]; b=d[(d.model==mo)&(d.featset=="syn")]["auroc"]
        print(f"  {mo:8} {'ALL':5} {a.mean():8.3f}+/-{a.std():5.3f} "
              f"{b.mean():8.3f}+/-{b.std():5.3f} {a.mean()-b.mean():+8.3f} {b.mean()/a.mean():7.3f}")
print(f"\n{'='*104}\nCONFORMAL COVERAGE mean +/- sd (target {1-ALPHA:.2f})\n{'='*104}")
print(f"  {'kind':20} {'model':8} {'featset':8} {'coverage':>16} {'%cells<0.88':>12}")
for kind in ["random","sublineage_blocked","lineage_blocked"]:
    for mo in ["logreg","lgbm"]:
        for fs in ["nonsyn","syn"]:
            c=df[(df.kind==kind)&(df.model==mo)&(df.featset==fs)]["coverage"]
            if not len(c): continue
            print(f"  {kind:20} {mo:8} {fs:8} {c.mean():8.3f}+/-{c.std():5.3f} "
                  f"{100*(c<0.88).mean():11.1f}%")
log("saved f17_robust.parquet")
