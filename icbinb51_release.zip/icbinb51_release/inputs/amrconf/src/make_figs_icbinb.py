#!/usr/bin/env python3
"""Figures + table numbers for the ICBINB-BIO paper (the NEGATIVE result:
phylogeny-weighted conformal prediction fails four ways).

All numbers read from results/; nothing hard-coded. Palette = validated default
categorical slots; hatching/marker shape carry identity too, so the figures survive
greyscale printing and CVD.
"""
import numpy as np, pandas as pd, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import NullFormatter, NullLocator
from scipy.stats import spearmanr

OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
FIG=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/paper/icbinb/figs"
BLUE="#2a78d6"; ORANGE="#eb6834"; AQUA="#1baf7a"; VIOLET="#4a3aa7"
INK="#0b0b0b"; INK2="#52514e"; MUTED="#898781"; GRID="#e1e0d9"; BASE="#c3c2b7"
plt.rcParams.update({
    "font.family":"serif","font.serif":["DejaVu Serif"],"font.size":8,
    "axes.edgecolor":BASE,"axes.linewidth":0.8,"axes.labelcolor":INK2,
    "xtick.color":MUTED,"ytick.color":MUTED,"text.color":INK,
    "axes.grid":True,"grid.color":GRID,"grid.linewidth":0.6,"axes.axisbelow":True,
    "legend.frameon":False,"figure.dpi":200})

import sys
PAIRS=sys.argv[1] if len(sys.argv)>1 else f"{OUT}/c2v2_pairs_s0.parquet"  # canonical (crc32-seeded); the un-suffixed file is the pre-F26 non-reproducible run
d=pd.read_parquet(PAIRS)
well=d[d.well_characterised]; res=d[~d.well_characterised]

# ---- Fig 1: accuracy tells you nothing about whether the guarantee holds ----
fig,ax=plt.subplots(figsize=(3.4,2.6))
ax.axhline(0.90,color=MUTED,lw=0.9,ls=(0,(3,2)))
ax.text(1.01,0.885,"nominal 0.90",fontsize=6.5,color=MUTED,va="top",ha="right")
ax.axhspan(0.0,0.70,color=ORANGE,alpha=0.07,zorder=0)
ax.text(0.335,0.665,"severe failure",fontsize=6.5,color=ORANGE,va="top")
ax.scatter(well.auroc,well.y_cov,s=13,color=BLUE,alpha=0.65,linewidth=0,
           label=f"well-characterised (n={len(well)})")
ax.scatter(res.auroc,res.y_cov,s=13,color=ORANGE,alpha=0.65,marker="^",linewidth=0,
           label=f"reserve (n={len(res)})")
rw=spearmanr(well.auroc,well.y_cov).statistic
ax.set_xlabel("AUROC on the held-out clade"); ax.set_ylabel("realised conformal coverage")
ax.set_xlim(0.32,1.02); ax.set_ylim(0.0,1.04)
ax.set_title(f"within-class Spearman $\\rho$ = {rw:+.3f}",fontsize=8,color=INK,pad=4)
ax.legend(loc="lower left",fontsize=6.5,handletextpad=0.2,borderpad=0.2)
fig.tight_layout(); fig.savefig(f"{FIG}/fig1_auroc_vs_coverage.pdf",bbox_inches="tight")

# ---- Fig 2: normalised phylogenetic weights collapse, depth-dependently ----
W=json.load(open(f"{OUT}/weight_degeneracy.json"))
fig,ax=plt.subplots(figsize=(3.4,2.6))
sty={"random":(AQUA,"o","random split"),
     "sublineage":(BLUE,"s","sublineage holdout"),
     "lineage2":(ORANGE,"^","lineage holdout")}
for key,rows in W.items():
    hold,dist=key.split("|")
    if dist!="tree": continue
    h=hold.replace("_holdout","")
    col,mk,lab=sty[h]
    bw=[r["bandwidth_x_median"] for r in rows]; cm=[r["cos_mean"] for r in rows]
    ax.plot(bw,cm,color=col,marker=mk,ms=4,lw=1.6,label=lab,
            markeredgecolor="white",markeredgewidth=0.7)
ax.axhline(1.0,color=MUTED,lw=0.9,ls=(0,(3,2)))
ax.text(0.255,1.028,"identical weights",fontsize=6.5,color=MUTED,va="top",ha="left")
ax.set_xscale("log"); ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_minor_formatter(NullFormatter())
ax.set_xticks([0.25,0.5,1.0,2.0]); ax.set_xticklabels(["0.25","0.5","1.0","2.0"])
ax.set_xlabel("kernel bandwidth ($\\times$ median patristic distance)")
ax.set_ylabel("mean pairwise cosine sim.\nof normalised weight vectors")
ax.set_ylim(0.30,1.07)
ax.legend(loc="lower right",fontsize=6.5,handletextpad=0.3,borderpad=0.2)
fig.tight_layout(); fig.savefig(f"{FIG}/fig2_weight_degeneracy.pdf",bbox_inches="tight")

# ---- Fig 3: what predicts a broken guarantee -- and what does not ----
PHYLO={"f_dist_min_mean","f_dist_min_med","f_dist_mean","f_domain_auc",
       "f_novel_cnt","f_novel_frac","f_novel_any","f_novel_ca_cnt","f_novel_ca_frac"}
NICE={"f_minscore_mean":"mean min$(p,1-p)$","f_empty_rate":"empty-set rate",
      "f_p_te_mean":"mean $p$ (test)","f_p_te_sd":"sd $p$ (test)",
      "f_p_shift":"mean $p$ shift","f_ambig_rate":"ambiguous-set rate",
      "f_qhat":"$\\hat q$","f_log_n_cal":"log $n_{cal}$","f_log_n_te":"log $n_{te}$",
      "f_dist_min_mean":"min patristic dist.","f_dist_min_med":"median min patristic",
      "f_dist_mean":"mean patristic dist.","f_domain_auc":"domain-classifier AUC",
      "f_novel_cnt":"novel mutations (count)","f_novel_frac":"novel mutations (frac)",
      "f_novel_any":"any novel mutation","f_novel_ca_cnt":"novel vs calib. (count)",
      "f_novel_ca_frac":"novel vs calib. (frac)"}
rows=[]
for c in [c for c in d.columns if c.startswith("f_")]:
    rows.append((c,abs(spearmanr(d[c],d.y_broken).statistic)))
rows=sorted(rows,key=lambda r:r[1])
fig,ax=plt.subplots(figsize=(3.5,3.4))
ys=np.arange(len(rows))
for y,(c,v) in zip(ys,rows):
    isp=c in PHYLO
    ax.barh(y,v,height=0.68,color=ORANGE if isp else BLUE,
            hatch="///" if isp else None,edgecolor="white",linewidth=0.7)
ax.set_yticks(ys); ax.set_yticklabels([NICE.get(c,c) for c,_ in rows],fontsize=6.5)
ax.set_xlabel("|Spearman $\\rho$| vs P(guarantee broken)")
ax.set_xlim(0,0.78); ax.grid(axis="y",visible=False)
ax.legend(handles=[Patch(facecolor=BLUE,edgecolor="white",label="predicted-probability"),
                   Patch(facecolor=ORANGE,hatch="///",edgecolor="white",label="phylogeny / novelty")],
          loc="lower right",fontsize=6.5,handletextpad=0.4,borderpad=0.3)
fig.tight_layout(); fig.savefig(f"{FIG}/fig3_signal_ranking.pdf",bbox_inches="tight")

# ---- table numbers: four conformal variants (F19 T3) ----
E=json.load(open(f"{OUT}/e3_shift_diagnosis.json"))
VAR=["vanilla","class_conditional","oracle_prior","covshift_weighted"]
print("\n=== E3 variants: mean coverage (n undercovered <0.88) ===")
tab={}
for split in ["random","sublineage_blocked","lineage2_blocked"]:
    for v in VAR:
        cs=[E[split][dr]["variants"][v]["coverage"] for dr in E[split]]
        tab[f"{split}|{v}"]=(float(np.mean(cs)),int(sum(c<0.88 for c in cs)),len(cs))
for v in VAR:
    print(f"  {v:20} "+"  ".join(
        f"{tab[f'{s}|{v}'][0]:.3f} {tab[f'{s}|{v}'][1]}/{tab[f'{s}|{v}'][2]}"
        for s in ["random","sublineage_blocked","lineage2_blocked"]))
json.dump(tab,open(f"{FIG}/../numbers_e3.json","w"),indent=1)

# ---- headline numbers for the text ----
sev=(d.y_cov<0.70)
print(f"\npairs={len(d)}  clades={d.clade.nunique()}")
print(f"median coverage {d.y_cov.median():.3f}  severe(<0.70) {sev.mean()*100:.1f}% ({sev.sum()}/{len(d)})")
print(f"rho(AUROC,cov) well {spearmanr(well.auroc,well.y_cov).statistic:+.3f} (n={len(well)}) "
      f"reserve {spearmanr(res.auroc,res.y_cov).statistic:+.3f} (n={len(res)}) "
      f"pooled {spearmanr(d.auroc,d.y_cov).statistic:+.3f}")
print("figs written")
