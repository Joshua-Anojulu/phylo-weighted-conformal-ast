#!/usr/bin/env python3
"""Does the tree's additive structure make NORMALIZED conformal weight vectors degenerate
across a held-out clade?

For a test point t outside the clade boundary, d(t,x_i) ~= c_t + a_i, so
  w_i(t) = exp(-d(t,x_i)/h) ~= exp(-c_t/h) * exp(-a_i/h)
and after normalisation the c_t factor CANCELS => identical normalised weights for every t.
If true, weighted split conformal has no per-isolate adaptivity inside a novel clade, even
though the absolute distance c_t is highly variable and remains useful as a clade-level
OOD signal.

Measured directly: cosine similarity and total-variation distance between normalised
weight vectors of pairs of test isolates, tree vs SNP distance, several bandwidths.
"""
import numpy as np, pandas as pd, json, time
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
tidx=coh.loc[keep,"tree_idx"].to_numpy()
M=np.load(f"{OUT}/cophenetic_f32.npy",mmap_mode="r")
Dtree=np.ascontiguousarray(M[np.ix_(tidx,tidx)]).astype(np.float64)
Dsnp=np.load(f"{OUT}/snp_dist_cohort_i32.npy").astype(np.float64)
n=Dtree.shape[0]; rng=np.random.default_rng(0)

def analyse(Dm,name,te_mask,n_test=300,n_cal=1500):
    tr=np.where(~te_mask)[0]; te=np.where(te_mask)[0]
    cal=rng.choice(tr,min(n_cal,tr.size),replace=False)
    tsel=rng.choice(te,min(n_test,te.size),replace=False)
    Dblk=Dm[np.ix_(tsel,cal)]                       # (n_test, n_cal)
    med=np.median(Dblk)
    rows=[]
    for mult in (0.25,0.5,1.0,2.0):
        h=med*mult
        W=np.exp(-Dblk/h)
        W/= W.sum(axis=1,keepdims=True)             # normalise
        # pairwise similarity between test points' weight vectors
        Wn=W/np.linalg.norm(W,axis=1,keepdims=True)
        C=Wn@Wn.T
        iu=np.triu_indices(len(tsel),1)
        cos=C[iu]
        # total-variation distance between normalised weight vectors
        idx=rng.choice(len(tsel),(4000,2))
        idx=idx[idx[:,0]!=idx[:,1]]
        tv=0.5*np.abs(W[idx[:,0]]-W[idx[:,1]]).sum(axis=1)
        # effective sample size spread (does the weight MASS vary?)
        ess=1.0/ (W**2).sum(axis=1)
        rows.append({"bandwidth_x_median":mult,"cos_mean":float(cos.mean()),
                     "cos_min":float(cos.min()),"tv_mean":float(tv.mean()),
                     "tv_max":float(tv.max()),
                     "ess_mean":float(ess.mean()),"ess_cv":float(ess.std()/ess.mean())})
    return rows

masks={"lineage2_holdout":(lin=="Lineage 2")}
vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())
held,tot=[],0
for sl in order:
    if tot>=0.2*n: break
    held.append(sl); tot+=int(vc[sl])
masks["sublineage_holdout"]=np.isin(sub,held)
rm=np.zeros(n,bool); rm[rng.permutation(n)[:int(0.2*n)]]=True
masks["random_holdout"]=rm

rep={}
for mk,mask in masks.items():
    for dn,Dm in (("tree",Dtree),("snp",Dsnp)):
        rows=analyse(Dm,dn,mask)
        rep[f"{mk}|{dn}"]=rows
print(f"{'holdout':20} {'d':4} {'bw':>5} {'cos_mean':>9} {'cos_min':>8} {'TV_mean':>8} {'TV_max':>7} {'ESS_cv':>7}")
for k,rows in rep.items():
    mk,dn=k.split("|")
    for r in rows:
        print(f"{mk:20} {dn:4} {r['bandwidth_x_median']:5.2f} {r['cos_mean']:9.5f} "
              f"{r['cos_min']:8.5f} {r['tv_mean']:8.4f} {r['tv_max']:7.4f} {r['ess_cv']:7.4f}")
    print()
json.dump(rep,open(f"{OUT}/weight_degeneracy.json","w"),indent=2)
print("cos_mean ~1.000 and TV ~0 => normalised weights are DEGENERATE (no per-isolate adaptivity).")
