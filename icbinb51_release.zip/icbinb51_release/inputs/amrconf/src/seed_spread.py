#!/usr/bin/env python3
"""Aggregate leave-one-clade-out R2 across master seeds -> the run-to-run spread F26 asked for.
Run once results/c2v2_pairs_s{0..4}.parquet all exist:  python src/seed_spread.py
"""
import glob, re, json, numpy as np, pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.metrics import r2_score
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
rows=[]
for f in sorted(glob.glob(f"{OUT}/c2v2_pairs_s*.parquet")):
    seed=int(re.search(r"_s(\d+)\.parquet",f).group(1))
    p=pd.read_parquet(f); F=sorted([c for c in p.columns if c.startswith("f_")])
    g=p["clade"].to_numpy(); rec={"seed":seed,"n_pairs":len(p),"n_clades":p.clade.nunique(),
                                  "median_cov":round(float(p.y_cov.median()),4),
                                  "severe_frac":round(float((p.y_cov<0.70).mean()),4)}
    for t in ["y_cov","y_broken"]:
        X=p[F].to_numpy(); y=p[t].to_numpy(); pr=np.zeros_like(y,dtype=float)
        for tr,te in LeaveOneGroupOut().split(X,y,g):
            pr[te]=GradientBoostingRegressor(random_state=0).fit(X[tr],y[tr]).predict(X[te])
        rec[f"r2_{t}"]=round(float(r2_score(y,pr)),4)
    rows.append(rec)
df=pd.DataFrame(rows).sort_values("seed")
print(df.to_string(index=False))
if len(df)>1:
    print(f"\nACROSS {len(df)} MASTER SEEDS")
    for t in ["y_cov","y_broken"]:
        v=df[f"r2_{t}"]; print(f"  R2 {t:9} mean {v.mean():.3f}  sd {v.sd if False else v.std():.3f}"
                               f"  range [{v.min():.3f}, {v.max():.3f}]")
    print(f"  median coverage  mean {df.median_cov.mean():.4f} sd {df.median_cov.std():.4f}")
    print(f"  severe fraction  mean {df.severe_frac.mean():.4f} sd {df.severe_frac.std():.4f}")
df.to_json(f"{OUT}/seed_spread.json",orient="records",indent=1)
print(f"\nwrote {OUT}/seed_spread.json")
