#!/usr/bin/env python3
"""Reconcile E3 (RIF/L2 coverage 0.491) with f17_robust (0.811). Same nominal config;
only the calibration draw differs. Either coverage is highly unstable to the calibration
sample, or one script has a bug. Run many independent calibration draws and look."""
import json, os
import numpy as np, pandas as pd
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
ALPHA=0.10; MIN_AC=5
coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
Y=np.load(f"{OUT}/labels_int8.npy")[keep]; lin=coh.loc[keep,"Lineage"].to_numpy()
X=sparse.load_npz(f"{OUT}/X_nonsyn.npz").tocsr()

RESULTS={}
for DRUG in ["RIF","INH","RFB"]:
    j=ALL.index(DRUG); y=Y[:,j]
    te_mask=(lin=="Lineage 2"); rest=np.where(~te_mask)[0]
    TE=np.where(te_mask)[0]; TE=TE[y[TE]>=0]
    covs=[];aucs=[];qs=[];emps=[]
    for s in range(30):
        r=np.random.default_rng(10_000+s); rp=r.permutation(rest); cut=int(.75*rest.size)
        TR=rp[:cut]; CA=rp[cut:]
        TR=TR[y[TR]>=0]; CA=CA[y[CA]>=0]
        ac=np.asarray((X[TR]>0).sum(axis=0)).ravel(); cols=np.where(ac>=MIN_AC)[0]
        clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                               class_weight="balanced").fit(X[TR][:,cols],y[TR])
        pca=clf.predict_proba(X[CA][:,cols])[:,1]; pte=clf.predict_proba(X[TE][:,cols])[:,1]
        s_ca=np.where(y[CA]==1,1-pca,pca)
        q=np.quantile(s_ca,min(np.ceil((s_ca.size+1)*(1-ALPHA))/s_ca.size,1.0),method="higher")
        inS,inR=(pte<=q),((1-pte)<=q)
        covs.append(float(np.where(y[TE]==1,inR,inS).mean()))
        emps.append(float(((~inS)&(~inR)).mean()))
        aucs.append(float(roc_auc_score(y[TE],pte))); qs.append(float(q))
    covs=np.array(covs);aucs=np.array(aucs);qs=np.array(qs);emps=np.array(emps)
    RESULTS[DRUG]={"n_draws":int(covs.size),"n_te":int(TE.size),
        "coverage":{"mean":round(float(covs.mean()),3),"sd":round(float(covs.std()),3),
                    "min":round(float(covs.min()),3),"max":round(float(covs.max()),3),
                    "deciles":[round(float(x),3) for x in np.percentile(covs,[0,10,25,50,75,90,100])],
                    "all":[round(float(x),4) for x in covs]},
        "auroc":{"mean":round(float(aucs.mean()),3),"sd":round(float(aucs.std()),3)},
        "qhat":{"mean":round(float(qs.mean()),4),"sd":round(float(qs.std()),4),
                "min":round(float(qs.min()),4),"max":round(float(qs.max()),4)},
        "empty_set":{"mean":round(float(emps.mean()),3),"sd":round(float(emps.std()),3)}}
    print(f"\n{DRUG} / Lineage-2 holdout, 30 independent calibration draws (n_te={TE.size}):")
    print(f"  coverage : mean {covs.mean():.3f} sd {covs.std():.3f} "
          f"min {covs.min():.3f} max {covs.max():.3f}")
    print(f"  AUROC    : mean {aucs.mean():.3f} sd {aucs.std():.3f} "
          f"min {aucs.min():.3f} max {aucs.max():.3f}")
    print(f"  qhat     : mean {qs.mean():.4f} sd {qs.std():.4f} "
          f"min {qs.min():.4f} max {qs.max():.4f}")
    print(f"  empty set: mean {emps.mean():.3f} sd {emps.std():.3f}")
    print(f"  deciles of coverage: {np.round(np.percentile(covs,[0,10,25,50,75,90,100]),3)}")

# Persist. This script printed to stdout and wrote nothing for its whole life, which is why the
# paper's calibration-instability paragraph had no artifact behind it and read as untraceable.
_p = f"{OUT}/cal_variance.json"
_payload = json.dumps({"_doc": "30 seeded calibration draws per drug under Lineage-2 holdout. "
                               "Generator: src/check_cal_variance.py. Seeds default_rng(10_000+s), "
                               "so this reproduces exactly.",
                       "drugs": RESULTS}, indent=2)
assert len(_payload) > 200 and '"RIF"' in _payload, "refusing to write a degenerate payload"
_tmp = _p + ".tmp"
with open(_tmp, "w") as _fh: _fh.write(_payload)
os.replace(_tmp, _p)
print(f"\n-> {_p}")
