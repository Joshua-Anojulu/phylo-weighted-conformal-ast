#!/usr/bin/env python3
"""Load the CRyPTIC GPI SNP-distance matrix, restrict to our cohort, and test whether
genotype-space distance escapes the F6 degeneracy that kills tree distance.

F6: under clade holdout every isolate in the held-out clade has the SAME nearest training
neighbours in TREE distance (2 distinct NN sets across 3,581 L2 isolates), so cophenetic
conformal weights cannot adapt per isolate. Question: does SNP distance vary within the
held-out clade? If yes, it is the right weight source.
"""
import numpy as np, pandas as pd, json, time
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
T=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/data/tables"
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

lab=np.load(f"{T}/GPI_SNP_DISTANCES_LABELS.npy",allow_pickle=True)
V=np.load(f"{T}/GPI_SNP_DISTANCES_VALUES.npy",mmap_mode="r")
log(f"labels {lab.shape} values {V.shape} {V.dtype}")
assert V.shape==(len(lab),len(lab)), (V.shape,len(lab))

coh=pd.read_parquet(f"{OUT}/cohort.parquet")
keep=coh["in_cohort"].to_numpy()
cid=coh.loc[keep,"UNIQUEID"].to_numpy()
pos={u:i for i,u in enumerate(lab.tolist())}
miss=[u for u in cid if u not in pos]
log(f"cohort {len(cid)}  not in SNP matrix: {len(miss)}")
sel=np.array([pos[u] for u in cid if u in pos])
ok=np.array([u in pos for u in cid])

log("extracting cohort submatrix ...")
Ssnp=np.ascontiguousarray(V[np.ix_(sel,sel)]).astype(np.int32)
log(f"  SNP submatrix {Ssnp.shape} {Ssnp.dtype} ({Ssnp.nbytes/2**30:.2f} GiB)")
log(f"  symmetric={np.array_equal(Ssnp,Ssnp.T)} diag0={np.all(np.diag(Ssnp)==0)} "
    f"min={Ssnp.min()} max={Ssnp.max()} median={int(np.median(Ssnp))}")

# tree distance, same ordering
M=np.load(f"{OUT}/cophenetic_f32.npy",mmap_mode="r")
tidx=coh.loc[keep,"tree_idx"].to_numpy()[ok]
Dtree=np.ascontiguousarray(M[np.ix_(tidx,tidx)])
lin=coh.loc[keep,"Lineage"].to_numpy()[ok]
sub=coh.loc[keep,"Sublineage"].to_numpy()[ok]
n=Ssnp.shape[0]
rep={"n":int(n),"n_missing_from_snp_matrix":len(miss)}

# correlation between the two distances
rng=np.random.default_rng(0); s=rng.choice(n,3000,replace=False)
a=Dtree[np.ix_(s,s)][np.triu_indices(3000,1)].astype(np.float64)
b=Ssnp[np.ix_(s,s)][np.triu_indices(3000,1)].astype(np.float64)
from scipy.stats import spearmanr, pearsonr
rho=spearmanr(a,b).statistic; r=pearsonr(a,b).statistic
log(f"tree vs SNP distance: spearman={rho:.4f} pearson={r:.4f}")
rep["tree_vs_snp_spearman"]=float(rho); rep["tree_vs_snp_pearson"]=float(r)

# ---- THE F6 TEST -------------------------------------------------------
log("F6 test: within-held-clade variability of distance-to-nearest-training-isolate")
def probe(name, te_mask, k=5):
    tr=np.where(~te_mask)[0]; te=np.where(te_mask)[0]
    out={"n_test":int(te.size),"n_train":int(tr.size)}
    for dname,Dm in (("tree",Dtree),("snp",Ssnp)):
        blk=Dm[np.ix_(te,tr)]
        kk=min(k,tr.size)
        part=np.argpartition(blk,kk-1,axis=1)[:,:kk]
        nnsets=len(set(tuple(sorted(r)) for r in part))
        d1=blk.min(axis=1).astype(np.float64)
        out[dname]={"distinct_nn_sets":nnsets,
                    "distinct_nn_dist_values":int(np.unique(d1).size),
                    "nn_dist_mean":float(d1.mean()),"nn_dist_sd":float(d1.std()),
                    "nn_dist_cv":float(d1.std()/max(d1.mean(),1e-30))}
    return out

probes={}
probes["lineage2_holdout"]=probe("L2",(lin=="Lineage 2"))
vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())
held,tot=[],0
for sl in order:
    if tot>=0.2*n: break
    held.append(sl); tot+=int(vc[sl])
probes["sublineage_holdout"]=probe("sub",np.isin(sub,held))
perm=rng.permutation(n); rm=np.zeros(n,bool); rm[perm[:int(0.2*n)]]=True
probes["random_holdout"]=probe("rand",rm)
rep["f6_probe"]=probes

print(f"\n{'holdout':22} {'dist':5} {'distinctNNsets':>15} {'distinctNNdists':>16} {'NNdist CV':>10}")
for kk,v in probes.items():
    for dn in ("tree","snp"):
        x=v[dn]
        print(f"{kk:22} {dn:5} {x['distinct_nn_sets']:15} "
              f"{x['distinct_nn_dist_values']:16} {x['nn_dist_cv']:10.4f}")
    print()
np.save(f"{OUT}/snp_dist_cohort_i32.npy",Ssnp)
json.dump(rep,open(f"{OUT}/snp_distance.json","w"),indent=2)
log("saved snp_dist_cohort_i32.npy + snp_distance.json")
