#!/usr/bin/env python3
"""Build the canonical joined cohort: tree leaf order x lineage x 13-drug phenotypes.
This is the shared artifact every paper in the slate depends on, so it is built once,
saved once, and audited here.
"""
import json, csv
import numpy as np
import pandas as pd

D   = __import__("os").environ.get("AMRCONF_ROOT", ".") + "/data"
OUT = __import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
DRUGS = ["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]

leaf_order = [l.strip() for l in open(f"{OUT}/cophenetic_leaf_order.txt") if l.strip()]
print(f"tree leaves: {len(leaf_order)}")

lin = pd.read_csv(f"{D}/cryptic_R1_10422_protein_kmer_kinship_to_distance_matrix_NJ_tree_information.txt",
                  sep="\t", dtype=str)
print(f"lineage table: {lin.shape}")

usecols = ["UNIQUEID","ENA_SAMPLE"] + [f"{d}_BINARY_PHENOTYPE" for d in DRUGS] \
          + [f"{d}_MIC" for d in DRUGS] + [f"{d}_PHENOTYPE_QUALITY" for d in DRUGS]
phe = pd.read_csv(f"{D}/CRyPTIC_reuse_table_20240917.csv", dtype=str, usecols=usecols)
print(f"phenotype table: {phe.shape}")

base = pd.DataFrame({"UNIQUEID": leaf_order, "tree_idx": np.arange(len(leaf_order))})
df = (base.merge(lin[["uniqueID","Lineage","Sublineage"]],
                 left_on="UNIQUEID", right_on="uniqueID", how="left")
           .drop(columns=["uniqueID"])
           .merge(phe, on="UNIQUEID", how="left"))
assert len(df) == len(leaf_order) and df["tree_idx"].is_unique
print(f"joined: {df.shape}")
print(f"  missing lineage : {df['Lineage'].isna().sum()}")
print(f"  missing pheno row: {df['AMI_BINARY_PHENOTYPE'].isna().sum() - 0}")

# canonical cohort = has lineage AND has a phenotype row
has_pheno = df["ENA_SAMPLE"].notna()
df["in_cohort"] = df["Lineage"].notna() & has_pheno
print(f"  in_cohort       : {int(df['in_cohort'].sum())}")

# binary label matrix: 1=R, 0=S, -1=missing/other  (I/U treated as missing)
Y = np.full((len(df), len(DRUGS)), -1, dtype=np.int8)
for k, d in enumerate(DRUGS):
    v = df[f"{d}_BINARY_PHENOTYPE"].to_numpy()
    Y[:, k] = np.where(v == "R", 1, np.where(v == "S", 0, -1))
np.save(f"{OUT}/labels_int8.npy", Y)

rep = {"n_tree_leaves": len(leaf_order), "n_in_cohort": int(df["in_cohort"].sum()),
       "drugs": DRUGS, "per_drug": {}}
coh = df["in_cohort"].to_numpy()
print(f"\n{'drug':5} {'R':>6} {'S':>6} {'miss':>6}  %R   (cohort only)")
for k, d in enumerate(DRUGS):
    y = Y[coh, k]
    R, S, m = int((y==1).sum()), int((y==0).sum()), int((y==-1).sum())
    print(f"{d:5} {R:6} {S:6} {m:6}  {100*R/max(R+S,1):5.1f}")
    rep["per_drug"][d] = {"R": R, "S": S, "missing": m,
                          "prevalence_R": R/max(R+S,1)}

print("\nLineage counts (cohort):")
print(df.loc[coh, "Lineage"].value_counts().to_string())
rep["lineage_counts"] = df.loc[coh,"Lineage"].value_counts().to_dict()
sub = df.loc[coh, "Sublineage"].value_counts()
rep["n_sublineages"] = int(sub.size)
rep["sublineage_counts"] = sub.to_dict()
print(f"\ndistinct sublineages in cohort: {sub.size}")
print(f"sublineages with >=50 isolates: {int((sub>=50).sum())}  (covering {int(sub[sub>=50].sum())} isolates)")

df.to_parquet(f"{OUT}/cohort.parquet", index=False)
json.dump(rep, open(f"{OUT}/cohort_report.json","w"), indent=2)
print(f"\nsaved {OUT}/cohort.parquet and labels_int8.npy")
