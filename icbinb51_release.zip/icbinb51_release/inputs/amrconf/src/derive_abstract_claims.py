#!/usr/bin/env python3
"""Record the DERIVED quantities the ML4H abstract prints, so they become real keys.

Two abstract claims are aggregates over per-drug values and live under no single key in any
result file: the max per-drug coverage shift, and the signed change in mean coverage. A pin must
resolve to an indexed key, so pinning them descriptively BROKE the pin check -- correctly. The
fix is not to loosen the checker but to record what the abstract actually claims.

Note the two are different statistics of the same data: the signed mean CANCELS opposite-direction
moves (0.002) while the mean absolute does not (0.023). The paper reports both, in the abstract
and the body respectively. Neither should ever be 'corrected' into the other.
"""
import json, os
import math as _math

ROOT = __import__("os").environ.get("AMRCONF_ROOT", ".")
d = json.load(open(f"{ROOT}/results/e3_shift_diagnosis.json"))
out = {}
for split, drugs in d.items():
    van = [v["variants"]["vanilla"]["coverage"] for v in drugs.values()]
    orc = [v["variants"]["oracle_prior"]["coverage"] for v in drugs.values()]
    delt = [o - v for o, v in zip(orc, van)]
    out[split] = {
        "n_drugs": len(delt),
        "oracle_max_abs_shift": round(max(abs(x) for x in delt), 4),
        "oracle_mean_abs_shift": round(sum(abs(x) for x in delt) / len(delt), 4),
        "oracle_signed_mean_shift": round(sum(orc)/len(orc) - sum(van)/len(van), 4),
        "oracle_shift_min": round(min(delt), 4),
        "oracle_shift_max": round(max(delt), 4),
        "spans_zero": bool(min(delt) < 0 < max(delt)),
    }
# --- Table 2: mean coverage per variant x split, and the count under 0.88 ------------------
# These are means over 9 well-characterised drugs, so like the abstract's shift statistics they
# live under no single key and cannot be pinned until they are recorded here.
UNDER = 0.88
for split, drugs in d.items():
    for var in ("vanilla", "class_conditional", "oracle_prior", "covshift_weighted"):
        cov = [v["variants"][var]["coverage"] for v in drugs.values() if var in v["variants"]]
        if not cov: continue
        out[f"tab2.{split}.{var}"] = {
            "n_drugs": len(cov),
            "mean_coverage": round(sum(cov) / len(cov), 4),
            "n_under_threshold": sum(1 for c in cov if c < UNDER),
            "threshold": UNDER,
        }

# --- five-seed spread of the whole pipeline (seed_spread.json) ---------------------------
# The paper reports mean, sd and range of R^2 across five calibration draws. All four are
# aggregates over the per-seed records and live under no single key.
import statistics as _st
_ss = json.load(open(f"{ROOT}/results/seed_spread.json"))
for _f in ("r2_y_cov", "r2_y_broken", "median_cov", "severe_frac"):
    _v = [x[_f] for x in _ss if _f in x]
    if len(_v) < 2: continue
    out[f"seedspread.{_f}"] = {
        "n_seeds": len(_v), "mean": round(_st.mean(_v), 4), "sd": round(_st.stdev(_v), 4),
        "min": round(min(_v), 4), "max": round(max(_v), 4),
    }

# --- P(X|Y) discriminator AUC range per split -------------------------------------------
for _split, _drugs in d.items():
    _v = []
    for _g, _x in _drugs.items():
        _a = _x.get("pxy_discriminator_auc")
        if isinstance(_a, dict): _v += [y for y in _a.values() if isinstance(y, (int, float))]
        elif isinstance(_a, (int, float)): _v.append(_a)
    if _v:
        out[f"pxy.{_split}"] = {"n": len(_v), "min": round(min(_v), 4), "max": round(max(_v), 4)}

# --- novelty-feature ablation: |R^2 full - R^2 without novelty features| ------------------
_pn = json.load(open(f"{ROOT}/results/PAPER_NUMBERS.json"))
for _t in ("y_cov", "y_broken"):
    _a, _b = _pn.get(f"pred.{_t}.gbr.r2"), _pn.get(f"pred.{_t}.gbr_nonovel.r2")
    if _a is not None and _b is not None:
        out[f"ablation.novelty.{_t}"] = {"r2_full": _a, "r2_no_novelty": _b,
                                         "abs_delta": round(abs(_a - _b), 4)}

# --- share of isolates with a phylogenetically identical twin -----------------------------
_pb = json.load(open(f"{ROOT}/results/phylo_build_report.json"))
_cr = json.load(open(f"{ROOT}/results/cohort_report.json"))
_tw = _pb.get("checks", {}).get("n_isolates_with_a_zero_distance_twin")
_n  = _cr.get("n_in_cohort")
if _tw and _n:
    out["twins"] = {"n_with_twin": _tw, "n_cohort": _n, "pct": round(100 * _tw / _n, 1)}

# --- bound claims: the text states "|rho| <= x" and "agree within x" ----------------------
# A ceiling is the quantity the sentence ASSERTS, not a rounding of a stored scalar, so it has
# to exist as a value or the claim cannot be monitored at all. (Contrast the 5.8e-11 mantissa,
# which is half a numeral and was deliberately NOT manufactured as a result.)
_ceil2 = lambda x: _math.ceil(round(x, 10) * 100) / 100
for _blk in ("novelty", "phylo"):
    _m = _pn.get(f"feat.{_blk}.absrho_max")
    if _m is not None:
        out[f"feat.{_blk}.absrho_bound"] = {"absrho_max": _m, "bound_2dp": _ceil2(_m)}

_gaps = {}
for _sp in ("random", "lineage_blocked", "sublineage_blocked"):
    for _c in ("syn", "nonsyn"):
        _a, _b = _pn.get(f"syn.{_sp}.lgbm.{_c}.mean"), _pn.get(f"syn.{_sp}.logreg.{_c}.mean")
        if _a is not None and _b is not None:
            _gaps[f"{_sp}.{_c}"] = abs(_a - _b)
if _gaps:
    _w = max(_gaps, key=_gaps.get)
    out["syn.modelclass_gap"] = {"max_abs_gap": round(_gaps[_w], 4), "argmax": _w,
                                 "bound_2dp": _ceil2(_gaps[_w])}

# --- synonymous/non-synonymous AUROC recovery ratio ---------------------------------------
# Printed twice: "88% of the AUROC of causal features" (intro) and "a ratio of 0.88" (body).
# The body sentence lists BOTH model classes before stating one ratio, so the pooled figure is
# the one it asserts. Per-model values are kept because they differ at the 2nd decimal and the
# intro's parenthetical quotes the logistic-regression pair specifically.
_r = {}
for _m in ("logreg", "lgbm"):
    _s, _n = _pn.get(f"syn.random.{_m}.syn.mean"), _pn.get(f"syn.random.{_m}.nonsyn.mean")
    if _s and _n: _r[_m] = _s / _n
if len(_r) == 2:
    _pool = sum(_r.values()) / len(_r)
    out["syn.recovery_ratio"] = {"pooled": round(_pool, 4),
                                 "pooled_pct": round(100 * _pool, 1),
                                 "logreg": round(_r["logreg"], 4),
                                 "lgbm": round(_r["lgbm"], 4)}

# --- the 18-quantity feature family, and the domain-classifier saturation claim -----------
_feats = sorted(k.split(".")[1] for k in _pn if k.startswith("feat.f_") and k.endswith(".rho_broken"))
if _feats:
    out["feat.family"] = {"n_features": len(_feats)}

try:
    import pandas as _pd
    _pairs = _pd.read_parquet(f"{ROOT}/results/c2v2_pairs.parquet")
    _s = _pairs["f_domain_auc"].dropna()
    # The paper says this "saturates at 1.000 on every clade holdout". It is near-constant at its
    # ceiling, but "every" is not literally true -- see _FLAG_domain_auc_every in the pins file.
    out["pxy.clade_holdout_domain_auc"] = {
        "n": int(len(_s)), "mean": round(float(_s.mean()), 4),
        "min": round(float(_s.min()), 4), "max": round(float(_s.max()), 4),
        "n_rounding_to_1000": int((_s.round(3) >= 1.0).sum()),
        "n_exactly_1": int((_s == 1.0).sum())}
except Exception as _e:
    out["pxy.clade_holdout_domain_auc"] = {"error": str(_e)}

# --- the bimodal coverage clusters ---------------------------------------------------------
# The paper says coverage "clusters at either ~0.48 or ~0.90 with an empty middle". Report the
# structure without assuming it: the median is the lower cluster centre (the low group holds a
# large majority of draws), and the middle count is stated explicitly because "empty" is the
# part of that sentence the data does not support.
try:
    _all = json.load(open(f"{ROOT}/results/cal_variance.json"))["drugs"]["RIF"]["coverage"]["all"]
    _v = sorted(_all)
    _n = len(_v)
    _lo = [x for x in _v if x < 0.55]
    _hi = [x for x in _v if x > 0.85]
    _mid = [x for x in _v if 0.55 <= x <= 0.85]
    out["cal_instability.clusters"] = {
        "n_draws": _n,
        "median": round(_st.median(_v), 4),
        "lower_n": len(_lo), "lower_mean": round(sum(_lo)/len(_lo), 4),
        "upper_n": len(_hi), "upper_mean": round(sum(_hi)/len(_hi), 4),
        "middle_n": len(_mid), "middle_values": [round(x, 3) for x in _mid],
        "n_between_lower_and_upper_clusters": len([x for x in _v if 0.50 <= x < 0.85]),
        "values_between": [round(x, 3) for x in _v if 0.50 <= x < 0.85]}
except Exception as _e:
    out["cal_instability.clusters"] = {"error": str(_e)}

# --- Table 2 caption: vanilla conformal averaged over the four LOLO folds -----------------
# "Averaged over all four leave-one-lineage-out folds vanilla split conformal gives
# 0.809 +/- 0.162". The mean is over the four folds (balanced at 6 drugs each, so it equals the
# cell mean), and the +/- is the SAMPLE sd across the 24 (fold x drug) cells -- the conservative
# choice, since the spread across the four fold means alone is only 0.098.
try:
    import pandas as _pd
    _f = _pd.read_parquet(f"{ROOT}/results/f17_robust.parquet")
    _s = _f[(_f.kind == "lineage_blocked") & (_f.featset == "nonsyn") & (_f.model == "logreg")]
    _c = _s.coverage
    _fold = _s.groupby("instance").coverage.mean()
    out["lolo.vanilla_coverage"] = {
        "n_cells": int(len(_c)), "n_folds": int(len(_fold)),
        "mean": round(float(_c.mean()), 4),
        "sd_across_cells": round(float(_c.std(ddof=1)), 4),
        "sd_across_fold_means": round(float(_fold.std(ddof=0)), 4),
        "fold_means": {k: round(float(v), 3) for k, v in _fold.items()}}
except Exception as _e:
    out["lolo.vanilla_coverage"] = {"error": str(_e)}

# --- cohort lineage count ------------------------------------------------------------------
# "spanning 4 lineages and 59 sublineages". n_sublineages is stored; the lineage count is only
# implicit in the length of lineage_counts, so record it as a value.
_ch = json.load(open(f"{ROOT}/results/cohort_report.json"))
if isinstance(_ch.get("lineage_counts"), dict):
    out["cohort.lineages"] = {"n_lineages": len(_ch["lineage_counts"]),
                              "names": sorted(_ch["lineage_counts"])}

# --- reserve-drug AUROC range under blocking -----------------------------------------------
# The paper states "(AUROC 0.39--0.72 across both feature sets)" for BDQ/CFZ/DLM/LZD. Computed
# over exactly what that sentence describes: four reserve drugs x both feature sets x blocked
# splits. It REPLACED a printed 0.45--0.68 on 2026-09-07, which was the non-synonymous set with
# the two lowest cells omitted -- see _NOTE_reserve_range_widened in the pins file.
_res = {"BDQ", "CFZ", "DLM", "LZD"}
_cells = []
for _fs in ("syn", "nonsyn"):
    try:
        _E = json.load(open(f"{ROOT}/results/e2_conformal_{_fs}_ac5.json"))
    except OSError:
        continue
    for _split, _d in _E.items():
        if not isinstance(_d, dict) or _split == "random":
            continue
        for _drug, _dd in _d.items():
            if _drug in _res and isinstance(_dd, dict) and isinstance(_dd.get("auroc"), (int, float)):
                _cells.append((_fs, _split, _drug, _dd["auroc"]))
if _cells:
    _v = [c[3] for c in _cells]
    _lo = min(_cells, key=lambda c: c[3]); _hi = max(_cells, key=lambda c: c[3])
    out["reserve.blocked_auroc"] = {
        "n_cells": len(_cells), "min": round(_lo[3], 4), "max": round(_hi[3], 4),
        "argmin": f"{_lo[0]}/{_lo[1]}/{_lo[2]}", "argmax": f"{_hi[0]}/{_hi[1]}/{_hi[2]}",
        "n_below_chance": sum(1 for x in _v if x < 0.5)}

p = f"{ROOT}/results/derived_abstract_claims.json"
tmp = p + ".tmp"
with open(tmp, "w") as fh: json.dump(out, fh, indent=2)
os.replace(tmp, p)
for k, v in out.items():
    # generic: print whatever fields the entry has. A per-shape printer needed patching for
    # every new block added and silently skipped the ones it did not know about.
    print(f"  {k:<34} " + "  ".join(f"{kk}={vv}" for kk, vv in v.items()))
