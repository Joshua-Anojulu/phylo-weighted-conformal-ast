#!/usr/bin/env python3
"""E5 -- selective prediction / abstention curves. The clinically meaningful deliverable.

At each abstention budget b, report performance on the RETAINED isolates:
  sens, spec, VME (very major error: true-R called S -- the dangerous one), ME, accuracy.

Compares abstention RULES honestly, including the possibility that ours loses:
  confidence  : |p_hat - 0.5|                      (standard baseline)
  phylo       : patristic distance to nearest calibration isolate  (OUR clade-level signal)
  phylo       : patristic distance to nearest calibration isolate  (OUR clade-level signal)
  snp         : SNP distance to nearest calibration isolate
  oracle      : abstain on actually-wrong predictions (upper bound)
  random      : random abstention (lower bound)

Reference point: the deployed CRyPTIC v1.31 catalogue's own 'U' rate and its sens/spec
(from baseline_catalogue.json) -- i.e. what current clinical practice achieves.
"""
import numpy as np, pandas as pd, json, time
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
DRUGS=["RIF","RFB","INH","EMB","LEV","MXF","ETH","KAN","AMI"]
BUDGETS=[0.0,0.05,0.10,0.20,0.30,0.40,0.50]
ALPHAS=[0.01,0.02,0.05,0.10,0.15,0.20,0.30]
ALPHA=0.10; MIN_AC=5
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
Y=np.load(f"{OUT}/labels_int8.npy")[keep]
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
tidx=coh.loc[keep,"tree_idx"].to_numpy()
X=sparse.load_npz(f"{OUT}/X_nonsyn.npz").tocsr()
M=np.load(f"{OUT}/cophenetic_f32.npy",mmap_mode="r")
Dtree=np.ascontiguousarray(M[np.ix_(tidx,tidx)])
Dsnp=np.load(f"{OUT}/snp_dist_cohort_i32.npy")
n=X.shape[0]; rng=np.random.default_rng(0)

def metrics(y,yhat):
    TP=int(((yhat==1)&(y==1)).sum()); FN=int(((yhat==0)&(y==1)).sum())
    TN=int(((yhat==0)&(y==0)).sum()); FP=int(((yhat==1)&(y==0)).sum())
    return {"n":int(y.size),"sens":TP/max(TP+FN,1),"spec":TN/max(TN+FP,1),
            "vme":FN/max(TP+FN,1),"me":FP/max(TN+FP,1),
            "acc":(TP+TN)/max(y.size,1),"prev_R":float((y==1).mean())}

def run(tr,ca,te,tag):
    res={}
    for d in DRUGS:
        j=ALL.index(d); y=Y[:,j]
        TR=tr[y[tr]>=0]; CA=ca[y[ca]>=0]; TE=te[y[te]>=0]
        if TR.size<200 or CA.size<150 or TE.size<150: continue
        if len(np.unique(y[TR]))<2 or len(np.unique(y[TE]))<2: continue
        ac=np.asarray((X[TR]>0).sum(axis=0)).ravel(); cols=np.where(ac>=MIN_AC)[0]
        clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                               class_weight="balanced").fit(X[TR][:,cols],y[TR])
        pca=clf.predict_proba(X[CA][:,cols])[:,1]; pte=clf.predict_proba(X[TE][:,cols])[:,1]
        yte=y[TE]; yhat=(pte>=0.5).astype(np.int8)
        s_ca=np.where(y[CA]==1,1-pca,pca)
        q=np.quantile(s_ca,min(np.ceil((s_ca.size+1)*(1-ALPHA))/s_ca.size,1.0),method="higher")
        # abstention scores: HIGHER = abstain sooner
        # NOTE: the former continuous "conformal" rule was DROPPED. It scored
        # |(p-q)-((1-p)-q)| = |2p-1|, an algebraic duplicate of the confidence rule, and
        # produced identical curves in 27/27 drug-split cells. A genuine conformal
        # abstention rule is DISCRETE (abstain iff the set is ambiguous or empty) and is
        # evaluated separately below, one operating point per alpha.
        scores={
          "confidence": -np.abs(pte-0.5),
          "phylo"     : Dtree[np.ix_(TE,CA)].min(axis=1),
          "snp"       : Dsnp[np.ix_(TE,CA)].min(axis=1).astype(np.float64),
          "oracle"    : (yhat!=yte).astype(np.float64)+rng.random(yte.size)*1e-6,
          "random"    : rng.random(yte.size),
        }
        rows={}
        for rule,sc in scores.items():
            order=np.argsort(-sc)          # abstain on highest score first
            curve=[]
            for b in BUDGETS:
                k=int(round(b*yte.size))
                keepmask=np.ones(yte.size,bool); keepmask[order[:k]]=False
                if keepmask.sum()<30 or len(np.unique(yte[keepmask]))<2:
                    curve.append({"budget":b,"n":int(keepmask.sum()),"insufficient":True}); continue
                m=metrics(yte[keepmask],yhat[keepmask]); m["budget"]=b
                curve.append(m)
            rows[rule]=curve
        # --- GENUINE conformal abstention: discrete, one operating point per alpha ---
        # abstain iff the alpha-level prediction set is not a singleton (ambiguous {S,R}
        # or empty). The abstention RATE is an output, not a knob, so each alpha is
        # compared against the confidence rule forced to that same achieved rate.
        conf_pts=[]
        for a in ALPHAS:
            qa=np.quantile(s_ca,min(np.ceil((s_ca.size+1)*(1-a))/s_ca.size,1.0),method="higher")
            size=((pte<=qa).astype(int)+((1-pte)<=qa).astype(int))
            keepmask=(size==1)
            rate=float(1.0-keepmask.mean())
            pt={"alpha":a,"qhat":float(qa),"abstain_rate":rate,
                "empty_rate":float((size==0).mean()),"ambig_rate":float((size==2).mean())}
            if keepmask.sum()>=30 and len(np.unique(yte[keepmask]))>=2:
                pt.update(metrics(yte[keepmask],yhat[keepmask]))
            else:
                pt["insufficient"]=True
            # confidence baseline matched to the SAME abstention rate
            k=int(round(rate*yte.size))
            cm=np.ones(yte.size,bool); cm[np.argsort(-scores["confidence"])[:k]]=False
            if cm.sum()>=30 and len(np.unique(yte[cm]))>=2:
                mm=metrics(yte[cm],yhat[cm])
                pt["matched_confidence_vme"]=mm["vme"]; pt["matched_confidence_acc"]=mm["acc"]
            conf_pts.append(pt)
        res[d]={"auroc":float(roc_auc_score(yte,pte)),"n_te":int(TE.size),
                "prev_te":float((yte==1).mean()),"curves":rows,
                "conformal_discrete":conf_pts}
    return res

splits={}
p=rng.permutation(n); a,b=int(.6*n),int(.8*n)
splits["random"]=(p[:a],p[a:b],p[b:])
vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())
held,tot=[],0
for sl in order:
    if tot>=0.2*n: break
    held.append(sl); tot+=int(vc[sl])
tem=np.isin(sub,held); rest=np.where(~tem)[0]; rp=rng.permutation(rest); cut=int(.75*rest.size)
splits["sublineage_blocked"]=(rp[:cut],rp[cut:],np.where(tem)[0])
tem2=(lin=="Lineage 2"); rest2=np.where(~tem2)[0]; rp2=rng.permutation(rest2); cut2=int(.75*rest2.size)
splits["lineage2_blocked"]=(rp2[:cut2],rp2[cut2:],np.where(tem2)[0])

allres={}
for tag,(tr,ca,te) in splits.items():
    log(f"{tag}"); allres[tag]=run(tr,ca,te,tag)
json.dump(allres,open(f"{OUT}/e5_selective.json","w"),indent=2)

RULES=["confidence","phylo","snp","oracle","random"]
cat=json.load(open(f"{OUT}/baseline_catalogue.json"))
for tag in splits:
    r=allres[tag]
    if not r: continue
    print(f"\n{'#'*100}\n# {tag}: VME (very major error) on RETAINED isolates vs abstention budget\n{'#'*100}")
    for d in DRUGS:
        if d not in r: continue
        v=r[d]
        cb=cat.get(d,{})
        ref=(f"catalogue: sens {cb.get('sens',float('nan')):.3f} VME {cb.get('vme',float('nan')):.3f} "
             f"at U={cb.get('pct_U',float('nan')):.1f}%") if cb.get("sens") is not None else "catalogue: no coverage"
        print(f"\n{d}  AUROC {v['auroc']:.3f}  n_te={v['n_te']}  prev_R={v['prev_te']:.3f}   [{ref}]")
        print(f"  {'rule':11} " + " ".join(f"{b:>7.0%}" for b in BUDGETS))
        for rule in RULES:
            cur=v["curves"][rule]
            cells=[]
            for c in cur:
                cells.append("      -" if c.get("insufficient") else f"{c['vme']:7.3f}")
            print(f"  {rule:11} " + " ".join(cells))
    # aggregate: mean VME at 20% budget by rule
    print(f"\n  --- mean VME @20% abstention, {tag} ---")
    for rule in RULES:
        vals=[]
        for d in r:
            c=[x for x in r[d]["curves"][rule] if x.get("budget")==0.20 and not x.get("insufficient")]
            if c: vals.append(c[0]["vme"])
        if vals: print(f"    {rule:11} {np.mean(vals):.4f}  (n={len(vals)} drugs)")
# ---- discrete conformal abstention report ----
for tag in splits:
    r=allres[tag]
    if not r: continue
    print(f"\n{'#'*100}\n# {tag}: DISCRETE conformal abstention (abstain iff set is empty or ambiguous)\n"
          f"# rate is an OUTPUT of alpha, not a budget; 'conf@rate' = confidence rule forced to the same rate\n{'#'*100}")
    for d in DRUGS:
        if d not in r: continue
        print(f"\n{d}  AUROC {r[d]['auroc']:.3f}  n_te={r[d]['n_te']}")
        print(f"  {'alpha':>6} {'rate':>7} {'empty':>7} {'ambig':>7} {'VME':>7} {'ME':>7} {'acc':>7} {'conf@rate VME':>14}")
        for pt in r[d]["conformal_discrete"]:
            if pt.get("insufficient"):
                print(f"  {pt['alpha']:6.2f} {pt['abstain_rate']:7.3f} {pt['empty_rate']:7.3f} "
                      f"{pt['ambig_rate']:7.3f} {'-':>7} {'-':>7} {'-':>7} {'-':>14}")
                continue
            mc=pt.get("matched_confidence_vme")
            print(f"  {pt['alpha']:6.2f} {pt['abstain_rate']:7.3f} {pt['empty_rate']:7.3f} "
                  f"{pt['ambig_rate']:7.3f} {pt['vme']:7.3f} {pt['me']:7.3f} {pt['acc']:7.3f} "
                  f"{(f'{mc:.3f}' if mc is not None else '-'):>14}")
    print(f"\n  --- mean over drugs, {tag}: discrete conformal vs rate-matched confidence ---")
    for a in ALPHAS:
        vs=[];cs=[];rs=[]
        for d in r:
            pt=[x for x in r[d]["conformal_discrete"] if x["alpha"]==a and not x.get("insufficient")]
            if pt and pt[0].get("matched_confidence_vme") is not None:
                vs.append(pt[0]["vme"]); cs.append(pt[0]["matched_confidence_vme"]); rs.append(pt[0]["abstain_rate"])
        if vs: print(f"    alpha {a:4.2f}  rate {np.mean(rs):.3f}  conformal VME {np.mean(vs):.4f}  "
                     f"confidence@same-rate VME {np.mean(cs):.4f}  (n={len(vs)} drugs)")
log("saved e5_selective.json")
