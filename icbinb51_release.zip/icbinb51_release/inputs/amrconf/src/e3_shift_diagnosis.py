#!/usr/bin/env python3
"""E3 -- settle the shift-mechanism question.

Competing hypotheses for why split conformal loses coverage on a held-out clade:
  H1 pure LABEL shift   : P(Y) changes, P(X|Y) invariant
        => class-conditional (Mondrian-by-label) CP is AUTOMATICALLY valid, no weights.
           Fix is known (Podkopaev & Ramdas, UAI 2021) -> our novelty must move elsewhere.
  H2 pure COVARIATE shift: P(X) changes, P(Y|X) invariant
        => covariate-shift-weighted CP (Tibshirani et al. 2019) restores coverage.
           F14 predicts the weights are DEGENERATE under clade holdout, so expect failure.
  H3 GENERALISED shift  : P(X|Y) also changes (lineage-specific mutations)
        => BOTH standard corrections fail; abstention/OOD is the principled remedy.

Tests run:
  T1 prior shift magnitude, per drug
  T2 DIRECT P(X|Y)-invariance test: can a discriminator tell calibration-R from test-R
     (and S from S) using features? CV-AUC >> 0.5 falsifies the label-shift assumption.
  T3 four conformal variants, coverage measured marginally and class-conditionally:
       vanilla | class-conditional (Mondrian-by-label) | oracle-prior-corrected
       | covariate-shift-weighted (domain classifier)
"""
import numpy as np, pandas as pd, json, time, sys
from scipy import sparse
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
OUT=__import__("os").environ.get("AMRCONF_ROOT", ".") + "/results"
DRUGS=["RIF","RFB","INH","EMB","LEV","MXF","ETH","KAN","AMI"]   # well-characterised only
ALPHA=0.10; MIN_AC=5
def log(*a): print(f"[{time.strftime('%H:%M:%S')}]",*a,flush=True)

coh=pd.read_parquet(f"{OUT}/cohort.parquet"); keep=coh["in_cohort"].to_numpy()
ALL=["AMI","BDQ","CFZ","DLM","EMB","ETH","INH","KAN","LEV","LZD","MXF","RIF","RFB"]
Y=np.load(f"{OUT}/labels_int8.npy")[keep]
lin=coh.loc[keep,"Lineage"].to_numpy(); sub=coh.loc[keep,"Sublineage"].to_numpy()
X=sparse.load_npz(f"{OUT}/X_nonsyn.npz").tocsr()
n=X.shape[0]; rng=np.random.default_rng(0)

def qlevel(m,alpha=ALPHA): return min(np.ceil((m+1)*(1-alpha))/m,1.0)

def variants(pca,yca,pte,yte,w_cov=None,prior_te=None,prior_ca=None):
    """Return dict of variant -> (inS,inR)."""
    out={}
    s_ca=np.where(yca==1,1-pca,pca)          # 1-p_hat(true label)
    sS_te=pte; sR_te=1-pte                   # score for hypothesising S / R
    # -- vanilla split conformal
    q=np.quantile(s_ca,qlevel(s_ca.size),method="higher")
    out["vanilla"]=(sS_te<=q, sR_te<=q)
    # -- class-conditional (Mondrian by label): valid under PURE label shift
    qS=np.quantile(s_ca[yca==0],qlevel((yca==0).sum()),method="higher")
    qR=np.quantile(s_ca[yca==1],qlevel((yca==1).sum()),method="higher")
    out["class_conditional"]=(sS_te<=qS, sR_te<=qR)
    # -- oracle prior correction then vanilla CP
    if prior_te is not None and prior_ca is not None:
        def adj(p):
            eps=1e-9; p=np.clip(p,eps,1-eps)
            lo=np.log(p/(1-p))+np.log(prior_te/(1-prior_te))-np.log(prior_ca/(1-prior_ca))
            return 1/(1+np.exp(-lo))
        pca2,pte2=adj(pca),adj(pte)
        s2=np.where(yca==1,1-pca2,pca2)
        q2=np.quantile(s2,qlevel(s2.size),method="higher")
        out["oracle_prior"]=(pte2<=q2, (1-pte2)<=q2)
    # -- covariate-shift weighted CP (Tibshirani et al. 2019)
    if w_cov is not None:
        w=np.append(w_cov,w_cov.mean())      # +test point weight
        w=w/w.sum()
        order=np.argsort(s_ca); cw=np.cumsum(w[:-1][order])
        j=np.searchsorted(cw,1-ALPHA)
        q3=s_ca[order][min(j,s_ca.size-1)]
        out["covshift_weighted"]=(sS_te<=q3, sR_te<=q3)
    return out

def cov_stats(inS,inR,yte):
    covered=np.where(yte==1,inR,inS)
    size=inS.astype(int)+inR.astype(int)
    return {"coverage":float(covered.mean()),
            "cov_given_S":float(covered[yte==0].mean()) if (yte==0).any() else None,
            "cov_given_R":float(covered[yte==1].mean()) if (yte==1).any() else None,
            "mean_set_size":float(size.mean()),
            "pct_empty":float((size==0).mean()),
            "pct_ambiguous":float((size==2).mean())}

def run_split(tr,ca,te,tag):
    res={}
    for d in DRUGS:
        j=ALL.index(d); y=Y[:,j]
        TR=tr[y[tr]>=0]; CA=ca[y[ca]>=0]; TE=te[y[te]>=0]
        if TR.size<200 or CA.size<150 or TE.size<150: continue
        if len(np.unique(y[TR]))<2 or len(np.unique(y[TE]))<2: continue
        ac=np.asarray((X[TR]>0).sum(axis=0)).ravel()
        cols=np.where(ac>=MIN_AC)[0]
        Xtr,Xca,Xte=X[TR][:,cols],X[CA][:,cols],X[TE][:,cols]
        clf=LogisticRegression(C=1.0,solver="liblinear",max_iter=2000,
                               class_weight="balanced").fit(Xtr,y[TR])
        pca=clf.predict_proba(Xca)[:,1]; pte=clf.predict_proba(Xte)[:,1]
        pi_ca=float((y[CA]==1).mean()); pi_te=float((y[TE]==1).mean())

        # T2: P(X|Y) invariance -- discriminate cal vs test WITHIN each class
        inv={}
        for cls,nm in ((0,"S"),(1,"R")):
            a=CA[y[CA]==cls]; b=TE[y[TE]==cls]
            if a.size<40 or b.size<40: inv[nm]=None; continue
            Xd=sparse.vstack([X[a][:,cols],X[b][:,cols]])
            yd=np.r_[np.zeros(a.size),np.ones(b.size)]
            aucs=[]
            for tri,tei in StratifiedKFold(3,shuffle=True,random_state=0).split(np.zeros(yd.size),yd):
                dc=LogisticRegression(C=1.0,solver="liblinear",max_iter=1000,
                                      class_weight="balanced").fit(Xd[tri],yd[tri])
                aucs.append(roc_auc_score(yd[tei],dc.predict_proba(Xd[tei])[:,1]))
            inv[nm]=float(np.mean(aucs))

        # covariate-shift weights from a domain classifier (cal=0 vs test=1)
        Xd=sparse.vstack([Xca,Xte]); yd=np.r_[np.zeros(CA.size),np.ones(TE.size)]
        dc=LogisticRegression(C=1.0,solver="liblinear",max_iter=1000,
                              class_weight="balanced").fit(Xd,yd)
        pd_=np.clip(dc.predict_proba(Xca)[:,1],1e-6,1-1e-6)
        w_cov=pd_/(1-pd_)

        V=variants(pca,y[CA],pte,y[TE],w_cov=w_cov,prior_te=pi_te,prior_ca=pi_ca)
        res[d]={"auroc":float(roc_auc_score(y[TE],pte)),
                "prior_cal":pi_ca,"prior_test":pi_te,
                "prior_ratio":pi_te/max(pi_ca,1e-9),
                "pxy_discriminator_auc":inv,
                "variants":{k:cov_stats(*v,y[TE]) for k,v in V.items()}}
    return res

splits={}
p=rng.permutation(n); a,b=int(.6*n),int(.8*n)
splits["random"]=(p[:a],p[a:b],p[b:])
vc=pd.Series(sub).value_counts(); order=rng.permutation(vc.index.to_numpy())
held,tot=[],0
for sl in order:
    if tot>=0.2*n: break
    held.append(sl); tot+=int(vc[sl])
tem=np.isin(sub,held); rest=np.where(~tem)[0]; rp=rng.permutation(rest); cut=int(.75*rest.size)
splits["sublineage_blocked"]=(rp[:cut],rp[cut:],np.where(tem)[0])
tem2=(lin=="Lineage 2"); rest2=np.where(~tem2)[0]; rp2=rng.permutation(rest2); cut2=int(.75*rest2.size)
splits["lineage2_blocked"]=(rp2[:cut2],rp2[cut2:],np.where(tem2)[0])

allres={}
for tag,(tr,ca,te) in splits.items():
    log(f"{tag}: n_tr={tr.size} n_cal={ca.size} n_te={te.size}")
    allres[tag]=run_split(tr,ca,te,tag)
json.dump(allres,open(f"{OUT}/e3_shift_diagnosis.json","w"),indent=2)

VAR=["vanilla","class_conditional","oracle_prior","covshift_weighted"]
for tag in splits:
    r=allres[tag]
    if not r: continue
    print(f"\n{'='*100}\n{tag}   (target coverage {1-ALPHA:.2f})\n{'='*100}")
    print(f"{'drug':5} {'AUROC':>6} {'pi_cal':>7} {'pi_te':>6} {'ratio':>6} "
          f"{'PXY_S':>6} {'PXY_R':>6} | " + " ".join(f"{v[:9]:>10}" for v in VAR))
    for d in DRUGS:
        if d not in r: continue
        v=r[d]; iv=v["pxy_discriminator_auc"]
        cs=" ".join(f"{v['variants'][k]['coverage']:10.3f}" if k in v["variants"] else f"{'--':>10}" for k in VAR)
        print(f"{d:5} {v['auroc']:6.3f} {v['prior_cal']:7.3f} {v['prior_test']:6.3f} "
              f"{v['prior_ratio']:6.2f} {(iv.get('S') or 0):6.3f} {(iv.get('R') or 0):6.3f} | {cs}")
    for k in VAR:
        c=[r[d]["variants"][k]["coverage"] for d in r if k in r[d]["variants"]]
        if c: print(f"  mean coverage {k:20} = {np.mean(c):.3f}   undercovered {sum(1 for x in c if x<0.88)}/{len(c)}")
log("saved e3_shift_diagnosis.json")
